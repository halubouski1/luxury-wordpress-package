<?php
if(!defined('ABSPATH'))exit;
// Compatibility with the Seraphinite Accelerator speed plugin used on the live site.
// It postpones every script until the visitor's first touch or scroll; on phones the first tap on "Book" or on a date
// was lost because the booking scripts were not loaded yet. The booking scripts are therefore added once to its
// "Scripts → Non-critical → Exclude" list (everything else stays postponed), and cached pages of an apartment are
// refreshed when its dates or prices change.

const LUX_SERAPH_EXCL=[
 'id:@^lux-@',
 'src:@/themes/luxury-apart-hotel/assets/@',
 'src:@/plugins/luxury-editorial/assets/@',
 'src:@intl-tel-input@',
 'id:@^iti@',
 'body:@window\\.LUX_CATALOG@',
 'body:@window\\.LUX_LANGS@',
 'body:@luxGoogleTranslateInit@',
 'src:@translate\\.google\\.com/translate_a/element\\.js@',
];
function lux_seraph_apply(){
 if(!class_exists('\\seraph_accel\\Plugin'))return 'not installed';
 try{
  $s=\seraph_accel\Plugin::SettGet();if(!is_array($s))return 'no settings';
  // "Include only" mode lists the only scripts that are postponed, so ours are not postponed anyway.
  if(!($s['contPr']['js']['nonCrit']['excl']??true))return 'include-only mode';
  $items=array_values((array)($s['contPr']['js']['nonCrit']['items']??[]));$add=array_values(array_diff(LUX_SERAPH_EXCL,$items));
  if($add){$s['contPr']['js']['nonCrit']['items']=array_merge($items,$add);\seraph_accel\Plugin::SettSet($s);if(function_exists('\\seraph_accel\\RunOpt'))\seraph_accel\RunOpt(0);}
  return 'ok';
 }catch(\Throwable $e){return 'error: '.$e->getMessage();}
}
add_action('admin_init',function(){if(!class_exists('\\seraph_accel\\Plugin')||get_option('lux_seraph_excl')==='v1')return;$r=lux_seraph_apply();if(in_array($r,['ok','include-only mode'],true))update_option('lux_seraph_excl','v1',false);else update_option('lux_seraph_excl_last',$r,false);});
// Refresh the speed plugin's cached copies of apartments whose dates or prices changed (availability.php collects them).
add_action('shutdown',function(){
 if(empty($GLOBALS['lux_purge_ids'])||!function_exists('\\seraph_accel\\CacheOpPost'))return;
 foreach(array_keys($GLOBALS['lux_purge_ids']) as $id){try{\seraph_accel\CacheOpPost($id,'Luxury availability or price change');}catch(\Throwable $e){}}
},20);
