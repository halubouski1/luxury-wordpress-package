/* Country-code phone selector (intl-tel-input) for every tel field:
   booking form, owner enquiry, property quiz, experience request.
   Default country Georgia; on submit the field is rewritten to the full
   international number so the country code is always sent. */
(function(){
  var PREF=['ge','ru','tr','am','az','ua','il','de','gb','us','ae','kz','by'];
  function fullNumber(iti,input){
    try{var n=iti.getNumber();if(n)return n;}catch(e){}
    try{var d=iti.getSelectedCountryData(),nat=(input.value||'').replace(/[^\d]/g,'');if(d&&d.dialCode&&nat)return '+'+d.dialCode+nat;}catch(e){}
    return input.value;
  }
  function enhance(input){
    if(input.dataset.itiDone||!window.intlTelInput)return;
    input.dataset.itiDone='1';
    /* The dial code is shown beside the flag, so a "+995 ..." hint would repeat it. */
    if(/^\s*\+/.test(input.getAttribute('placeholder')||''))input.removeAttribute('placeholder');
    var iti=window.intlTelInput(input,{
      initialCountry:'ge',
      separateDialCode:true,
      countryOrder:PREF,
      loadUtils:function(){return import('https://cdn.jsdelivr.net/npm/intl-tel-input@23/build/js/utils.js');}
    });
    var form=input.closest('form');
    if(form&&!form.dataset.itiBound){form.dataset.itiBound='1';
      form.addEventListener('submit',function(){input.value=fullNumber(iti,input);},true);
    }
  }
  function scan(){if(!window.intlTelInput)return;document.querySelectorAll('input[type=tel]').forEach(enhance);}
  function ready(){scan();try{new MutationObserver(scan).observe(document.documentElement,{subtree:true,childList:true});}catch(e){}}
  if(document.readyState!=='loading')ready();else document.addEventListener('DOMContentLoaded',ready);
})();
