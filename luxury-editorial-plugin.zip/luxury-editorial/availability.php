<?php
if(!defined('ABSPATH'))exit;
// One availability calendar for the website and the admin (Asia/Tbilisi dates).
// A period [from, until) closes the nights from `from` up to the night before `until`: a new stay may start on `until`,
// and a guest may check out on `from`. Sources: manual blocks, confirmed bookings and bookings that are waiting for their
// online prepayment while the hold is active. Availability is computed from these periods, never from a "closed" switch,
// so the dates after a block are bookable at once and nothing has to be reopened by hand.

const LUX_BLOCK_REASONS=['external'=>'External booking (other channel)','direct'=>'Direct booking','owner'=>'Owner stay','maintenance'=>'Maintenance / technical block'];
const LUX_HOLD_MINUTES=75; // Flitt payment page lives 60 minutes; the extra time covers a late bank notification.

function lux_blocks($id){
 $raw=get_post_meta($id,'_lux_closed',true);if(!is_array($raw))return [];$out=[];
 foreach($raw as $i=>$r){if(!is_array($r))continue;$f=(string)($r['from']??$r[0]??'');$t=(string)($r['until']??$r[1]??'');if(!lux_ymd($f)||!lux_ymd($t)||$t<=$f)continue;
  $out[]=['key'=>(string)($r['key']??substr(md5($f.$t.$i),0,10)),'from'=>$f,'until'=>$t,'reason'=>isset(LUX_BLOCK_REASONS[$r['reason']??''])?$r['reason']:'external','comment'=>(string)($r['comment']??''),'by'=>(int)($r['by']??0),'at'=>(string)($r['at']??'')];}
 usort($out,fn($a,$b)=>strcmp($a['from'],$b['from']));return $out;
}
// Bookings that occupy apartments: confirmed ones, and online bookings waiting for payment until the hold ends.
function lux_occupying_bookings(){
 $ids=get_posts(['post_type'=>'lux_booking','post_status'=>'private','numberposts'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'_lux_status','value'=>['confirmed','awaiting_payment'],'compare'=>'IN']]]);
 $today=wp_date('Y-m-d');$out=[];
 foreach($ids as $b){$d=get_post_meta($b,'_lux_request',true);if(!is_array($d)||($d['kind']??'')==='experience'||($d['checkout']??'')<=$today)continue;
  $st=get_post_meta($b,'_lux_status',true);if($st==='awaiting_payment'&&(int)get_post_meta($b,'_lux_hold_until',true)<time())continue;
  foreach(($d['apartments']??[]) as $a)$out[]=['apt'=>(int)$a['id'],'from'=>$d['checkin'],'until'=>$d['checkout'],'type'=>$st==='confirmed'?'booking':'hold','ref'=>$d['reference'],'booking'=>(int)$b];}
 return $out;
}
// Every busy period of one apartment that has not ended. $exclude: a booking that must not block itself.
function lux_busy($aptId,$exclude=0,$withBlocks=true){
 $today=wp_date('Y-m-d');$out=[];
 if($withBlocks)foreach(lux_blocks($aptId) as $b)if($b['until']>$today)$out[]=['from'=>$b['from'],'until'=>$b['until'],'type'=>'block','ref'=>LUX_BLOCK_REASONS[$b['reason']],'key'=>$b['key']];
 foreach(lux_occupying_bookings() as $o)if($o['apt']===(int)$aptId&&$o['booking']!==(int)$exclude)$out[]=$o;
 usort($out,fn($a,$b)=>strcmp($a['from'],$b['from']));return $out;
}
// Overlap rule: requested_check_in < busy_until and requested_check_out > busy_from.
function lux_conflicts($aptId,$in,$out,$exclude=0,$withBlocks=true){return array_values(array_filter(lux_busy($aptId,$exclude,$withBlocks),fn($r)=>$in<$r['until']&&$out>$r['from']));}
function lux_booking_conflicts($bookingId){$d=get_post_meta($bookingId,'_lux_request',true);$c=[];foreach(($d['apartments']??[]) as $a)foreach(lux_conflicts((int)$a['id'],$d['checkin'],$d['checkout'],$bookingId) as $r)$c[]=$a['title'].': '.$r['from'].' – '.$r['until'].' ('.($r['type']==='block'?'blocked':$r['ref']).')';return $c;}
// Holds the apartments of an online booking while the guest pays.
function lux_hold($bookingId){update_post_meta($bookingId,'_lux_hold_until',time()+LUX_HOLD_MINUTES*MINUTE_IN_SECONDS);}
// Serialises "check, then occupy" so two guests cannot take the same nights at the same moment.
function lux_availability_lock(){for($i=0;$i<50&&!add_option('lux_avail_lock',time(),'','no');$i++){if((int)get_option('lux_avail_lock')<time()-20)delete_option('lux_avail_lock');usleep(100000);}}
function lux_availability_unlock(){delete_option('lux_avail_lock');}

// ---------- Admin: Luxury Setup → Availability ----------
add_action('admin_menu',function(){add_submenu_page('luxury-setup','Availability calendar','Availability','edit_posts','luxury-availability','lux_availability_page');});
function lux_block_log($id,$action,$b){$log=get_post_meta($id,'_lux_block_log',true);$log=is_array($log)?$log:[];$log[]=['action'=>$action,'from'=>$b['from'],'until'=>$b['until'],'reason'=>$b['reason'],'comment'=>$b['comment'],'by'=>get_current_user_id(),'at'=>current_time('mysql')];update_post_meta($id,'_lux_block_log',array_slice($log,-200));}
add_action('admin_post_lux_block_save',function(){
 if(!current_user_can('edit_posts'))wp_die('No access');check_admin_referer('lux_block');$id=absint($_POST['apt']??0);if(get_post_type($id)!==lux_room_type())wp_die('Unknown apartment');
 $in=wp_unslash($_POST);$key=sanitize_key($in['key']??'');$back=admin_url('admin.php?page=luxury-availability&apt='.$id);
 $blocks=lux_blocks($id);
 if(($in['do']??'')==='remove'){foreach($blocks as $i=>$b)if($b['key']===$key){lux_block_log($id,'remove',$b);unset($blocks[$i]);}lux_save_blocks($id,$blocks);wp_safe_redirect($back.'&msg=removed');exit;}
 $f=sanitize_text_field($in['from']??'');$t=sanitize_text_field($in['until']??'');
 if(!lux_ymd($f)||!lux_ymd($t)||$t<=$f){wp_safe_redirect($back.'&err='.rawurlencode('The release date must be after the start date.'));exit;}
 $b=['key'=>$key?:substr(wp_generate_password(12,false),0,10),'from'=>$f,'until'=>$t,'reason'=>isset(LUX_BLOCK_REASONS[$in['reason']??''])?$in['reason']:'external','comment'=>sanitize_text_field($in['comment']??''),'by'=>get_current_user_id(),'at'=>current_time('mysql')];
 lux_availability_lock();
 // A block may not cover a confirmed booking or a guest who is paying right now: those must be settled separately.
 $clash=lux_conflicts($id,$f,$t,0,false);
 if($clash){lux_availability_unlock();wp_safe_redirect($back.'&err='.rawurlencode('Not saved: these dates overlap '.implode(', ',array_map(fn($r)=>($r['type']==='hold'?'a payment in progress for ':'booking ').$r['ref'].' ('.$r['from'].' – '.$r['until'].')',$clash)).'. Settle that booking first.'));exit;}
 $found=false;foreach($blocks as $i=>$x){if($x['key']===$b['key']){$blocks[$i]=$b;$found=true;}elseif($x['from']===$f&&$x['until']===$t&&$x['reason']===$b['reason']){$found=true;}}
 if(!$found)$blocks[]=$b;lux_save_blocks($id,$blocks);lux_availability_unlock();lux_block_log($id,$key?'edit':'add',$b);
 wp_safe_redirect($back.'&msg=saved');exit;
});
function lux_save_blocks($id,$blocks){update_post_meta($id,'_lux_closed',array_values(array_map(fn($b)=>['key'=>$b['key'],'from'=>$b['from'],'until'=>$b['until'],'reason'=>$b['reason'],'comment'=>$b['comment'],'by'=>$b['by'],'at'=>$b['at']],$blocks)));}
function lux_availability_page(){
 if(!current_user_can('edit_posts'))return;
 $apts=get_posts(['post_type'=>lux_room_type(),'post_status'=>['publish','draft','private'],'numberposts'=>-1,'orderby'=>'title','order'=>'ASC']);$id=absint($_GET['apt']??($apts[0]->ID??0));$e='esc_html';
 echo '<div class="wrap"><h1>Availability calendar</h1><p>Close an apartment for a period: the nights from the start date up to the night before the release date. The release date itself is free for a new arrival, and the dates after it are bookable immediately — nothing has to be reopened. A block closes sales only; it does not create a booking, an invoice or a voucher.</p>';
 if(!empty($_GET['msg']))echo '<div class="notice notice-success is-dismissible"><p>'.($_GET['msg']==='removed'?'Block removed.':'Saved. The website uses it immediately.').'</p></div>';
 if(!empty($_GET['err']))echo '<div class="notice notice-error"><p>'.$e(wp_unslash($_GET['err'])).'</p></div>';
 echo '<form method="get"><input type="hidden" name="page" value="luxury-availability"><label>Apartment <select name="apt" onchange="this.form.submit()">';
 foreach(['batumi'=>'Batumi','gudauri'=>'Gudauri'] as $c=>$cl){echo '<optgroup label="'.$cl.'">';foreach($apts as $a)if((get_post_meta($a->ID,'_lux_city',true)?:'batumi')===$c)echo '<option value="'.$a->ID.'" '.selected($id,$a->ID,false).'>'.$e($a->post_title.' · block '.get_post_meta($a->ID,'_lux_block',true)).'</option>';echo '</optgroup>';}
 echo '</select></label> <noscript><button class="button">Show</button></noscript></form>';
 if(!$id){echo '</div>';return;}
 $label=['block'=>'Manual block','booking'=>'Booking','hold'=>'Payment in progress (temporary hold)'];
 echo '<h2>'.$e(get_the_title($id)).'</h2><table class="widefat striped" style="max-width:1100px"><thead><tr><th>Type</th><th>Start (first night)</th><th>Release date (free again)</th><th>Nights</th><th>Reason / booking</th><th>Comment (internal)</th><th>Changed</th><th></th></tr></thead><tbody>';
 $rows=lux_busy($id);$blocks=[];foreach(lux_blocks($id) as $b)$blocks[$b['key']]=$b;
 if(!$rows)echo '<tr><td colspan="8">Free — no blocks or bookings ahead.</td></tr>';
 foreach($rows as $r){$n=lux_ymd($r['from'])->diff(lux_ymd($r['until']))->days;$b=$r['type']==='block'?($blocks[$r['key']]??null):null;
  echo '<tr><td><strong>'.$e($label[$r['type']]).'</strong></td>';
  if($b){$u=get_userdata($b['by']);echo '<td colspan="7"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">'.wp_nonce_field('lux_block','_wpnonce',true,false).'<input type="hidden" name="action" value="lux_block_save"><input type="hidden" name="apt" value="'.$id.'"><input type="hidden" name="key" value="'.esc_attr($b['key']).'"><input type="date" name="from" value="'.esc_attr($b['from']).'" required> → <input type="date" name="until" value="'.esc_attr($b['until']).'" required> <span>'.$n.' night'.($n===1?'':'s').'</span><select name="reason">';foreach(LUX_BLOCK_REASONS as $k=>$v)echo '<option value="'.$k.'" '.selected($b['reason'],$k,false).'>'.$e($v).'</option>';echo '</select><input type="text" name="comment" value="'.esc_attr($b['comment']).'" placeholder="Internal comment" style="min-width:200px"><span class="description">'.$e(($u?$u->display_name:'').' · '.$b['at']).'</span><button class="button">Save changes</button><button class="button-link-delete" name="do" value="remove" onclick="return confirm(\'Remove this block?\')">Remove</button></form></td></tr>';continue;}
  echo '<td>'.$e($r['from']).'</td><td>'.$e($r['until']).'</td><td>'.$n.'</td><td>'.(isset($r['booking'])?'<a href="'.esc_url(get_edit_post_link($r['booking'])).'">'.$e($r['ref']).'</a>':$e($r['ref'])).'</td><td></td><td></td><td></td></tr>';}
 echo '</tbody></table><h2>Close dates</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;max-width:1100px">'.wp_nonce_field('lux_block','_wpnonce',true,false).'<input type="hidden" name="action" value="lux_block_save"><input type="hidden" name="apt" value="'.$id.'"><label>Start date (first closed night)<br><input type="date" name="from" required></label><label>Release date (free again)<br><input type="date" name="until" required></label><label>Reason<br><select name="reason">';foreach(LUX_BLOCK_REASONS as $k=>$v)echo '<option value="'.$k.'">'.$e($v).'</option>';echo '</select></label><label>Internal comment<br><input type="text" name="comment" style="min-width:260px"></label><button class="button button-primary">Close these dates</button></form><p class="description">Example: start 10 December, release 15 December closes the nights of 10–14 December; a guest can arrive on 15 December. Reasons and comments are never shown to guests.</p>';
 $log=get_post_meta($id,'_lux_block_log',true);if(is_array($log)&&$log){echo '<h2>History</h2><ul>';foreach(array_slice(array_reverse($log),0,30) as $l){$u=get_userdata($l['by']);echo '<li>'.$e($l['at'].' · '.($u?$u->display_name:'').' · '.$l['action'].' · '.$l['from'].' → '.$l['until'].' · '.(LUX_BLOCK_REASONS[$l['reason']]??'').($l['comment']?' · '.$l['comment']:'')).'</li>';}echo '</ul>';}
 echo '</div>';
}
