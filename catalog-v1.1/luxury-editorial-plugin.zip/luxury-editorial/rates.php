<?php
if(!defined('ABSPATH'))exit;
// Seasonal nightly rates. A period covers every night from `from` to `to` inclusive (checkout day is not a night).
// When periods overlap, the shortest one wins, so a holiday week can sit inside a wider season. Nights outside all periods use the base rate.

function lux_ymd($v){if(!is_string($v))return false;$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v,new DateTimeZone('UTC'));return $d&&$d->format('Y-m-d')===$v?$d:false;}
function lux_today(){return wp_date('Y-m-d');}
function lux_period_days($r){return (int)lux_ymd($r['from'])->diff(lux_ymd($r['to']))->days+1;}
function lux_clean_rates($rows,&$rejected=0){
 $clean=[];$rejected=0;
 foreach((array)$rows as $r){
  if(!is_array($r))continue;$from=trim((string)($r['from']??''));$to=trim((string)($r['to']??''));$price=trim((string)($r['price']??''));
  if($from===''&&$to===''&&$price==='')continue;
  if(!lux_ymd($from)||!lux_ymd($to)||$to<$from||!is_numeric($price)||$price<0){$rejected++;continue;}
  $clean[]=['from'=>$from,'to'=>$to,'price'=>(int)round((float)$price),'label'=>mb_substr(sanitize_text_field((string)($r['label']??'')),0,60)];
 }
 usort($clean,fn($a,$b)=>[$a['from'],$a['to']]<=>[$b['from'],$b['to']]);return $clean;
}
function lux_rates($id){$r=get_post_meta($id,'_lux_rates',true);return is_array($r)?lux_clean_rates($r):[];}
function lux_upcoming_rates($id){$today=lux_today();return array_values(array_filter(lux_rates($id),fn($r)=>$r['to']>=$today));}

function lux_rate_for_night($base,$rates,$night){
 $best=null;$bestDays=PHP_INT_MAX;
 foreach($rates as $r)if($r['from']<=$night&&$night<=$r['to']){$days=lux_period_days($r);if($days<=$bestDays){$best=$r;$bestDays=$days;}}
 return $best?['price'=>(float)$best['price'],'label'=>$best['label']]:['price'=>(float)$base,'label'=>''];
}
// Returns nights, total, average and consecutive segments that share a rate. `on_request` means at least one night has no price.
function lux_quote($base,$rates,$checkin,$checkout){
 $in=lux_ymd($checkin);$out=lux_ymd($checkout);if(!$in||!$out||$out<=$in)return null;
 $total=0;$nights=0;$segments=[];$onRequest=false;
 for($d=$in;$d<$out;$d=$d->modify('+1 day')){
  $night=$d->format('Y-m-d');$rate=lux_rate_for_night($base,$rates,$night);$nights++;$total+=$rate['price'];if($rate['price']<=0)$onRequest=true;
  $last=count($segments)-1;
  if($last>=0&&$segments[$last]['price']===$rate['price']&&$segments[$last]['label']===$rate['label']){$segments[$last]['nights']++;$segments[$last]['to']=$night;}
  else $segments[]=['from'=>$night,'to'=>$night,'nights'=>1,'price'=>$rate['price'],'label'=>$rate['label']];
 }
 return ['nights'=>$nights,'total'=>$total,'average'=>$nights?round($total/$nights):0,'segments'=>$segments,'on_request'=>$onRequest];
}
// Lowest nightly rate a guest can still book: the base rate and any period that has not ended.
function lux_from_price($base,$rates){$prices=array_filter(array_merge([(float)$base],array_map(fn($r)=>(float)$r['price'],$rates)),fn($p)=>$p>0);return $prices?min($prices):0;}
// Prices are stored and shown in Georgian lari (GEL).
// One-time switch of existing sites from USD: base and seasonal rates are converted at the official NBG rate
// of 29 Sep 2026 and rounded to 5 GEL. add_option is atomic, so parallel requests cannot convert twice.
const LUX_USD_GEL=2.6055;
function lux_usd_to_gel($usd){return (int)(round((float)$usd*LUX_USD_GEL/5)*5);}
function lux_migrate_prices_to_gel(){
 if(get_option('lux_price_currency')==='GEL'||!function_exists('lux_room_type')||!add_option('lux_price_currency','GEL'))return;
 foreach(get_posts(['post_type'=>lux_room_type(),'post_status'=>['publish','draft','pending','private','future','trash'],'numberposts'=>-1,'fields'=>'ids']) as $id){
  $p=get_post_meta($id,'_lux_price',true);if($p!==''&&$p!==false)update_post_meta($id,'_lux_price',lux_usd_to_gel($p));
  $r=get_post_meta($id,'_lux_rates',true);if(is_array($r)&&$r){foreach($r as &$x)if(isset($x['price']))$x['price']=lux_usd_to_gel($x['price']);unset($x);update_post_meta($id,'_lux_rates',$r);}
 }
}
add_action('init','lux_migrate_prices_to_gel',40);
function lux_money($v){$v=round((float)$v,2);return number_format($v,floor($v)==$v?0:2).' GEL';}
function lux_short_date($ymd){$d=lux_ymd($ymd);return $d?$d->format('j M Y'):$ymd;}

// Apartment editor: one row per period.
add_action('add_meta_boxes',function(){add_meta_box('lux-rates','Seasonal rates','lux_rates_box',lux_room_type(),'normal','high');});
function lux_rate_row($i,$r=[]){$today=lux_today();$ended=!empty($r['to'])&&$r['to']<$today;?>
<tr class="lux-rate-row<?php echo $ended?' is-ended':'';?>">
 <td><input type="date" name="lux_rates[<?php echo esc_attr($i);?>][from]" value="<?php echo esc_attr($r['from']??'');?>" aria-label="First night"></td>
 <td><input type="date" name="lux_rates[<?php echo esc_attr($i);?>][to]" value="<?php echo esc_attr($r['to']??'');?>" aria-label="Last night"></td>
 <td><input type="number" min="0" step="1" name="lux_rates[<?php echo esc_attr($i);?>][price]" value="<?php echo esc_attr($r['price']??'');?>" aria-label="Nightly rate in GEL" style="width:110px"></td>
 <td><input type="text" maxlength="60" name="lux_rates[<?php echo esc_attr($i);?>][label]" value="<?php echo esc_attr($r['label']??'');?>" placeholder="e.g. High season" aria-label="Season name" class="widefat"></td>
 <td><?php if($ended)echo '<span class="lux-rate-ended">Ended</span>';?><button type="button" class="button-link lux-rate-remove" aria-label="Remove period">Remove</button></td>
</tr><?php }
function lux_rates_box($post){
 $rates=lux_rates($post->ID);$base=(float)get_post_meta($post->ID,'_lux_price',true);
 $overlaps=[];for($i=0;$i<count($rates);$i++)for($j=$i+1;$j<count($rates);$j++)if($rates[$j]['from']<=$rates[$i]['to']&&$rates[$i]['from']<=$rates[$j]['to'])$overlaps[]=lux_short_date($rates[$i]['from']).'–'.lux_short_date($rates[$i]['to']).' and '.lux_short_date($rates[$j]['from']).'–'.lux_short_date($rates[$j]['to']);
 ?><style>#lux-rates table{border-collapse:collapse;width:100%;margin:10px 0}#lux-rates th{text-align:left;font-weight:600;padding:6px 8px 6px 0}#lux-rates td{padding:6px 8px 6px 0;vertical-align:middle}#lux-rates .is-ended input{opacity:.55}.lux-rate-ended{display:inline-block;margin-right:10px;padding:2px 7px;border-radius:3px;background:#f0f0f1;color:#646970;font-size:11px}.lux-rate-remove{color:#b32d2e}</style>
 <p>Set nightly rates in Georgian lari (GEL) for any period ahead. Each night of a stay is priced by the period it falls in, so a stay across two seasons is charged accordingly. Nights outside every period use the base rate from Apartment details (<?php echo $base>0?esc_html(lux_money($base)):'not set — shown as “Rate on request”';?>).</p>
 <p>“Last night” is the final night charged: for a period from 1 October to 30 November, a guest leaving on 1 December pays the seasonal rate for every night. If periods overlap, the shorter period wins. The season name is shown to guests in the price breakdown.</p>
 <?php if($overlaps)echo '<div class="notice notice-info inline"><p>Overlapping periods (the shorter one applies): '.esc_html(implode('; ',$overlaps)).'</p></div>';?>
 <input type="hidden" name="lux_rates_present" value="1">
 <table><thead><tr><th>First night</th><th>Last night</th><th>Rate / night (GEL)</th><th>Season name (optional)</th><th></th></tr></thead><tbody id="lux-rate-rows"><?php foreach($rates as $i=>$r)lux_rate_row($i,$r);if(!$rates)lux_rate_row(0);?></tbody></table>
 <template id="lux-rate-template"><?php lux_rate_row('__i__');?></template>
 <p><button type="button" class="button" id="lux-add-rate">Add period</button> <a href="<?php echo esc_url(admin_url('admin.php?page=luxury-rates'));?>">Edit seasons for several apartments</a></p><?php
}
add_action('save_post',function($id){
 if(!isset($_POST['lux_rates_present'],$_POST['lux_apartment_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['lux_apartment_nonce'])),'lux_apartment')||!current_user_can('edit_post',$id)||get_post_type($id)!==lux_room_type()||wp_is_post_revision($id)||wp_is_post_autosave($id))return;
 $rates=lux_clean_rates(wp_unslash($_POST['lux_rates']??[]),$rejected);update_post_meta($id,'_lux_rates',$rates);
 if($rejected)set_transient('lux_rates_notice_'.get_current_user_id(),$rejected,60);
},20);
add_action('admin_notices',function(){$key='lux_rates_notice_'.get_current_user_id();$n=(int)get_transient($key);if(!$n)return;delete_transient($key);echo '<div class="notice notice-warning is-dismissible"><p>'.esc_html(sprintf(_n('%d seasonal rate was not saved: check that it has both dates, the last night is not before the first, and a rate of 0 or more.','%d seasonal rates were not saved: check that each has both dates, the last night is not before the first, and a rate of 0 or more.',$n),$n)).'</p></div>';});

// Several apartments at once: add a season (fixed rate or % of each base rate) or remove periods with exact dates.
add_action('admin_menu',function(){add_submenu_page('luxury-setup','Seasonal rates','Seasonal rates','manage_options','luxury-rates','lux_rates_page');});
function lux_rates_page(){
 if(!current_user_can('manage_options'))return;$posts=lux_catalog_posts();$done=isset($_GET['lux_done'])?sanitize_text_field(wp_unslash($_GET['lux_done'])):'';
 ?><div class="wrap"><h1>Seasonal rates</h1>
 <?php if($done)echo '<div class="notice notice-success is-dismissible"><p>'.esc_html($done).'</p></div>';?>
 <p>Plan prices ahead for several apartments at once. To fine-tune one apartment, open it and edit its Seasonal rates.</p>
 <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="background:#fff;border:1px solid #c3c4c7;padding:16px 20px;max-width:980px">
 <input type="hidden" name="action" value="lux_bulk_rates"><?php wp_nonce_field('lux_bulk_rates');?>
 <?php $src=[];foreach($posts as $p){$u=lux_upcoming_rates($p->ID);if($u)$src[$p->ID]=['title'=>get_the_title($p),'rates'=>$u];}?>
 <h2 style="margin-top:0">Seasons</h2>
 <p style="color:#50575e">Add as many periods as you need, tick the apartments below and save — every ticked apartment gets all these periods. A period with the same dates already in an apartment is replaced; its other periods stay. “Last night” is the final night charged.</p>
 <?php if($src){?><p><label>Copy periods from <select id="lux-bulk-copy"><option value="">— choose an apartment —</option><?php foreach($src as $id=>$s)echo '<option value="'.(int)$id.'">'.esc_html($s['title'].' ('.count($s['rates']).')').'</option>';?></select></label> <span style="color:#646970">then change rates or dates if needed</span></p><?php }?>
 <style>#lux-bulk-table{border-collapse:collapse;margin:6px 0}#lux-bulk-table th{text-align:left;font-weight:600;padding:4px 10px 4px 0}#lux-bulk-table td{padding:4px 10px 4px 0}.lux-bulk-remove{color:#b32d2e}</style>
 <div style="overflow-x:auto;max-width:100%"><table id="lux-bulk-table"><thead><tr><th>First night</th><th>Last night</th><th id="lux-bulk-rate-head">Rate / night (GEL)</th><th>Season name (optional)</th><th></th></tr></thead><tbody id="lux-bulk-rows"></tbody></table></div>
 <template id="lux-bulk-template"><tr><td><input type="date" name="rows[__i__][from]" aria-label="First night"></td><td><input type="date" name="rows[__i__][to]" aria-label="Last night"></td><td><input type="number" step="1" min="0" name="rows[__i__][price]" class="lux-bulk-price" style="width:110px" aria-label="Rate"></td><td><input type="text" maxlength="60" name="rows[__i__][label]" placeholder="e.g. High season" style="width:220px" aria-label="Season name"></td><td><button type="button" class="button-link lux-bulk-remove">Remove</button></td></tr></template>
 <p><button type="button" class="button" id="lux-bulk-add">Add period</button></p>
 <p><label><input type="radio" name="kind" value="fixed" checked> Rates in GEL per night — the same for every ticked apartment</label><br><label><input type="radio" name="kind" value="percent"> Rates as % change of each apartment’s own base rate (e.g. 20 for +20%, -15 for −15%)</label></p>
 <h2>Apartments</h2>
 <?php foreach(['batumi'=>'Batumi','gudauri'=>'New Gudauri'] as $city=>$name){$list=array_filter($posts,fn($p)=>get_post_meta($p->ID,'_lux_city',true)===$city);if(!$list)continue;?>
 <fieldset style="margin:0 0 14px"><legend><strong><?php echo esc_html($name);?></strong> · <label><input type="checkbox" class="lux-check-city" data-city="<?php echo esc_attr($city);?>"> all</label></legend>
 <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:4px 16px;margin-top:6px"><?php foreach($list as $p){$base=(float)get_post_meta($p->ID,'_lux_price',true);?><label><input type="checkbox" name="apartments[]" value="<?php echo (int)$p->ID;?>" data-city="<?php echo esc_attr($city);?>"> <?php echo esc_html(get_the_title($p));?> <span style="color:#646970">(base <?php echo $base>0?esc_html(lux_money($base)):'—';?>)</span></label><?php }?></div></fieldset><?php }?>
 <p><button class="button button-primary" name="mode" value="add" id="lux-bulk-save">Save these periods to selected apartments</button> <button class="button" name="mode" value="remove" id="lux-bulk-del">Remove periods with these exact dates</button></p>
 </form>
 <h2>Upcoming rates</h2>
 <table class="widefat striped" style="max-width:980px"><thead><tr><th>Apartment</th><th>Base / night</th><th>Periods</th></tr></thead><tbody><?php foreach($posts as $p){$rates=lux_upcoming_rates($p->ID);$base=(float)get_post_meta($p->ID,'_lux_price',true);?><tr><td><a href="<?php echo esc_url(get_edit_post_link($p->ID));?>"><?php echo esc_html(get_the_title($p));?></a></td><td><?php echo $base>0?esc_html(lux_money($base)):'—';?></td><td><?php echo $rates?implode('<br>',array_map(fn($r)=>esc_html(lux_short_date($r['from']).' – '.lux_short_date($r['to']).' · '.lux_money($r['price']).($r['label']?' · '.$r['label']:'')),$rates)):'<span style="color:#646970">Base rate all year</span>';?></td></tr><?php }?></tbody></table>
 <script>(()=>{
 document.querySelectorAll('.lux-check-city').forEach(c=>c.addEventListener('change',()=>document.querySelectorAll('input[name="apartments[]"][data-city="'+c.dataset.city+'"]').forEach(b=>b.checked=c.checked)));
 const SRC=<?php echo wp_json_encode(array_map(fn($s)=>$s['rates'],$src));?>,rows=document.getElementById('lux-bulk-rows'),tpl=document.getElementById('lux-bulk-template'),form=rows.closest('form');let next=0;
 const add=(r={})=>{rows.insertAdjacentHTML('beforeend',tpl.innerHTML.replace(/__i__/g,String(next++)));const tr=rows.lastElementChild,f=tr.querySelectorAll('input');f[0].value=r.from||'';f[1].value=r.to||'';f[2].value=r.price??'';f[3].value=r.label||'';percent();return tr;};
 const filled=()=>[...rows.children].filter(tr=>[...tr.querySelectorAll('input')].some(i=>i.value.trim()!==''));
 const percent=()=>{const p=form.querySelector('input[name=kind][value=percent]').checked;document.getElementById('lux-bulk-rate-head').textContent=p?'Change of base rate (%)':'Rate / night (GEL)';rows.querySelectorAll('.lux-bulk-price').forEach(i=>{i.min=p?-90:0;i.max=p?500:'';});};
 form.querySelectorAll('input[name=kind]').forEach(r=>r.addEventListener('change',percent));
 document.getElementById('lux-bulk-add').addEventListener('click',()=>{const prev=rows.lastElementChild,tr=add(),from=tr.querySelector('input[type=date]');const to=prev&&prev.querySelectorAll('input[type=date]')[1].value;if(to){const d=new Date(to+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+1);from.value=d.toISOString().slice(0,10);}from.focus();});
 rows.addEventListener('click',e=>{const b=e.target.closest('.lux-bulk-remove');if(b){b.closest('tr').remove();if(!rows.children.length)add();}});
 const copy=document.getElementById('lux-bulk-copy');if(copy)copy.addEventListener('change',()=>{const list=SRC[copy.value];if(!list)return;if(filled().length&&!confirm('Replace the periods in the table with the periods of '+copy.options[copy.selectedIndex].text+'?')){copy.value='';return;}form.querySelector('input[name=kind][value=fixed]').checked=true;rows.innerHTML='';list.forEach(add);copy.value='';});
 for(let i=0;i<3;i++)add();
 const ticked=()=>form.querySelectorAll('input[name="apartments[]"]:checked').length;
 document.getElementById('lux-bulk-save').addEventListener('click',e=>{const n=filled().length,a=ticked();if(!n){e.preventDefault();alert('Add at least one period.');return;}if(!a){e.preventDefault();alert('Tick at least one apartment.');return;}if(!confirm('Save '+n+' period(s) to '+a+' apartment(s)?'))e.preventDefault();});
 document.getElementById('lux-bulk-del').addEventListener('click',e=>{const n=filled().filter(tr=>{const d=tr.querySelectorAll('input[type=date]');return d[0].value&&d[1].value;}).length,a=ticked();if(!n){e.preventDefault();alert('Enter the first and last night of the periods to remove.');return;}if(!a){e.preventDefault();alert('Tick at least one apartment.');return;}if(!confirm('Remove periods with exactly these '+n+' date range(s) from '+a+' apartment(s)?'))e.preventDefault();});
 })();</script>
 </div><?php
}
add_action('admin_post_lux_bulk_rates',function(){
 if(!current_user_can('manage_options'))wp_die('Not allowed',403);check_admin_referer('lux_bulk_rates');
 $back=function($msg){wp_safe_redirect(add_query_arg('lux_done',rawurlencode($msg),admin_url('admin.php?page=luxury-rates')));exit;};
 $mode=($_POST['mode']??'')==='remove'?'remove':'add';$kind=($_POST['kind']??'')==='percent'?'percent':'fixed';
 $ids=array_filter(array_map('absint',(array)($_POST['apartments']??[])),fn($id)=>get_post_type($id)===lux_room_type());
 // Read every filled row first; one wrong row changes nothing, so no apartment ends up half-updated.
 $rows=[];$bad=[];$n=0;
 foreach((array)wp_unslash($_POST['rows']??[]) as $r){
  if(!is_array($r))continue;$from=trim((string)($r['from']??''));$to=trim((string)($r['to']??''));$price=trim((string)($r['price']??''));$label=mb_substr(sanitize_text_field((string)($r['label']??'')),0,60);
  if($from===''&&$to===''&&$price===''&&$label==='')continue;$n++;
  $datesOk=lux_ymd($from)&&lux_ymd($to)&&$to>=$from;
  $priceOk=is_numeric($price)&&($kind==='fixed'?$price>=0:($price>=-90&&$price<=500));
  if(!$datesOk||($mode==='add'&&!$priceOk)){$bad[]=$n;continue;}
  $rows[]=['from'=>$from,'to'=>$to,'price'=>(float)$price,'label'=>$label];
 }
 if($bad)return $back(sprintf('Nothing changed: check period %s — it needs a first and last night (last on or after first) and %s.',implode(', ',$bad),$kind==='fixed'?'a rate of 0 or more':'a percentage between -90 and 500'));
 if(!$rows)return $back('Nothing changed: add at least one period.');
 if(!$ids)return $back('Nothing changed: select at least one apartment.');
 $same=fn($a,$b)=>$a['from']===$b['from']&&$a['to']===$b['to'];$changed=0;
 if($mode==='remove'){$removed=0;foreach($ids as $id){$rates=lux_rates($id);$kept=array_values(array_filter($rates,function($r)use($rows,$same){foreach($rows as $x)if($same($r,$x))return false;return true;}));if(count($kept)!==count($rates)){update_post_meta($id,'_lux_rates',$kept);$changed++;$removed+=count($rates)-count($kept);}}return $back(sprintf('Removed %d period(s) from %d apartment(s).',$removed,$changed));}
 $skipped=0;
 foreach($ids as $id){
  $base=(float)get_post_meta($id,'_lux_price',true);if($kind==='percent'&&$base<=0){$skipped++;continue;}
  $rates=array_values(array_filter(lux_rates($id),function($r)use($rows,$same){foreach($rows as $x)if($same($r,$x))return false;return true;}));
  foreach($rows as $x)$rates[]=['from'=>$x['from'],'to'=>$x['to'],'price'=>round($kind==='fixed'?$x['price']:$base*(1+$x['price']/100)),'label'=>$x['label']];
  update_post_meta($id,'_lux_rates',lux_clean_rates($rates));$changed++;
 }
 return $back(sprintf('Saved %d period(s) to %d apartment(s).',count($rows),$changed).($skipped?sprintf(' %d skipped: no base rate to apply a percentage to.',$skipped):''));
});
