(()=>{'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>Array.from(r.querySelectorAll(s));
document.documentElement.classList.add('lx-js');

// Sticky section tabs sit just below the sticky header.
const header=$('.site-header');
// Keep the section tabs pinned exactly below the sticky header (header height can change on scroll / with the admin bar).
const setHeader=()=>document.documentElement.style.setProperty('--lx-header',Math.max(0,header?header.getBoundingClientRect().bottom:0)+'px');
setHeader();addEventListener('resize',setHeader);addEventListener('scroll',setHeader,{passive:true});

const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches,reveal=$$('.lx-reveal');
if(reduced||!('IntersectionObserver' in window))reveal.forEach(e=>e.setAttribute('data-enter',''));
else{const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.setAttribute('data-enter','');io.unobserve(e.target);}}),{threshold:.08});reveal.forEach(e=>io.observe(e));}

// Package type filter on the Zanzibar collection.
$$('[data-lx-filter]').forEach(button=>button.addEventListener('click',()=>{const type=button.dataset.lxFilter;
 $$('[data-lx-filter]').forEach(b=>{const on=b===button;b.classList.toggle('is-active',on);b.setAttribute('aria-pressed',String(on));});
 $$('.lx-card').forEach(card=>{card.hidden=!!type&&!card.dataset.types.split(' ').includes(type);if(!card.hidden)card.setAttribute('data-enter','');});}));

const tabs=$$('.lx-tabs a');
if(tabs.length&&'IntersectionObserver' in window){const byId=new Map(tabs.map(a=>[a.getAttribute('href').slice(1),a]));
 const spy=new IntersectionObserver(entries=>entries.forEach(e=>{if(!e.isIntersecting)return;tabs.forEach(a=>a.classList.remove('is-current'));byId.get(e.target.id)?.classList.add('is-current');}),{rootMargin:'-40% 0px -55% 0px'});
 byId.forEach((a,id)=>{const section=document.getElementById(id);if(section)spy.observe(section);});}

// "Request availability" — one form for tours, packages and concierge.
const dialog=$('#lx-request-dialog'),form=$('#lx-request-form'),config=window.LUX_CATALOG||{};
if(!dialog||!form)return;
let target='',requestKey='',pending=false,trigger=null,previousOverflow='';
const newKey=()=>crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
document.addEventListener('click',event=>{const button=event.target.closest('[data-lx-request]');if(!button)return;
 target=button.dataset.lxRequest;requestKey=newKey();trigger=button;
 $('#lx-request-for').textContent=`${button.dataset.lxTitle}. Share your preferred dates and our team will reply with availability and a tailored proposal.`;
 $('#lx-request-body').hidden=false;$('#lx-request-success').hidden=true;$('#lx-request-error').hidden=true;
 previousOverflow=document.body.style.overflow;document.body.style.overflow='hidden';dialog.showModal();});
dialog.addEventListener('click',e=>{if(pending)return;if(e.target.closest('[data-lx-close]')){dialog.close();return;}
 if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});
dialog.addEventListener('cancel',e=>{if(pending)e.preventDefault();});
dialog.addEventListener('close',()=>{document.body.style.overflow=previousOverflow;trigger?.focus();});
form.addEventListener('submit',async event=>{event.preventDefault();if(pending||!form.reportValidity())return;
 const error=$('#lx-request-error'),submit=$('.lx-submit',form),label=submit.innerHTML;error.hidden=true;pending=true;submit.textContent='Sending your request…';
 const data=new FormData(form);
 const payload={requestKey,experience:target,name:data.get('name'),email:data.get('email'),phone:data.get('phone'),dates:data.get('dates'),guests:data.get('guests')?Number(data.get('guests')):null,notes:data.get('notes'),website:data.get('website'),consent:data.get('consent')==='on'};
 $$('input,textarea,button',form).forEach(e=>e.disabled=true);
 try{const tokenResponse=await fetch(config.tokenEndpoint,{credentials:'same-origin',headers:{'X-WP-Nonce':config.restNonce},cache:'no-store'});
  if(!tokenResponse.ok)throw new Error('Your session has expired. Please reload the page and try again.');
  payload.nonce=(await tokenResponse.json()).nonce;
  const response=await fetch(form.dataset.endpoint,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':config.restNonce},body:JSON.stringify(payload)});
  const result=await response.json();if(!response.ok)throw new Error(result.message||'We could not save your request. Please try again.');
  $('#lx-request-body').hidden=true;$('#lx-request-success').hidden=false;
  $('#lx-success-copy').textContent=result.demo?'Your test request is saved in Booking requests in this demo’s WordPress admin. No email was sent.':'Your request has been saved. Our team will contact you with availability and a tailored proposal.';
  $('#lx-reference').textContent='REFERENCE '+result.reference;form.reset();$('#lx-request-success').focus();
 }catch(e){error.textContent=e.message||'Unable to connect. Please try again.';error.hidden=false;}
 finally{pending=false;$$('input,textarea,button',form).forEach(e=>e.disabled=false);submit.innerHTML=label;}});
})();
