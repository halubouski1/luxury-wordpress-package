<?php
if(!defined('ABSPATH'))exit;
// Approximate prices in other currencies. Prices and payment stay in GEL; guests can also see USD, EUR or GBP
// converted at the official National Bank of Georgia rate, refreshed twice a day with the last good rate kept as fallback.

function lux_fx_currencies(){return ['USD'=>'$','EUR'=>'€','GBP'=>'£'];}
function lux_fx_rates(){
 $cached=get_transient('lux_fx_rates');if(is_array($cached))return $cached;
 $fallback=get_option('lux_fx_last')?:['date'=>'2026-09-29','source'=>'NBG','rates'=>['USD'=>2.6055,'EUR'=>2.9632,'GBP'=>3.4541]];
 $url='https://nbg.gov.ge/gw/api/ct/monetarypolicy/currencies/en/json/?'.implode('&',array_map(fn($c)=>'currencies='.$c,array_keys(lux_fx_currencies())));
 $res=wp_remote_get($url,['timeout'=>6]);$data=is_wp_error($res)?null:json_decode(wp_remote_retrieve_body($res),true);
 $rates=[];foreach(($data[0]['currencies']??[]) as $c)if(isset(lux_fx_currencies()[$c['code']??''])&&($c['rate']??0)>0)$rates[$c['code']]=(float)$c['rate']/max(1,(int)($c['quantity']??1));
 if(count($rates)===count(lux_fx_currencies())){$fx=['date'=>substr((string)($data[0]['date']??wp_date('Y-m-d')),0,10),'source'=>'NBG','rates'=>$rates];update_option('lux_fx_last',$fx,false);set_transient('lux_fx_rates',$fx,12*HOUR_IN_SECONDS);return $fx;}
 set_transient('lux_fx_rates',$fallback,HOUR_IN_SECONDS);return $fallback;
}
function lux_fx_payload(){$fx=lux_fx_rates();$out=['date'=>$fx['date'],'currencies'=>[]];foreach(lux_fx_currencies() as $code=>$sym)$out['currencies'][$code]=['symbol'=>$sym,'rate'=>$fx['rates'][$code]??null];return $out;}
