<?php
if(!defined('ABSPATH'))exit;
// Booking extras and payment split: breakfast per guest per night, airport transfers (private sedan), 30% deposit or full payment.
// Amounts are recalculated here on submit; the browser figures are only a preview. No card payment is taken on the site.

function lux_extras_defaults(){return ['breakfast'=>26,'deposit'=>30,'sedan_max'=>4,'routes'=>"Batumi Airport ↔ Batumi Hotel | 40\nKutaisi Airport ↔ Batumi | 315\nTbilisi Airport ↔ Batumi | 520\nTbilisi Airport ↔ Gudauri | 315"];}
function lux_booking_extras(){
 $s=array_merge(lux_extras_defaults(),array_filter((array)get_option('lux_booking_extras',[]),fn($v)=>$v!==''&&$v!==null));
 $routes=[];foreach(preg_split('/\R/',(string)$s['routes']) as $line){$parts=array_map('trim',explode('|',$line));if(count($parts)<2||$parts[0]===''||!is_numeric($parts[1]))continue;$routes[]=['id'=>trim(preg_replace('/[^a-z0-9]+/','-',strtolower(remove_accents($parts[0]))),'-'),'name'=>$parts[0],'price'=>(int)round((float)$parts[1])];}
 return ['breakfast'=>max(0,(int)$s['breakfast']),'deposit'=>min(100,max(1,(int)$s['deposit'])),'sedan_max'=>max(1,(int)$s['sedan_max']),'routes'=>$routes];
}
// $accommodation: total of all apartments or null when any is on request.
function lux_booking_breakdown($accommodation,$nights,$guests,$breakfastGuests,$route,$trip,$option){
 $x=lux_booking_extras();$complete=$accommodation!==null;
 $breakfast=['guests'=>$breakfastGuests,'nights'=>$nights,'price'=>$x['breakfast'],'total'=>$breakfastGuests*$nights*$x['breakfast']];
 $transfer=null;foreach($x['routes'] as $r)if($r['id']===$route){$onRequest=$guests>$x['sedan_max'];$transfer=['id'=>$r['id'],'name'=>$r['name'],'trip'=>$trip,'price'=>$r['price'],'total'=>$onRequest?null:$r['price']*($trip==='round'?2:1),'on_request'=>$onRequest];if($onRequest)$complete=false;}
 $total=$complete?(int)round($accommodation+$breakfast['total']+($transfer['total']??0)):null;
 $pct=$option==='full'?100:$x['deposit'];$due=$total===null?null:(int)round($total*$pct/100);
 return ['accommodation'=>$accommodation,'breakfast'=>$breakfast,'transfer'=>$transfer,'total'=>$total,'payment'=>['option'=>$option,'percent'=>$pct,'due_now'=>$due,'deposit'=>$option==='full'?0:$due,'balance'=>$total===null?null:$total-$due]];
}

add_action('admin_menu',function(){add_submenu_page('luxury-setup','Booking extras','Booking extras','manage_options','luxury-extras','lux_extras_page');});
function lux_extras_page(){
 if(!current_user_can('manage_options'))return;$saved=(array)get_option('lux_booking_extras',[]);$d=lux_extras_defaults();$x=lux_booking_extras();
 ?><div class="wrap"><h1>Booking extras</h1><?php if(isset($_GET['updated']))echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';?>
 <p>Services guests can add in the booking request form, and the payment split shown with the total. All prices in Georgian lari (GEL). Empty fields use the value in grey.</p>
 <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="max-width:760px"><input type="hidden" name="action" value="lux_extras"><?php wp_nonce_field('lux_extras');?>
 <table class="form-table" role="presentation">
 <tr><th scope="row"><label for="lux-breakfast">Breakfast</label></th><td><input id="lux-breakfast" name="breakfast" type="number" min="0" step="1" value="<?php echo esc_attr($saved['breakfast']??'');?>" placeholder="<?php echo esc_attr($d['breakfast']);?>" style="width:100px"> GEL per guest per night</td></tr>
 <tr><th scope="row"><label for="lux-routes">Transfer routes</label></th><td><textarea id="lux-routes" name="routes" rows="6" class="large-text code" placeholder="<?php echo esc_attr($d['routes']);?>"><?php echo esc_textarea($saved['routes']??'');?></textarea><p class="description">One route per line: <code>Route name | price</code>. Price is one way, for a private sedan; round trip is charged twice.</p></td></tr>
 <tr><th scope="row"><label for="lux-sedan">Sedan capacity</label></th><td><input id="lux-sedan" name="sedan_max" type="number" min="1" max="20" step="1" value="<?php echo esc_attr($saved['sedan_max']??'');?>" placeholder="<?php echo esc_attr($d['sedan_max']);?>" style="width:80px"> guests. Larger groups see “Private minivan — price on request”.</td></tr>
 <tr><th scope="row"><label for="lux-deposit">Deposit</label></th><td><input id="lux-deposit" name="deposit" type="number" min="1" max="100" step="1" value="<?php echo esc_attr($saved['deposit']??'');?>" placeholder="<?php echo esc_attr($d['deposit']);?>" style="width:80px"> % of the total, shown as the deposit option.</td></tr>
 </table><?php submit_button('Save booking extras');?></form>
 <h2>Current routes</h2><ul style="list-style:disc;padding-left:20px"><?php foreach($x['routes'] as $r)echo '<li>'.esc_html($r['name'].' — '.lux_money($r['price']).' one way').'</li>';?></ul></div><?php
}
add_action('admin_post_lux_extras',function(){
 if(!current_user_can('manage_options'))wp_die('Not allowed',403);check_admin_referer('lux_extras');
 $in=wp_unslash($_POST);$out=[];foreach(['breakfast','deposit','sedan_max'] as $k)$out[$k]=($in[$k]??'')===''?'':absint($in[$k]);$out['routes']=sanitize_textarea_field($in['routes']??'');
 update_option('lux_booking_extras',$out);wp_safe_redirect(admin_url('admin.php?page=luxury-extras&updated=1'));exit;
});
