<?php
if(!defined('ABSPATH'))exit;
// One availability calendar for the website and the admin (Asia/Tbilisi dates).
// A period [from, until) closes the nights from `from` up to the night before `until`: a new stay may start on `until`,
// and a guest may check out on `from`. Sources: manual blocks, confirmed bookings and bookings that are waiting for their
// online prepayment while the hold is active. Availability is computed from these periods, never from a "closed" switch,
// so the dates after a block are bookable at once and nothing has to be reopened by hand.

const LUX_BLOCK_REASONS=['external'=>'External booking (other channel)','direct'=>'Direct booking','owner'=>'Owner stay','maintenance'=>'Maintenance / technical block'];
const LUX_HOLD_MINUTES=75; // Flitt payment page lives 60 minutes; the extra time covers a late bank notification.

function lux_blocks($id){
 $raw=get_post_meta($id,'_lux_closed',true);if(!is_array($raw))return [];$out=[];
 foreach($raw as $i=>$r){if(!is_array($r))continue;$f=(string)($r['from']??$r[0]??'');$t=(string)($r['until']??$r[1]??'');if(!lux_ymd($f)||!lux_ymd($t)||$t<=$f)continue;
  $out[]=['key'=>(string)($r['key']??substr(md5($f.$t.$i),0,10)),'from'=>$f,'until'=>$t,'reason'=>isset(LUX_BLOCK_REASONS[$r['reason']??''])?$r['reason']:'external','comment'=>(string)($r['comment']??''),'by'=>(int)($r['by']??0),'at'=>(string)($r['at']??'')];}
 usort($out,fn($a,$b)=>strcmp($a['from'],$b['from']));return $out;
}
// Bookings that occupy apartments: confirmed ones, and online bookings waiting for payment until the hold ends.
function lux_occupying_bookings(){
 $ids=get_posts(['post_type'=>'lux_booking','post_status'=>'private','numberposts'=>-1,'fields'=>'ids','meta_query'=>[['key'=>'_lux_status','value'=>['confirmed','awaiting_payment'],'compare'=>'IN']]]);
 $today=wp_date('Y-m-d');$out=[];
 foreach($ids as $b){$d=get_post_meta($b,'_lux_request',true);if(!is_array($d)||($d['kind']??'')==='experience'||($d['checkout']??'')<=$today)continue;
  $st=get_post_meta($b,'_lux_status',true);if($st==='awaiting_payment'&&(int)get_post_meta($b,'_lux_hold_until',true)<time())continue;
  foreach(($d['apartments']??[]) as $a)$out[]=['apt'=>(int)$a['id'],'from'=>$d['checkin'],'until'=>$d['checkout'],'type'=>$st==='confirmed'?'booking':'hold','ref'=>$d['reference'],'booking'=>(int)$b];}
 return $out;
}
// Every busy period of one apartment that has not ended. $exclude: a booking that must not block itself.
function lux_busy($aptId,$exclude=0,$withBlocks=true){
 $today=wp_date('Y-m-d');$out=[];
 if($withBlocks)foreach(lux_blocks($aptId) as $b)if($b['until']>$today)$out[]=['from'=>$b['from'],'until'=>$b['until'],'type'=>'block','ref'=>LUX_BLOCK_REASONS[$b['reason']],'key'=>$b['key']];
 foreach(lux_occupying_bookings() as $o)if($o['apt']===(int)$aptId&&$o['booking']!==(int)$exclude)$out[]=$o;
 usort($out,fn($a,$b)=>strcmp($a['from'],$b['from']));return $out;
}
// Overlap rule: requested_check_in < busy_until and requested_check_out > busy_from.
function lux_conflicts($aptId,$in,$out,$exclude=0,$withBlocks=true){return array_values(array_filter(lux_busy($aptId,$exclude,$withBlocks),fn($r)=>$in<$r['until']&&$out>$r['from']));}
function lux_booking_conflicts($bookingId){$d=get_post_meta($bookingId,'_lux_request',true);$c=[];foreach(($d['apartments']??[]) as $a)foreach(lux_conflicts((int)$a['id'],$d['checkin'],$d['checkout'],$bookingId) as $r)$c[]=$a['title'].': '.$r['from'].' – '.$r['until'].' ('.($r['type']==='block'?'blocked':$r['ref']).')';return $c;}
// Holds the apartments of an online booking while the guest pays.
function lux_hold($bookingId){update_post_meta($bookingId,'_lux_hold_until',time()+LUX_HOLD_MINUTES*MINUTE_IN_SECONDS);}
// Serialises "check, then occupy" so two guests cannot take the same nights at the same moment.
function lux_availability_lock(){for($i=0;$i<50&&!add_option('lux_avail_lock',time(),'','no');$i++){if((int)get_option('lux_avail_lock')<time()-20)delete_option('lux_avail_lock');usleep(100000);}}
function lux_availability_unlock(){delete_option('lux_avail_lock');}

// ---------- Admin: Luxury Setup → Availability ----------
add_action('admin_menu',function(){add_submenu_page('luxury-setup','Availability calendar','Availability','edit_posts','luxury-availability','lux_availability_page');});
function lux_block_log($id,$action,$b){$log=get_post_meta($id,'_lux_block_log',true);$log=is_array($log)?$log:[];$log[]=['action'=>$action,'from'=>$b['from'],'until'=>$b['until'],'reason'=>$b['reason'],'comment'=>$b['comment'],'by'=>get_current_user_id(),'at'=>current_time('mysql')];update_post_meta($id,'_lux_block_log',array_slice($log,-200));}
add_action('admin_post_lux_block_save',function(){
 if(!current_user_can('edit_posts'))wp_die('No access');check_admin_referer('lux_block');$id=absint($_POST['apt']??0);if(get_post_type($id)!==lux_room_type())wp_die('Unknown apartment');
 $in=wp_unslash($_POST);$key=sanitize_key($in['key']??'');$back=admin_url('admin.php?page=luxury-availability&apt='.$id);
 $blocks=lux_blocks($id);
 if(($in['do']??'')==='remove'){foreach($blocks as $i=>$b)if($b['key']===$key){lux_block_log($id,'remove',$b);unset($blocks[$i]);}lux_save_blocks($id,$blocks);wp_safe_redirect($back.'&msg=removed');exit;}
 $f=sanitize_text_field($in['from']??'');$t=sanitize_text_field($in['until']??'');
 if(!lux_ymd($f)||!lux_ymd($t)||$t<=$f){wp_safe_redirect($back.'&err='.rawurlencode('The release date must be after the start date.'));exit;}
 $b=['key'=>$key?:substr(wp_generate_password(12,false),0,10),'from'=>$f,'until'=>$t,'reason'=>isset(LUX_BLOCK_REASONS[$in['reason']??''])?$in['reason']:'external','comment'=>sanitize_text_field($in['comment']??''),'by'=>get_current_user_id(),'at'=>current_time('mysql')];
 lux_availability_lock();
 // A block may not cover a confirmed booking or a guest who is paying right now: those must be settled separately.
 $clash=lux_conflicts($id,$f,$t,0,false);
 if($clash){lux_availability_unlock();wp_safe_redirect($back.'&err='.rawurlencode('Not saved: these dates overlap '.implode(', ',array_map(fn($r)=>($r['type']==='hold'?'a payment in progress for ':'booking ').$r['ref'].' ('.$r['from'].' – '.$r['until'].')',$clash)).'. Settle that booking first.'));exit;}
 $found=false;foreach($blocks as $i=>$x){if($x['key']===$b['key']){$blocks[$i]=$b;$found=true;}elseif($x['from']===$f&&$x['until']===$t&&$x['reason']===$b['reason']){$found=true;}}
 if(!$found)$blocks[]=$b;lux_save_blocks($id,$blocks);lux_availability_unlock();lux_block_log($id,$key?'edit':'add',$b);
 wp_safe_redirect($back.'&msg=saved');exit;
});
function lux_save_blocks($id,$blocks){update_post_meta($id,'_lux_closed',array_values(array_map(fn($b)=>['key'=>$b['key'],'from'=>$b['from'],'until'=>$b['until'],'reason'=>$b['reason'],'comment'=>$b['comment'],'by'=>$b['by'],'at'=>$b['at']],$blocks)));}
function lux_availability_page(){
 if(!current_user_can('edit_posts'))return;
 $apts=get_posts(['post_type'=>lux_room_type(),'post_status'=>['publish','draft','private'],'numberposts'=>-1,'orderby'=>'title','order'=>'ASC']);$id=absint($_GET['apt']??($apts[0]->ID??0));$e='esc_html';
 echo '<div class="wrap"><h1>Availability calendar</h1><p>Close an apartment for a period: the nights from the start date up to the night before the release date. The release date itself is free for a new arrival, and the dates after it are bookable immediately — nothing has to be reopened. A block closes sales only; it does not create a booking, an invoice or a voucher.</p>';
 if(!empty($_GET['msg']))echo '<div class="notice notice-success is-dismissible"><p>'.(['removed'=>'Block removed.','cancelled'=>'Booking cancelled. Its dates are free on the website now.','restored'=>'Booking restored. Its dates are closed again.'][$_GET['msg']]??'Saved. The website uses it immediately.').'</p></div>';
 if(!empty($_GET['err']))echo '<div class="notice notice-error"><p>'.$e(wp_unslash($_GET['err'])).'</p></div>';
 echo '<form method="get"><input type="hidden" name="page" value="luxury-availability"><label>Apartment <select name="apt" onchange="this.form.submit()">';
 foreach(['batumi'=>'Batumi','gudauri'=>'Gudauri'] as $c=>$cl){echo '<optgroup label="'.$cl.'">';foreach($apts as $a)if((get_post_meta($a->ID,'_lux_city',true)?:'batumi')===$c)echo '<option value="'.$a->ID.'" '.selected($id,$a->ID,false).'>'.$e($a->post_title.' · block '.get_post_meta($a->ID,'_lux_block',true)).'</option>';echo '</optgroup>';}
 echo '</select></label> <noscript><button class="button">Show</button></noscript></form>';
 if(!$id){echo '</div>';return;}
 $label=['block'=>'Manual block','booking'=>'Booking','hold'=>'Payment in progress (temporary hold)'];
 echo '<h2>'.$e(get_the_title($id)).'</h2><table class="widefat striped" style="max-width:1100px"><thead><tr><th>Type</th><th>Start (first night)</th><th>Release date (free again)</th><th>Nights</th><th>Reason / booking</th><th>Comment (internal)</th><th>Changed</th><th></th></tr></thead><tbody>';
 $rows=lux_busy($id);$blocks=[];foreach(lux_blocks($id) as $b)$blocks[$b['key']]=$b;
 if(!$rows)echo '<tr><td colspan="8">Free — no blocks or bookings ahead.</td></tr>';
 foreach($rows as $r){$n=lux_ymd($r['from'])->diff(lux_ymd($r['until']))->days;$b=$r['type']==='block'?($blocks[$r['key']]??null):null;
  echo '<tr><td><strong>'.$e($label[$r['type']]).'</strong></td>';
  if($b){$u=get_userdata($b['by']);echo '<td colspan="7"><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">'.wp_nonce_field('lux_block','_wpnonce',true,false).'<input type="hidden" name="action" value="lux_block_save"><input type="hidden" name="apt" value="'.$id.'"><input type="hidden" name="key" value="'.esc_attr($b['key']).'"><input type="date" name="from" value="'.esc_attr($b['from']).'" required> → <input type="date" name="until" value="'.esc_attr($b['until']).'" required> <span>'.$n.' night'.($n===1?'':'s').'</span><select name="reason">';foreach(LUX_BLOCK_REASONS as $k=>$v)echo '<option value="'.$k.'" '.selected($b['reason'],$k,false).'>'.$e($v).'</option>';echo '</select><input type="text" name="comment" value="'.esc_attr($b['comment']).'" placeholder="Internal comment" style="min-width:200px"><span class="description">'.$e(($u?$u->display_name:'').' · '.$b['at']).'</span><button class="button">Save changes</button><button class="button-link-delete" name="do" value="remove" onclick="return confirm(\'Remove this block?\')">Remove</button></form></td></tr>';continue;}
  echo '<td>'.$e($r['from']).'</td><td>'.$e($r['until']).'</td><td>'.$n.'</td><td>'.(isset($r['booking'])?'<a href="'.esc_url(get_edit_post_link($r['booking'])).'">'.$e($r['ref']).'</a>':$e($r['ref'])).'</td><td></td><td></td><td>'.(isset($r['booking'])&&current_user_can('manage_options')?lux_cancel_link($r['booking'],add_query_arg(['page'=>'luxury-availability','apt'=>$id],admin_url('admin.php'))):'').'</td></tr>';}
 echo '</tbody></table><h2>Close dates</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;max-width:1100px">'.wp_nonce_field('lux_block','_wpnonce',true,false).'<input type="hidden" name="action" value="lux_block_save"><input type="hidden" name="apt" value="'.$id.'"><label>Start date (first closed night)<br><input type="date" name="from" required></label><label>Release date (free again)<br><input type="date" name="until" required></label><label>Reason<br><select name="reason">';foreach(LUX_BLOCK_REASONS as $k=>$v)echo '<option value="'.$k.'">'.$e($v).'</option>';echo '</select></label><label>Internal comment<br><input type="text" name="comment" style="min-width:260px"></label><button class="button button-primary">Close these dates</button></form><p class="description">Example: start 10 December, release 15 December closes the nights of 10–14 December; a guest can arrive on 15 December. Reasons and comments are never shown to guests.</p>';
 $log=get_post_meta($id,'_lux_block_log',true);if(is_array($log)&&$log){echo '<h2>History</h2><ul>';foreach(array_slice(array_reverse($log),0,30) as $l){$u=get_userdata($l['by']);echo '<li>'.$e($l['at'].' · '.($u?$u->display_name:'').' · '.$l['action'].' · '.$l['from'].' → '.$l['until'].' · '.(LUX_BLOCK_REASONS[$l['reason']]??'').($l['comment']?' · '.$l['comment']:'')).'</li>';}echo '</ul>';}
 echo '</div>';
}

// Live busy dates for the calendar. Pages may be served from a page cache (LiteSpeed) for up to an hour,
// so the calendar asks for the current periods on every page view; this answer is never cached.
add_action('rest_api_init',function(){register_rest_route('luxury/v1','/availability',['methods'=>'GET','permission_callback'=>'__return_true','callback'=>function(){
 $out=[];foreach(get_posts(['post_type'=>lux_room_type(),'post_status'=>'publish','numberposts'=>-1,'fields'=>'ids']) as $id)$out[$id]=array_map(fn($r)=>[$r['from'],$r['until']],lux_busy($id));
 $res=new WP_REST_Response($out);$res->header('Cache-Control','no-store, max-age=0');$res->header('X-LiteSpeed-Cache-Control','no-cache');return $res;
}]);});
// When dates, prices or a booking change, drop the cached copies of the affected apartment pages and the lists (LiteSpeed Cache).
$GLOBALS['lux_purge_ids']=[];
function lux_queue_purge($meta_id,$post_id,$key){
 if(!in_array($key,['_lux_status','_lux_hold_until','_lux_closed','_lux_rates','_lux_price'],true))return;
 if(get_post_type($post_id)==='lux_booking'){$d=get_post_meta($post_id,'_lux_request',true);foreach(($d['apartments']??[]) as $a)$GLOBALS['lux_purge_ids'][(int)$a['id']]=1;}
 elseif(get_post_type($post_id)===lux_room_type())$GLOBALS['lux_purge_ids'][(int)$post_id]=1;
}
add_action('added_post_meta','lux_queue_purge',10,3);add_action('updated_post_meta','lux_queue_purge',10,3);
add_action('shutdown',function(){
 if(empty($GLOBALS['lux_purge_ids'])||!has_action('litespeed_purge_post'))return;
 foreach(array_keys($GLOBALS['lux_purge_ids']) as $id)do_action('litespeed_purge_post',$id);
 foreach(['/apartments/','/batumi/','/gudauri/','/new-gudauri/'] as $u)do_action('litespeed_purge_url',home_url($u));
});

// ---------- Cancel a booking and release its dates (client request of 26 Nov 2026) ----------
// Cancelled (and Declined) bookings no longer occupy their apartments: the dates are free on the website at once.
// Nothing is emailed to the guest and no money is moved; a refund is made in the Flitt portal or by the bank.
function lux_cancel_log($id,$entry){$log=get_post_meta($id,'_lux_cancel_log',true);$log=is_array($log)?$log:[];$log[]=$entry+['by'=>get_current_user_id(),'at'=>current_time('mysql')];update_post_meta($id,'_lux_cancel_log',array_slice($log,-50));}
function lux_booking_cancel($id,$reason=''){
 $old=(string)get_post_meta($id,'_lux_status',true);if($old==='cancelled')return true;
 update_post_meta($id,'_lux_status','cancelled');delete_post_meta($id,'_lux_hold_until');
 wp_clear_scheduled_hook('luxf_unpaid_reminder',[$id]);
 lux_cancel_log($id,['action'=>'cancelled','from_status'=>$old,'reason'=>$reason]);return true;
}
// Restores the status it had before (normally Confirmed) — only if nobody has taken those nights meanwhile.
function lux_booking_restore($id){
 if(get_post_meta($id,'_lux_status',true)!=='cancelled')return '';
 lux_availability_lock();$clash=lux_booking_conflicts($id);
 if($clash){lux_availability_unlock();return 'Not restored: the dates are taken now — '.implode('; ',$clash).'.';}
 $prev='confirmed';$log=get_post_meta($id,'_lux_cancel_log',true);foreach(array_reverse(is_array($log)?$log:[]) as $l)if(($l['action']??'')==='cancelled'){$prev=$l['from_status']?:'confirmed';break;}
 if(in_array($prev,['awaiting_payment','payment_failed','new',''],true))$prev='reviewing'; // a payment hold is not revived; the team decides
 update_post_meta($id,'_lux_status',$prev);lux_availability_unlock();lux_cancel_log($id,['action'=>'restored','to_status'=>$prev]);return '';
}
function lux_cancel_link($id,$back){
 $st=get_post_meta($id,'_lux_status',true);$d=get_post_meta($id,'_lux_request',true);$ref=is_array($d)?($d['reference']??''):'';
 if($st==='cancelled')return '<a href="'.esc_url(wp_nonce_url(add_query_arg(['action'=>'lux_booking_restore','id'=>$id,'back'=>rawurlencode($back)],admin_url('admin-post.php')),'lux_booking_restore_'.$id)).'" onclick="return confirm(\'Restore booking '.esc_js($ref).' and close its dates again?\')">Restore booking</a>';
 $url=wp_nonce_url(add_query_arg(['action'=>'lux_booking_cancel','id'=>$id,'back'=>rawurlencode($back)],admin_url('admin-post.php')),'lux_booking_cancel_'.$id);
 return '<a class="lux-cancel-booking" style="color:#b32d2e" href="'.esc_url($url).'" onclick="var r=prompt(\'Cancel booking '.esc_js($ref).' and make its dates free on the website?\\n\\nReason (internal, optional):\',\'\');if(r===null)return false;this.href+=\'&reason=\'+encodeURIComponent(r);">Cancel booking &amp; release dates</a>';
}
foreach(['cancel','restore'] as $lux_do)add_action('admin_post_lux_booking_'.$lux_do,function()use($lux_do){
 $id=absint($_GET['id']??0);if(!current_user_can('manage_options')||get_post_type($id)!=='lux_booking')wp_die('No access');check_admin_referer('lux_booking_'.$lux_do.'_'.$id);
 $back=esc_url_raw(rawurldecode((string)($_GET['back']??'')));if(!$back||strpos($back,admin_url())!==0)$back=get_edit_post_link($id,'raw');
 if($lux_do==='cancel'){lux_booking_cancel($id,sanitize_text_field(wp_unslash($_GET['reason']??'')));wp_safe_redirect(add_query_arg('msg','cancelled',$back));exit;}
 $err=lux_booking_restore($id);wp_safe_redirect($err?add_query_arg('err',rawurlencode($err),$back):add_query_arg('msg','restored',$back));exit;
});
// Booking screen: a clear box with the dates and the cancel / restore action.
add_action('add_meta_boxes',function(){add_meta_box('lux-booking-dates','Dates & cancellation','lux_booking_dates_box','lux_booking','side','high');});
function lux_booking_dates_box($post){
 $id=$post->ID;$d=get_post_meta($id,'_lux_request',true);if(!is_array($d)||($d['kind']??'')==='experience'){echo '<p>Experience request — no dates are closed.</p>';return;}
 $st=get_post_meta($id,'_lux_status',true)?:'new';$occupies=false;foreach(lux_occupying_bookings() as $o)if($o['booking']===$id)$occupies=true;
 $names=['new'=>'New request','awaiting_payment'=>'Awaiting online payment','payment_failed'=>'Not confirmed — payment failed','reviewing'=>'In review','confirmed'=>'Confirmed','declined'=>'Declined','cancelled'=>'Cancelled'];
 if(!empty($_GET['msg'])&&in_array($_GET['msg'],['cancelled','restored'],true))echo '<div class="notice notice-success inline"><p>'.($_GET['msg']==='cancelled'?'Booking cancelled. Its dates are free on the website now.':'Booking restored. Its dates are closed again.').'</p></div>';
 if(!empty($_GET['err']))echo '<div class="notice notice-error inline"><p>'.esc_html(wp_unslash($_GET['err'])).'</p></div>';
 echo '<p><strong>'.esc_html($names[$st]??$st).'</strong><br>'.esc_html(($d['checkin']??'').' → '.($d['checkout']??'')).'<br>'.esc_html(implode(', ',array_map(fn($a)=>$a['title'],$d['apartments']??[]))).'</p>';
 echo '<p>'.($occupies?'🔒 These dates are <strong>closed</strong> on the website.':'🔓 These dates are <strong>free</strong> on the website'.(($d['checkout']??'')<=wp_date('Y-m-d')?' (the stay is over).':' — this booking does not hold them.')).'</p>';
 if(current_user_can('manage_options'))echo '<p>'.str_replace('<a ','<a class="button" ',lux_cancel_link($id,get_edit_post_link($id,'raw'))).'</p>';
 if($st==='cancelled')echo '<p class="description">The guest is not emailed automatically. A refund, if due, is made in the Flitt portal (or by bank transfer) — then note it in the payments below.</p>';
 else echo '<p class="description">Cancelling frees the dates immediately. The guest is not emailed and no money is refunded automatically (refunds: Flitt portal or bank).</p>';
 $log=get_post_meta($id,'_lux_cancel_log',true);if(is_array($log)&&$log){echo '<p><strong>History</strong></p><ul style="margin:0">';foreach(array_reverse($log) as $l){$u=get_userdata($l['by']??0);echo '<li>'.esc_html(($l['at']??'').' · '.($u?$u->display_name:'').' · '.($l['action']??'').(!empty($l['reason'])?' · '.$l['reason']:'')).'</li>';}echo '</ul>';}
}
// Bookings list: the same action under each booking.
add_filter('post_row_actions',function($actions,$post){if($post->post_type==='lux_booking'&&current_user_can('manage_options')){$d=get_post_meta($post->ID,'_lux_request',true);if(is_array($d)&&($d['kind']??'')!=='experience')$actions['lux_cancel']=lux_cancel_link($post->ID,admin_url('edit.php?post_type=lux_booking'));}return $actions;},10,2);
add_action('admin_notices',function(){$s=function_exists('get_current_screen')?get_current_screen():null;if(!$s||$s->id!=='edit-lux_booking'||(empty($_GET['msg'])&&empty($_GET['err'])))return;if($_GET['msg']==='cancelled')echo '<div class="notice notice-success is-dismissible"><p>Booking cancelled. Its dates are free on the website now.</p></div>';if($_GET['msg']==='restored')echo '<div class="notice notice-success is-dismissible"><p>Booking restored. Its dates are closed again.</p></div>';if(!empty($_GET['err']))echo '<div class="notice notice-error"><p>'.esc_html(wp_unslash($_GET['err'])).'</p></div>';});
