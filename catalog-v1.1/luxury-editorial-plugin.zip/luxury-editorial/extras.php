<?php
if(!defined('ABSPATH'))exit;
// Booking extras and payment split: breakfast per guest per night, airport transfers (private sedan), 30% deposit or full payment.
// Amounts are recalculated here on submit; the browser figures are only a preview. No card payment is taken on the site.

function lux_extras_defaults(){return ['breakfast'=>26,'breakfast_gudauri'=>40,'deposit'=>30,'sedan_max'=>4,'routes'=>"Batumi Airport ↔ Batumi Hotel | 50\nKutaisi Airport ↔ Batumi | 300\nTbilisi Airport ↔ Batumi | 550\nTbilisi Airport ↔ Gudauri | 350\nGudauri ↔ Batumi | 800"];}
function lux_booking_extras(){
 $s=array_merge(lux_extras_defaults(),array_filter((array)get_option('lux_booking_extras',[]),fn($v)=>$v!==''&&$v!==null));
 $routes=[];foreach(preg_split('/\R/',(string)$s['routes']) as $line){$parts=array_map('trim',explode('|',$line));if(count($parts)<2||$parts[0]===''||!is_numeric($parts[1]))continue;$routes[]=['id'=>trim(preg_replace('/[^a-z0-9]+/','-',strtolower(remove_accents($parts[0]))),'-'),'name'=>$parts[0],'price'=>(int)round((float)$parts[1])];}
 return ['breakfast'=>max(0,(int)$s['breakfast']),'breakfast_gudauri'=>max(0,(int)$s['breakfast_gudauri']),'deposit'=>min(100,max(1,(int)$s['deposit'])),'sedan_max'=>max(1,(int)$s['sedan_max']),'routes'=>$routes];
}
function lux_breakfast_price($city,$x=null){$x=$x?:lux_booking_extras();return $city==='gudauri'?$x['breakfast_gudauri']:$x['breakfast'];}
// $accommodation: total of all apartments or null when any is on request.
// $stays: the apartments in request order ([city, guests]); breakfasts are allocated to them in that order and priced by city.
function lux_booking_breakdown($accommodation,$nights,$guests,$breakfastGuests,$route,$trip,$option,$vehicle='car',$stays=[]){
 $x=lux_booking_extras();$complete=$accommodation!==null;
 if(!$stays)$stays=[['city'=>'batumi','guests'=>$breakfastGuests]];
 $left=$breakfastGuests;$byCity=[];$bfTotal=0;foreach($stays as $st){$n=min($left,(int)$st['guests']);if($n<=0)continue;$left-=$n;$byCity[$st['city']]=($byCity[$st['city']]??0)+$n;$bfTotal+=$n*$nights*lux_breakfast_price($st['city'],$x);}
 $prices=array_unique(array_map(fn($c)=>lux_breakfast_price($c,$x),array_keys($byCity)));
 $breakfast=['guests'=>$breakfastGuests,'nights'=>$nights,'price'=>count($prices)===1?reset($prices):($byCity?null:$x['breakfast']),'total'=>$bfTotal,'by_city'=>$byCity];
 $transfer=null;foreach($x['routes'] as $r)if($r['id']===$route){$onRequest=$vehicle==='minivan'||$guests>$x['sedan_max'];$transfer=['id'=>$r['id'],'name'=>$r['name'],'trip'=>$trip,'vehicle'=>$onRequest?'minivan':'car','price'=>$r['price'],'total'=>$onRequest?null:$r['price']*($trip==='round'?2:1),'on_request'=>$onRequest];if($onRequest)$complete=false;}
 $total=$complete?(int)round($accommodation+$breakfast['total']+($transfer['total']??0)):null;
 $pct=$option==='full'?100:$x['deposit'];$due=$total===null?null:(int)round($total*$pct/100);
 return ['accommodation'=>$accommodation,'breakfast'=>$breakfast,'transfer'=>$transfer,'total'=>$total,'payment'=>['option'=>$option,'percent'=>$pct,'due_now'=>$due,'deposit'=>$option==='full'?0:$due,'balance'=>$total===null?null:$total-$due]];
}

add_action('admin_menu',function(){add_submenu_page('luxury-setup','Booking extras','Booking extras','manage_options','luxury-extras','lux_extras_page');});
function lux_extras_page(){
 if(!current_user_can('manage_options'))return;$saved=(array)get_option('lux_booking_extras',[]);$d=lux_extras_defaults();$x=lux_booking_extras();
 ?><div class="wrap"><h1>Booking extras</h1><?php if(isset($_GET['updated']))echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';?>
 <p>Services guests can add in the booking request form, and the payment split shown with the total. All prices in Georgian lari (GEL). Empty fields use the value in grey.</p>
 <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="max-width:760px"><input type="hidden" name="action" value="lux_extras"><?php wp_nonce_field('lux_extras');?>
 <table class="form-table" role="presentation">
 <tr><th scope="row"><label for="lux-breakfast">Breakfast · Batumi</label></th><td><input id="lux-breakfast" name="breakfast" type="number" min="0" step="1" value="<?php echo esc_attr($saved['breakfast']??'');?>" placeholder="<?php echo esc_attr($d['breakfast']);?>" style="width:100px"> GEL per guest per night</td></tr>
 <tr><th scope="row"><label for="lux-breakfast-gudauri">Breakfast · New Gudauri</label></th><td><input id="lux-breakfast-gudauri" name="breakfast_gudauri" type="number" min="0" step="1" value="<?php echo esc_attr($saved['breakfast_gudauri']??'');?>" placeholder="<?php echo esc_attr($d['breakfast_gudauri']);?>" style="width:100px"> GEL per guest per night</td></tr>
 <tr><th scope="row"><label for="lux-routes">Transfer routes</label></th><td><textarea id="lux-routes" name="routes" rows="6" class="large-text code" placeholder="<?php echo esc_attr($d['routes']);?>"><?php echo esc_textarea($saved['routes']??'');?></textarea><p class="description">One route per line: <code>Route name | price</code>. Price is one way, per private car (up to the capacity below); round trip is charged twice. Minivans are always priced on request.</p></td></tr>
 <tr><th scope="row"><label for="lux-sedan">Car capacity</label></th><td><input id="lux-sedan" name="sedan_max" type="number" min="1" max="20" step="1" value="<?php echo esc_attr($saved['sedan_max']??'');?>" placeholder="<?php echo esc_attr($d['sedan_max']);?>" style="width:80px"> guests. Larger groups see “Private minivan — price on request”.</td></tr>
 <tr><th scope="row"><label for="lux-deposit">Deposit</label></th><td><input id="lux-deposit" name="deposit" type="number" min="1" max="100" step="1" value="<?php echo esc_attr($saved['deposit']??'');?>" placeholder="<?php echo esc_attr($d['deposit']);?>" style="width:80px"> % of the total, shown as the deposit option.</td></tr>
 </table><?php submit_button('Save booking extras');?></form>
 <h2>Current routes</h2><ul style="list-style:disc;padding-left:20px"><?php foreach($x['routes'] as $r)echo '<li>'.esc_html($r['name'].' — '.lux_money($r['price']).' one way').'</li>';?></ul></div><?php
}
add_action('admin_post_lux_extras',function(){
 if(!current_user_can('manage_options'))wp_die('Not allowed',403);check_admin_referer('lux_extras');
 $in=wp_unslash($_POST);$out=[];foreach(['breakfast','breakfast_gudauri','deposit','sedan_max'] as $k)$out[$k]=($in[$k]??'')===''?'':absint($in[$k]);$out['routes']=sanitize_textarea_field($in['routes']??'');
 update_option('lux_booking_extras',$out);wp_safe_redirect(admin_url('admin.php?page=luxury-extras&updated=1'));exit;
});
