/* Stay calendar for the apartment pages and the booking form.
   Busy nights (manual blocks, bookings, payments in progress) are crossed out and cannot be chosen; the nightly
   price in GEL is shown under each date. The native date fields stay in place and keep their values, so the
   booking logic in catalog.js keeps working: a chosen date is written into the field and a "change" event is fired. */
(function(){
  'use strict';
  var config=window.LUX_CATALOG;if(!config||!config.apartments)return;
  var rooms={};config.apartments.forEach(function(a){rooms[Number(a.id)]=a;});
  var DAY=864e5;
  function utc(v){return Date.UTC(+v.slice(0,4),+v.slice(5,7)-1,+v.slice(8,10));}
  function iso(t){return new Date(t).toISOString().slice(0,10);}
  function addDays(v,n){return iso(utc(v)+n*DAY);}
  function tbilisiToday(){try{return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Tbilisi'}).format(new Date());}catch(e){return iso(Date.now());}}
  function lang(){var l=document.documentElement.dataset.luxLang||'en';return ({ru:'ru',ka:'ka'})[l]||'en';}
  var TXT={
    en:{legend:'Crossed-out dates are not available',prices:'Prices per night in GEL',checkin:'Select check-in date',checkout:'Select check-out date',clear:'Clear dates',close:'Close',prev:'Previous month',next:'Next month'},
    ru:{legend:'Зачёркнутые даты недоступны',prices:'Цены за ночь в GEL',checkin:'Выберите дату заезда',checkout:'Выберите дату выезда',clear:'Сбросить даты',close:'Закрыть',prev:'Предыдущий месяц',next:'Следующий месяц'},
    ka:{legend:'გადახაზული თარიღები დაკავებულია',prices:'ფასი ერთ ღამეზე, GEL',checkin:'აირჩიეთ შესვლის თარიღი',checkout:'აირჩიეთ გასვლის თარიღი',clear:'თარიღების გასუფთავება',close:'დახურვა',prev:'წინა თვე',next:'შემდეგი თვე'}
  };
  function t(k){return (TXT[lang()]||TXT.en)[k];}
  function nightsText(n){var L=lang();if(L==='ru'){var m=n%10,h=n%100;return n+' '+(m===1&&h!==11?'ночь':(m>=2&&m<=4&&(h<10||h>=20)?'ночи':'ночей'));}return L==='ka'?n+' ღამე':n+(n===1?' night':' nights');}

  // Dates are always shown as day/month/year. The browser's own date field follows the computer's language
  // (in the US format 12/03/2026 is 3 December), so its text is hidden and this label is drawn over it.
  var PH={en:'dd/mm/yyyy',ru:'дд/мм/гггг',ka:'დდ/თთ/წწწწ'};
  function dmy(v){return /^\d{4}-\d{2}-\d{2}$/.test(v||'')?v.slice(8,10)+'/'+v.slice(5,7)+'/'+v.slice(0,4):'';}
  var nativeValue=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value'),paints=[];
  function wrapOf(input){var w=input.parentNode;if(w&&w.classList&&w.classList.contains('lc-dp-wrap'))return w;w=document.createElement('span');w.className='lc-dp-wrap';input.parentNode.insertBefore(w,input);w.appendChild(input);return w;}
  function showDate(input){
    if(input.dataset.dmyDone)return;input.dataset.dmyDone='1';
    var w=wrapOf(input),s=document.createElement('span');s.className='lc-date-text notranslate';s.setAttribute('translate','no');s.setAttribute('aria-hidden','true');w.appendChild(s);input.classList.add('lc-dmy');
    function paint(){var v=nativeValue.get.call(input),cs=getComputedStyle(input);s.textContent=dmy(v)||PH[lang()]||PH.en;s.classList.toggle('is-empty',!v);s.style.left=((parseFloat(cs.paddingLeft)||12)+(parseFloat(cs.borderLeftWidth)||1))+'px';s.style.fontSize=cs.fontSize;}
    // catalog.js fills the fields by assigning .value (no event), so the label follows every assignment.
    try{Object.defineProperty(input,'value',{configurable:true,get:function(){return nativeValue.get.call(this);},set:function(v){nativeValue.set.call(this,v);paint();}});}catch(e){}
    input.addEventListener('input',paint);input.addEventListener('change',paint);if(input.form)input.form.addEventListener('reset',function(){setTimeout(paint,0);});
    paints.push(paint);paint();
  }
  // Same rule as lux_quote(): the shortest rate period containing the night wins, otherwise the base rate.
  function rateFor(a,night){var best=null,bestDays=Infinity;(a.rates||[]).forEach(function(r){if(r.from<=night&&night<=r.to){var d=(utc(r.to)-utc(r.from))/DAY+1;if(d<=bestDays){best=r;bestDays=d;}}});return best?Number(best.price)||0:Number(a.price)||0;}

  // Which apartments a date field belongs to: the apartment page card, or the apartments chosen in the booking form.
  function contextIds(input){
    var card=input.closest('.lc-booking-card');
    if(card){var b=card.querySelector('[data-book-one]');return b?[Number(b.dataset.bookOne)]:[];}
    if(input.form&&input.form.id==='lc-booking-form')return Array.prototype.map.call(input.form.querySelectorAll('[data-guests-for]'),function(s){return Number(s.dataset.guestsFor);});
    return [];
  }
  function pairFor(input){
    var name=input.dataset.quickDate||input.name;var other=name==='checkin'?'checkout':'checkin';
    if(input.form&&input.form.elements[other])return {checkin:name==='checkin'?input:input.form.elements.checkin,checkout:name==='checkout'?input:input.form.elements.checkout};
    var scope=input.closest('.lc-booking-card,.lc-filters,form,section')||document;
    var o=scope.querySelector('[data-quick-date="'+other+'"]');
    return {checkin:name==='checkin'?input:o,checkout:name==='checkout'?input:o};
  }

  var pop=null,cur=null;
  function busyNight(ids,night){for(var i=0;i<ids.length;i++){var a=rooms[ids[i]];if(!a||!a.closed)continue;for(var j=0;j<a.closed.length;j++){var r=a.closed[j];if(night>=r[0]&&night<r[1])return true;}}return false;}
  function nightPrice(ids,night){var sum=0;for(var i=0;i<ids.length;i++){var a=rooms[ids[i]];if(!a)return 0;var p=rateFor(a,night);if(p<=0)return 0;sum+=p;}return sum;}
  // After a check-in date, the stay may run up to (and check out on) the first busy night.
  function firstBusyAfter(ids,from){for(var d=from,i=0;i<400;i++,d=addDays(d,1)){if(busyNight(ids,d))return d;}return null;}

  function build(){
    pop=document.createElement('div');pop.className='lc-dp notranslate';pop.setAttribute('translate','no');pop.setAttribute('role','dialog');pop.hidden=true;
    pop.addEventListener('click',function(e){
      var day=e.target.closest('[data-day]');if(day&&!day.disabled){choose(day.dataset.day);return;}
      if(e.target.closest('[data-dp-prev]')){cur.month=addMonths(cur.month,-1);render();}
      if(e.target.closest('[data-dp-next]')){cur.month=addMonths(cur.month,1);render();}
      if(e.target.closest('[data-dp-clear]')){set(cur.pair.checkin,'');set(cur.pair.checkout,'');cur.mode='checkin';render();}
      if(e.target.closest('[data-dp-close]'))close();
    });
    pop.addEventListener('mouseover',function(e){var d=e.target.closest('[data-day]');if(!d||!cur||cur.mode!=='checkout')return;cur.hover=d.dataset.day;paintRange();});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&pop&&!pop.hidden)close();});
    document.addEventListener('mousedown',function(e){if(pop&&!pop.hidden&&!pop.contains(e.target)&&!e.target.closest('.lc-dp-hit'))close();});
  }
  function addMonths(m,n){var d=new Date(Date.UTC(+m.slice(0,4),+m.slice(5,7)-1+n,1));return d.toISOString().slice(0,7);}
  function set(input,v){if(!input)return;input.value=v;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));}
  function choose(day){
    var p=cur.pair;
    if(cur.mode==='checkin'){set(p.checkin,day);if(p.checkout&&p.checkout.value&&p.checkout.value<=day)set(p.checkout,'');cur.mode='checkout';cur.hover=null;render();return;}
    set(p.checkout,day);close();
  }
  function open(input){
    if(!pop)build();
    var pair=pairFor(input),name=input.dataset.quickDate||input.name;
    // Opens inside the form, right under the date fields, so it never covers other fields (guests, phone …).
    // In the catalog filters on a wide screen it is a compact panel right under the date fields (like Booking).
    var host=input.closest('.lc-filters'),float=!!host&&window.innerWidth>=760;
    pop.classList.toggle('is-float',float);pop.style.left=pop.style.top='';
    if(float){host.classList.add('lc-dp-host');host.appendChild(pop);}
    else{var field=pair.checkout||input,anchor=field.closest('label')||field.closest('.lc-dp-wrap');anchor.parentNode.insertBefore(pop,anchor.nextSibling);}
    var start=(pair.checkin&&pair.checkin.value)||tbilisiToday();
    cur={input:input,pair:pair,ids:contextIds(input),mode:(name==='checkout'&&pair.checkin&&pair.checkin.value)?'checkout':'checkin',month:start.slice(0,7),hover:null,host:float?host:null};
    pop.hidden=false;place();render();try{pop.scrollIntoView({block:'nearest',behavior:'smooth'});}catch(e){}
  }
  function place(){
    if(!cur||!cur.host)return;var h=cur.host.getBoundingClientRect(),a=(cur.pair.checkin||cur.input).getBoundingClientRect(),b=(cur.pair.checkout||cur.input).getBoundingClientRect();
    pop.style.top=(Math.max(a.bottom,b.bottom)-h.top+8)+'px';pop.style.left=Math.max(0,Math.min(a.left-h.left,h.width-pop.offsetWidth))+'px';
  }
  function close(){if(pop)pop.hidden=true;cur=null;}
  function monthHtml(m){
    var L=lang(),first=new Date(Date.UTC(+m.slice(0,4),+m.slice(5,7)-1,1)),title=new Intl.DateTimeFormat(L,{month:'long',year:'numeric',timeZone:'UTC'}).format(first);
    var wd=[];for(var i=0;i<7;i++)wd.push(new Intl.DateTimeFormat(L,{weekday:'short',timeZone:'UTC'}).format(new Date(Date.UTC(2024,0,1+i))));
    var lead=(first.getUTCDay()+6)%7,days=new Date(Date.UTC(+m.slice(0,4),+m.slice(5,7),0)).getUTCDate();
    var today=tbilisiToday(),ci=cur.pair.checkin&&cur.pair.checkin.value,limit=cur.mode==='checkout'&&ci?firstBusyAfter(cur.ids,ci):null;
    var h='<div class="lc-dp-month"><p class="lc-dp-title">'+title+'</p><div class="lc-dp-grid">'+wd.map(function(w){return '<span class="lc-dp-wd">'+w+'</span>';}).join('');
    for(i=0;i<lead;i++)h+='<span></span>';
    for(var d=1;d<=days;d++){
      var day=m+'-'+String(d).padStart(2,'0'),busy=busyNight(cur.ids,day),past=day<today,dis,price='';
      if(cur.mode==='checkout'&&ci){dis=day<=ci||(limit&&day>limit);}else dis=past||busy;
      var cls='lc-dp-day'+(busy?' is-busy':'')+(past?' is-past':'');
      if(cur.ids.length&&!past){var p=busy?0:nightPrice(cur.ids,day);price='<small>'+(busy?'—':(p?Math.round(p):''))+'</small>';}
      h+='<button type="button" class="'+cls+'" data-day="'+day+'"'+(dis?' disabled':'')+' aria-label="'+day+(busy?' — '+t('legend'):'')+'"><span>'+d+'</span>'+price+'</button>';
    }
    return h+'</div></div>';
  }
  function render(){
    var two=pop.classList.contains('is-float')||(pop.parentNode&&pop.parentNode.clientWidth||0)>=640;
    var ci=cur.pair.checkin&&cur.pair.checkin.value,co=cur.pair.checkout&&cur.pair.checkout.value;
    var sum=ci?dmy(ci)+' — '+(co?dmy(co)+' · '+nightsText(Math.round((utc(co)-utc(ci))/DAY)):'…'):'';
    pop.innerHTML='<div class="lc-dp-head"><button type="button" data-dp-prev aria-label="'+t('prev')+'">‹</button><p>'+(cur.mode==='checkin'?t('checkin'):t('checkout'))+(sum?'<span class="lc-dp-sum">'+sum+'</span>':'')+'</p><button type="button" data-dp-next aria-label="'+t('next')+'">›</button></div>'
      +'<div class="lc-dp-months">'+monthHtml(cur.month)+(two?monthHtml(addMonths(cur.month,1)):'')+'</div>'
      +'<div class="lc-dp-foot"><span class="lc-dp-legend"><s>12</s> '+t('legend')+(cur.ids.length?' · '+t('prices'):'')+'</span><span><button type="button" data-dp-clear>'+t('clear')+'</button> <button type="button" data-dp-close>'+t('close')+'</button></span></div>';
    paintRange();place();
  }
  function paintRange(){
    var ci=cur.pair.checkin&&cur.pair.checkin.value,co=(cur.pair.checkout&&cur.pair.checkout.value)||(cur.mode==='checkout'?cur.hover:null);
    Array.prototype.forEach.call(pop.querySelectorAll('[data-day]'),function(b){var d=b.dataset.day;b.classList.toggle('is-start',d===ci);b.classList.toggle('is-end',!!co&&d===co);b.classList.toggle('is-in',!!(ci&&co&&d>ci&&d<co));});
  }

  // A transparent button over each date field opens the calendar instead of the browser picker.
  function enhance(input){
    if(input.dataset.dpDone)return;input.dataset.dpDone='1';
    var wrap=wrapOf(input);
    var hit=document.createElement('button');hit.type='button';hit.className='lc-dp-hit';hit.setAttribute('aria-label',input.getAttribute('aria-label')||((input.dataset.quickDate||input.name)==='checkin'?'Check in':'Check out'));
    hit.addEventListener('click',function(){open(input);});wrap.appendChild(hit);
  }
  function scan(){
    Array.prototype.forEach.call(document.querySelectorAll('input[type=date][data-quick-date],#lc-booking-form input[type=date][name=checkin],#lc-booking-form input[type=date][name=checkout]'),enhance);
    Array.prototype.forEach.call(document.querySelectorAll('.lc-filters input[type=date],.lc-booking-card input[type=date],#lc-booking-form input[type=date]'),showDate);
  }
  window.addEventListener('resize',function(){paints.forEach(function(f){f();});if(pop&&!pop.hidden&&cur){if(cur.host&&window.innerWidth<760){close();return;}render();}});
  if(document.readyState!=='loading')scan();else document.addEventListener('DOMContentLoaded',scan);
  // Fresh busy dates from the server (the page itself may come from a page cache).
  try{var ep=String(config.endpoint||'').replace(/booking-request.*$/,'availability');if(ep&&window.fetch)fetch(ep,{cache:'no-store',credentials:'same-origin'}).then(function(r){return r.ok?r.json():null;}).then(function(d){if(!d)return;Object.keys(d).forEach(function(id){if(rooms[Number(id)])rooms[Number(id)].closed=d[id];});if(pop&&!pop.hidden&&cur)render();}).catch(function(){});}catch(e){}
})();
