<?php
if(!defined('ABSPATH'))exit;
// Anonymous 1–5 star ratings for apartments. One vote per visitor (a random id kept in the browser); voting again replaces it.
// Votes are stored as hashed visitor id => stars, so no personal data is kept.

function lux_rating_votes($id){$v=get_post_meta($id,'_lux_rating_votes',true);return is_array($v)?$v:[];}
function lux_rating_summary($id){
 $dist=[1=>0,2=>0,3=>0,4=>0,5=>0];foreach(lux_rating_votes($id) as $s){$s=(int)$s;if(isset($dist[$s]))$dist[$s]++;}
 $count=array_sum($dist);$sum=0;foreach($dist as $s=>$n)$sum+=$s*$n;
 return ['average'=>$count?round($sum/$count,1):0,'count'=>$count,'distribution'=>$dist];
}

add_action('rest_api_init',function(){register_rest_route('luxury/v1','/rating',['methods'=>'POST','callback'=>'lux_submit_rating','permission_callback'=>'__return_true']);});
function lux_submit_rating($request){
 $d=$request->get_json_params();
 if(!is_array($d)||!is_string($d['nonce']??null)||!wp_verify_nonce($d['nonce'],'lux_booking'))return lux_booking_error('Please reload the page and try again.',403);
 $id=absint($d['id']??0);$stars=filter_var($d['stars']??null,FILTER_VALIDATE_INT);$voter=$d['voter']??'';
 if(get_post_type($id)!==lux_room_type()||get_post_status($id)!=='publish')return lux_booking_error('This apartment is no longer listed.',404);
 if(!$stars||$stars<1||$stars>5)return lux_booking_error('Choose between 1 and 5 stars.');
 if(!is_string($voter)||!preg_match('/^[a-zA-Z0-9-]{16,80}$/',$voter))return lux_booking_error('Please reload the page and try again.');
 $limit='lux_rating_rate_'.hash('sha256',($_SERVER['REMOTE_ADDR']??'unknown').wp_salt());$count=(int)get_transient($limit);
 if($count>=30)return lux_booking_error('Too many ratings. Please try again later.',429);
 // A per-apartment lock keeps simultaneous votes from overwriting each other.
 $lock='lux_rating_lock_'.$id;for($i=0;$i<20&&!add_option($lock,time(),'','no');$i++){if((int)get_option($lock)<time()-10)delete_option($lock);usleep(100000);}
 $votes=lux_rating_votes($id);$votes[hash('sha256',$voter.wp_salt())]=$stars;update_post_meta($id,'_lux_rating_votes',$votes);delete_option($lock);
 set_transient($limit,$count+1,HOUR_IN_SECONDS);
 return new WP_REST_Response(['stars'=>$stars]+lux_rating_summary($id),200);
}

// Admin: rating column in Apartments and a summary box with a reset.
add_action('init',function(){$type=lux_room_type();
 add_filter("manage_{$type}_posts_columns",fn($c)=>array_merge($c,['lux_rating'=>'Guest rating']));
 add_action("manage_{$type}_posts_custom_column",function($col,$id){if($col!=='lux_rating')return;$s=lux_rating_summary($id);echo $s['count']?esc_html('★ '.number_format($s['average'],1).' · '.$s['count'].' '._n('rating','ratings',$s['count'])):'—';},10,2);
},40);
add_action('add_meta_boxes',function(){add_meta_box('lux-ratings','Guest ratings','lux_ratings_box',lux_room_type(),'side','default');});
function lux_ratings_box($post){
 $s=lux_rating_summary($post->ID);
 if(!$s['count']){echo '<p>No ratings yet. Guests can rate this apartment from 1 to 5 stars on its page.</p>';return;}
 echo '<p style="font-size:20px;margin:4px 0 10px"><strong>★ '.esc_html(number_format($s['average'],1)).'</strong> <span style="font-size:13px;color:#646970">from '.(int)$s['count'].' '.esc_html(_n('rating','ratings',$s['count'])).'</span></p><table style="width:100%;border-collapse:collapse">';
 for($i=5;$i>=1;$i--){$n=$s['distribution'][$i];$w=$s['count']?round($n/$s['count']*100):0;echo '<tr><td style="width:34px;padding:2px 0">'.$i.' ★</td><td style="padding:2px 6px"><div style="background:#f0f0f1;height:8px;border-radius:4px"><div style="width:'.$w.'%;background:#8b7550;height:8px;border-radius:4px"></div></div></td><td style="width:26px;text-align:right">'.(int)$n.'</td></tr>';}
 echo '</table><p style="margin-top:12px"><a class="button-link-delete" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=lux_reset_ratings&post='.$post->ID),'lux_reset_ratings_'.$post->ID)).'" onclick="return confirm(\'Delete all ratings for this apartment?\')">Reset ratings</a></p>';
}
add_action('admin_post_lux_reset_ratings',function(){$id=absint($_GET['post']??0);if(!current_user_can('edit_post',$id))wp_die('Not allowed',403);check_admin_referer('lux_reset_ratings_'.$id);delete_post_meta($id,'_lux_rating_votes');wp_safe_redirect(get_edit_post_link($id,'url'));exit;});
