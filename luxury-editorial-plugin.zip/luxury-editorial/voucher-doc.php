<?php
if(!defined('ABSPATH'))exit;
// Booking confirmation voucher v1.4 (client spec of 18 Nov 2026): one template, Batumi and Gudauri settings, RU/EN/KA texts.
// The final voucher is issued only when the booking is confirmed, the required payment is recorded and every apartment
// has an address, block and number. Each issue is a numbered version: one stored PDF sent to the guest and to the company.

const LUXV_LOCALES=['en'=>'English','ru'=>'Русский','ka'=>'ქართული'];
const LUXV_TERMS_VERSION='R3.3';

function luxv_t($loc,$key){static $T=null;if($T===null)$T=luxv_texts();return $T[$loc][$key]??$T['en'][$key]??$key;}
function luxv_texts(){return [
'en'=>[
 'title'=>'Booking confirmation','confirmed'=>'CONFIRMED','booking_no'=>'Booking no.','invoice_no'=>'Invoice no.','version'=>'Version','issued'=>'Issued',
 'greeting'=>'Dear %s, your booking is confirmed. We look forward to welcoming you.',
 'lead_guest'=>'Lead guest','guests_stay'=>'Guests and length of stay','adults'=>'Adults','children'=>'Children','nights'=>'Nights','guests'=>'Guests',
 'location'=>'Location and property','address'=>'Accommodation address','block'=>'Block / building','apt'=>'Apartment number','apartment'=>'Apartment',
 'checkin'=>'Check-in','checkin_time'=>'14:00–23:59 · Georgia time','checkout'=>'Check-out','checkout_time'=>'By 11:00 · Georgia time',
 'category'=>'Category','rate'=>'Rate','contact'=>'Guest contact','arrival'=>'Estimated arrival','arrival_tz'=>'(Georgia local time)',
 'pay_h'=>'Payment details','total'=>'Total cost','paid'=>'Paid — %s%%','balance'=>'Balance due — %s%%','payment'=>'Payment','txn'=>'Transaction ID',
 'pay_status'=>'Payment status','st_unpaid'=>'Unpaid','st_partial'=>'Partially paid','st_full'=>'Fully paid',
 'balance_line'=>'The remaining balance must be paid at check-in, before the keys are issued.','overpaid'=>'Overpayment to be reconciled',
 'm_card'=>'Bank card (online)','m_transfer'=>'Bank transfer','m_cash'=>'Cash','m_terminal'=>'Card terminal',
 'services_h'=>'Your selected services','svc_col'=>'Booked service','amt_col'=>'Amount in GEL','accommodation'=>'Accommodation · Nights: %d',
 'breakfast'=>'Breakfast','transfer'=>'Transfer','added'=>'added','not_booked'=>'not booked','on_request'=>'price on request',
 'taxes'=>'The total includes applicable taxes and the mandatory fees listed.',
 'one_way'=>'one way','round_trip'=>'round trip','car'=>'private car','minivan'=>'minivan',
 'pickup'=>'Pick-up','meeting'=>'Meeting point','airport'=>'Arrival airport','terminal'=>'Terminal','flight_arrival'=>'Flight arrival','airport_tz'=>'(airport local time)',
 'airline'=>'Airline and flight','ticket'=>'Ticket / itinerary','ticket_received'=>'Received','ticket_pending'=>'Pending','pax'=>'Passengers and luggage','driver'=>'Driver or coordinator',
 'transfer_note'=>'For an airport transfer, please provide your arrival details in advance and send us your ticket or itinerary. Let us know if your flight changes.',
 'only_confirmed'=>'Only the services confirmed above are included in your booking.',
 'before_h'=>'Before your arrival','guest_info'=>'Guest information','checkin_h'=>'Check-in and key collection','key_collection'=>'Key collection','checkin_instr'=>'Check-in instructions',
 'p_present'=>'At check-in, please present your voucher or provide your invoice number, and show your original, valid passport or identity document.',
 'p_arrival'=>'Please provide your arrival date and approximate arrival time. Let us know in advance if your plans change.',
 'office_batumi'=>'Our Batumi office is open daily from 10:00 to 20:00. For a late check-in arranged in advance, keys can be collected from the specified reception desk, which is open 24/7, in accordance with our instructions.',
 'office_gudauri'=>'In Gudauri, keys can be collected from the reception desk in your accommodation building, which is open 24/7. We recommend contacting us in advance with your arrival time so we can arrange to welcome you.',
 'p_keys'=>'Keys are issued once the payment and identification requirements have been met. If you will arrive after 20:00, please let us know your arrival time in advance and obtain written confirmation from the company by email or WhatsApp. Arrival after 23:59 must be arranged separately; any arrangements made by phone must be confirmed in writing.',
 'cancel_h'=>'Cancellation terms','confirmed_rate'=>'Confirmed rate','accepted_terms'=>'Accepted terms','terms_accepted'=>'Terms accepted','full_terms'=>'Full terms',
 'c_free'=>'Free cancellation until 23:59 on %1$s: the amount paid is refunded in full (%2$s).',
 'c_mid'=>'From 00:00 on %1$s until 23:59 on %2$s: 30%% of the booking cost is retained (%3$s); amount refunded: %4$s.',
 'c_late'=>'From 00:00 on %1$s: the amount actually paid is non-refundable (%2$s).',
 'c_lastmin'=>'Last Minute rate (booked from 00:00 on the day before arrival): 100% prepayment, non-refundable.',
 'c_extras'=>'Breakfast and transfer','c_extras_default'=>'cancelled under the terms of the accommodation rate. Cancelling a service does not cancel your stay.',
 'p_tz'=>'All deadlines are in Georgia local time (Asia/Tbilisi, UTC+4). For an unambiguous written cancellation request, the relevant time is when we receive it at our official email address or on WhatsApp, rather than when a staff member reads it.',
 'p_noshow'=>'No-show: if you have not arrived by 23:59 on your check-in date and do not have written confirmation of a later arrival, the amount actually paid is non-refundable, except where required by mandatory legal provisions or covered by an agreed written exception. The unpaid 70% will not be charged automatically solely because of cancellation or a no-show.',
 'p_rights'=>'The accepted booking terms apply. These terms do not limit your statutory rights, including where an agreed service is not provided.',
 'requests_h'=>'Requests and arrangements','requests_note'=>'Additional requests require separate confirmation.',
 'help_h'=>'We are here to help','reservations'=>'Reservations','phone'=>'Phone',
 'office_line'=>'Company office in Batumi · Daily 10:00–20:00 (Georgia local time)','office_addr'=>'Batumi, 7d Sherif Khimshiashvili Street, Orbi City, Block C 13th floor, office 1333',
 'office_note_batumi'=>'Your apartment and reception desk may be in a different block. Please follow the confirmed property details and key collection instructions above.',
 'office_note_gudauri'=>'This is the address of our Batumi office. For your stay in Gudauri, please follow the property and reception details above.',
 'city_batumi'=>'Batumi','city_gudauri'=>'Gudauri','addr_batumi'=>'7d Sherif Khimshiashvili Street, Orbi City, Batumi, Georgia','addr_gudauri'=>'Redco New Gudauri, Gudauri 4702, Georgia',
 'mail_subject'=>'Your booking is confirmed · %s','mail_subject_update'=>'Updated booking confirmation · %s',
 'mail_body'=>'Dear %s,<br>your booking confirmation is attached as a PDF. Please keep it and present it at check-in together with your original passport or identity document.',
 'mail_link'=>'View your confirmation online','download'=>'Download PDF','print'=>'Print',
 'months'=>['January','February','March','April','May','June','July','August','September','October','November','December'],
],
'ru'=>[
 'title'=>'Подтверждение бронирования','confirmed'=>'ПОДТВЕРЖДЕНО','booking_no'=>'Бронирование №','invoice_no'=>'Инвойс №','version'=>'Версия','issued'=>'Выдано',
 'greeting'=>'Здравствуйте, %s! Ваше бронирование подтверждено. Будем рады приветствовать вас.',
 'lead_guest'=>'Основной гость','guests_stay'=>'Гости и срок проживания','adults'=>'Взрослые','children'=>'Дети','nights'=>'Ночи','guests'=>'Гостей',
 'location'=>'Локация и объект','address'=>'Адрес проживания','block'=>'Блок / корпус','apt'=>'Номер апартаментов','apartment'=>'Апартаменты',
 'checkin'=>'Заезд','checkin_time'=>'14:00–23:59 · По времени Грузии','checkout'=>'Выезд','checkout_time'=>'До 11:00 · По времени Грузии',
 'category'=>'Категория','rate'=>'Тариф','contact'=>'Контакты гостя','arrival'=>'Ориентировочное прибытие','arrival_tz'=>'(по времени Грузии)',
 'pay_h'=>'Сведения об оплате','total'=>'Общая стоимость','paid'=>'Оплачено — %s%%','balance'=>'Остаток к оплате — %s%%','payment'=>'Оплата','txn'=>'Номер операции',
 'pay_status'=>'Статус оплаты','st_unpaid'=>'Не оплачено','st_partial'=>'Частично оплачено','st_full'=>'Полностью оплачено',
 'balance_line'=>'Остаток необходимо оплатить при заселении, до получения ключей.','overpaid'=>'Переплата для сверки',
 'm_card'=>'Банковская карта (онлайн)','m_transfer'=>'Банковский перевод','m_cash'=>'Наличные','m_terminal'=>'Терминал',
 'services_h'=>'Выбранные вами услуги','svc_col'=>'Забронированная услуга','amt_col'=>'Сумма в GEL','accommodation'=>'Проживание · Ночей: %d',
 'breakfast'=>'Завтрак','transfer'=>'Трансфер','added'=>'добавлен','not_booked'=>'не забронирован','on_request'=>'цена по запросу',
 'taxes'=>'Общая стоимость включает применимые налоги и указанные обязательные сборы.',
 'one_way'=>'в одну сторону','round_trip'=>'туда и обратно','car'=>'легковой автомобиль','minivan'=>'минивэн',
 'pickup'=>'Подача','meeting'=>'Место встречи','airport'=>'Аэропорт прилёта','terminal'=>'Терминал','flight_arrival'=>'Прилёт','airport_tz'=>'(местное время аэропорта)',
 'airline'=>'Авиакомпания и рейс','ticket'=>'Билет / маршрутная квитанция','ticket_received'=>'Получены','ticket_pending'=>'Ожидаются','pax'=>'Пассажиры и багаж','driver'=>'Водитель или координатор',
 'transfer_note'=>'Для трансфера из аэропорта заранее сообщите данные прилёта и пришлите билет или маршрутную квитанцию. При изменении рейса уведомите нас.',
 'only_confirmed'=>'В бронирование входят только услуги, подтверждённые выше.',
 'before_h'=>'Перед вашим приездом','guest_info'=>'Информация для гостя','checkin_h'=>'Заселение и получение ключей','key_collection'=>'Получение ключей','checkin_instr'=>'Инструкции по заселению',
 'p_present'=>'При заселении предъявите ваучер или сообщите номер инвойса, а также предъявите оригинал действующего паспорта или документа, удостоверяющего личность.',
 'p_arrival'=>'Пожалуйста, укажите дату и приблизительное время прибытия. Если ваши планы изменятся, заранее сообщите нам.',
 'office_batumi'=>'Наш офис в Батуми открыт ежедневно с 10:00 до 20:00. При заранее согласованном позднем заселении ключи можно получить на указанной стойке регистрации, которая работает круглосуточно, 24/7, согласно нашим инструкциям.',
 'office_gudauri'=>'В Гудаури ключи можно получить на стойке регистрации в здании вашего проживания: она работает круглосуточно, 24/7. Рекомендуем заранее связаться с нами и сообщить время прибытия, чтобы мы могли организовать вашу встречу.',
 'p_keys'=>'Ключи выдаются после выполнения требований по оплате и удостоверению личности. Для прибытия после 20:00 заранее сообщите время и получите письменное подтверждение компании по email или WhatsApp. Прибытие после 23:59 согласуется отдельно; звонок необходимо подтвердить письменно.',
 'cancel_h'=>'Условия отмены бронирования','confirmed_rate'=>'Подтверждённый тариф','accepted_terms'=>'Принятые условия','terms_accepted'=>'Условия приняты','full_terms'=>'Полные условия',
 'c_free'=>'Бесплатная отмена до 23:59 %1$s: уплаченная сумма возвращается полностью (%2$s).',
 'c_mid'=>'С 00:00 %1$s до 23:59 %2$s: удерживается 30%% стоимости бронирования (%3$s); к возврату: %4$s.',
 'c_late'=>'С 00:00 %1$s: фактически уплаченная сумма не возвращается (%2$s).',
 'c_lastmin'=>'Тариф Last Minute (бронирование с 00:00 дня накануне заезда): предоплата 100%, невозвратный.',
 'c_extras'=>'Завтрак и трансфер','c_extras_default'=>'отменяются по условиям тарифа проживания. Отмена услуги не отменяет проживание.',
 'p_tz'=>'Все сроки указаны по местному времени Грузии (Asia/Tbilisi, UTC+4). Для однозначного письменного запроса об отмене учитывается время его получения на нашу официальную электронную почту или в WhatsApp, а не время прочтения сотрудником.',
 'p_noshow'=>'Незаезд: если вы не прибыли до 23:59 в дату заезда и не имеете письменного подтверждения более позднего прибытия, фактически уплаченная сумма не возвращается, кроме случаев, предусмотренных обязательными нормами закона или согласованным письменным исключением. Неоплаченные 70% не списываются автоматически только по причине отмены или незаезда.',
 'p_rights'=>'Применяются принятые условия бронирования. Эти условия не ограничивают ваши законные права, в том числе при непредоставлении согласованной услуги.',
 'requests_h'=>'Пожелания и договорённости','requests_note'=>'Дополнительные пожелания требуют отдельного подтверждения.',
 'help_h'=>'Мы готовы помочь','reservations'=>'Бронирование','phone'=>'Телефон',
 'office_line'=>'Офис компании в Батуми · Ежедневно 10:00–20:00 (по времени Грузии)','office_addr'=>'Батуми, ул. Шерифа Химшиашвили, 7d, Orbi City, блок C 13-й этаж, офис 1333',
 'office_note_batumi'=>'Ваши апартаменты и стойка регистрации могут находиться в другом корпусе. Руководствуйтесь указанными выше подтверждёнными данными объекта и инструкциями по получению ключей.',
 'office_note_gudauri'=>'Это адрес нашего офиса в Батуми. Для проживания в Гудаури руководствуйтесь указанными выше данными объекта и стойки регистрации.',
 'city_batumi'=>'Батуми','city_gudauri'=>'Гудаури','addr_batumi'=>'ул. Шерифа Химшиашвили, 7d, Orbi City, Батуми, Грузия','addr_gudauri'=>'Redco New Gudauri, Гудаури 4702, Грузия',
 'mail_subject'=>'Ваше бронирование подтверждено · %s','mail_subject_update'=>'Обновлённое подтверждение бронирования · %s',
 'mail_body'=>'Здравствуйте, %s!<br>Подтверждение бронирования — во вложении (PDF). Сохраните его и предъявите при заселении вместе с оригиналом паспорта или удостоверения личности.',
 'mail_link'=>'Открыть подтверждение онлайн','download'=>'Скачать PDF','print'=>'Печать',
 'months'=>['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'],
],
'ka'=>[
 'title'=>'დაჯავშნის დადასტურება','confirmed'=>'დადასტურებულია','booking_no'=>'ჯავშანი №','invoice_no'=>'ინვოისი №','version'=>'ვერსია','issued'=>'გაცემულია',
 'greeting'=>'გამარჯობა, %s! თქვენი ჯავშანი დადასტურებულია. მოხარულები ვიქნებით, გიმასპინძლოთ.',
 'lead_guest'=>'მთავარი სტუმარი','guests_stay'=>'სტუმრები და ყოფნის ხანგრძლივობა','adults'=>'ზრდასრულები','children'=>'ბავშვები','nights'=>'ღამეები','guests'=>'სტუმრები',
 'location'=>'მდებარეობა და ობიექტი','address'=>'საცხოვრებელი ობიექტის მისამართი','block'=>'ბლოკი / კორპუსი','apt'=>'აპარტამენტის ნომერი','apartment'=>'აპარტამენტი',
 'checkin'=>'შესვლა','checkin_time'=>'14:00–23:59 · საქართველოს დროით','checkout'=>'გასვლა','checkout_time'=>'11:00-მდე · საქართველოს დროით',
 'category'=>'კატეგორია','rate'=>'ტარიფი','contact'=>'სტუმრის საკონტაქტო ინფორმაცია','arrival'=>'ჩამოსვლის სავარაუდო დრო','arrival_tz'=>'(საქართველოს დროით)',
 'pay_h'=>'გადახდის ინფორმაცია','total'=>'საერთო ღირებულება','paid'=>'გადახდილია — %s%%','balance'=>'გადასახდელი ნაშთი — %s%%','payment'=>'გადახდა','txn'=>'ოპერაციის ნომერი',
 'pay_status'=>'გადახდის სტატუსი','st_unpaid'=>'გადაუხდელია','st_partial'=>'ნაწილობრივ გადახდილია','st_full'=>'სრულად გადახდილია',
 'balance_line'=>'დარჩენილი თანხა უნდა გადაიხადოთ დაბინავებისას, გასაღებების მიღებამდე.','overpaid'=>'ზედმეტად გადახდილი თანხა შესადარებლად',
 'm_card'=>'საბანკო ბარათი (ონლაინ)','m_transfer'=>'საბანკო გადარიცხვა','m_cash'=>'ნაღდი ფული','m_terminal'=>'ბარათის ტერმინალი',
 'services_h'=>'თქვენ მიერ არჩეული მომსახურება','svc_col'=>'დაჯავშნილი მომსახურება','amt_col'=>'თანხა GEL-ში','accommodation'=>'განთავსება · ღამეები: %d',
 'breakfast'=>'საუზმე','transfer'=>'ტრანსფერი','added'=>'დამატებულია','not_booked'=>'არ არის დაჯავშნილი','on_request'=>'ფასი მოთხოვნით',
 'taxes'=>'საერთო ღირებულება მოიცავს შესაბამის გადასახადებსა და მითითებულ სავალდებულო მოსაკრებლებს.',
 'one_way'=>'ერთი მიმართულებით','round_trip'=>'ორივე მიმართულებით','car'=>'მსუბუქი ავტომობილი','minivan'=>'მინივენი',
 'pickup'=>'ტრანსპორტის მოსვლა','meeting'=>'შეხვედრის ადგილი','airport'=>'ჩამოფრენის აეროპორტი','terminal'=>'ტერმინალი','flight_arrival'=>'ჩამოფრენა','airport_tz'=>'(აეროპორტის ადგილობრივი დროით)',
 'airline'=>'ავიაკომპანია და რეისი','ticket'=>'ბილეთი / ფრენის მარშრუტის დოკუმენტი','ticket_received'=>'მიღებულია','ticket_pending'=>'ველოდებით','pax'=>'მგზავრები და ბარგი','driver'=>'მძღოლი ან კოორდინატორი',
 'transfer_note'=>'აეროპორტიდან ტრანსფერისთვის წინასწარ შეგვატყობინეთ ჩამოფრენის მონაცემები და გამოგვიგზავნეთ ბილეთი ან ფრენის მარშრუტის დოკუმენტი. რეისის ცვლილების შემთხვევაში გვაცნობეთ.',
 'only_confirmed'=>'ჯავშანი მოიცავს მხოლოდ ზემოთ დადასტურებულ მომსახურებას.',
 'before_h'=>'თქვენს ჩამოსვლამდე','guest_info'=>'ინფორმაცია სტუმრისთვის','checkin_h'=>'შესვლა და გასაღებების მიღება','key_collection'=>'გასაღებების მიღება','checkin_instr'=>'დაბინავების ინსტრუქციები',
 'p_present'=>'შესვლისას წარადგინეთ ვაუჩერი ან მიუთითეთ ინვოისის ნომერი, ასევე წარადგინეთ მოქმედი პასპორტის ან პირადობის დამადასტურებელი დოკუმენტის ორიგინალი.',
 'p_arrival'=>'გთხოვთ, მიუთითოთ ჩამოსვლის თარიღი და სავარაუდო დრო. თუ თქვენი გეგმები შეიცვლება, წინასწარ შეგვატყობინეთ.',
 'office_batumi'=>'ჩვენი ოფისი ბათუმში ყოველდღე ღიაა 10:00-დან 20:00-მდე. წინასწარ შეთანხმებული გვიანი დაბინავების შემთხვევაში გასაღებების მიღება შესაძლებელია ჩვენი ინსტრუქციების შესაბამისად, მითითებულ რეგისტრაციის დახლთან, რომელიც სადღეღამისოდ მუშაობს, 24/7.',
 'office_gudauri'=>'გუდაურში გასაღებების მიღება შესაძლებელია თქვენი საცხოვრებელი შენობის რეგისტრაციის დახლთან, რომელიც სადღეღამისოდ მუშაობს, 24/7. გირჩევთ, წინასწარ დაგვიკავშირდეთ და გვაცნობოთ ჩამოსვლის დრო, რათა დაგხვდეთ.',
 'p_keys'=>'გასაღებები გაიცემა გადახდისა და ვინაობის დადასტურების მოთხოვნების შესრულების შემდეგ. თუ 20:00-ის შემდეგ აპირებთ ჩამოსვლას, წინასწარ შეგვატყობინეთ ჩამოსვლის დრო და მიიღეთ კომპანიის წერილობითი დადასტურება ელფოსტით ან WhatsApp-ით. 23:59-ის შემდეგ ჩამოსვლა ცალკე უნდა შეთანხმდეს; სატელეფონო შეთანხმება წერილობით უნდა დადასტურდეს.',
 'cancel_h'=>'ჯავშნის გაუქმების პირობები','confirmed_rate'=>'დადასტურებული ტარიფი','accepted_terms'=>'შეთანხმებული პირობები','terms_accepted'=>'პირობებზე თანხმობა დაფიქსირებულია','full_terms'=>'სრული პირობები',
 'c_free'=>'უფასო გაუქმება %1$s 23:59-მდე: გადახდილი თანხა სრულად ბრუნდება (%2$s).',
 'c_mid'=>'%1$s 00:00-დან %2$s 23:59-მდე: იკავება ჯავშნის ღირებულების 30%% (%3$s); დასაბრუნებელი თანხა: %4$s.',
 'c_late'=>'%1$s 00:00-დან: ფაქტობრივად გადახდილი თანხა არ ბრუნდება (%2$s).',
 'c_lastmin'=>'ტარიფი Last Minute (ჯავშანი ჩამოსვლის წინა დღის 00:00-დან): 100% წინასწარი გადახდა, თანხა არ ბრუნდება.',
 'c_extras'=>'საუზმე და ტრანსფერი','c_extras_default'=>'უქმდება განთავსების ტარიფის პირობებით. მომსახურების გაუქმება არ აუქმებს განთავსებას.',
 'p_tz'=>'ყველა ვადა მითითებულია საქართველოს ადგილობრივი დროით (Asia/Tbilisi, UTC+4). გაუქმების მკაფიო წერილობითი მოთხოვნის შემთხვევაში ითვლება ჩვენს ოფიციალურ ელფოსტაზე ან WhatsApp-ში მისი მიღების დრო და არა თანამშრომლის მიერ მისი წაკითხვის დრო.',
 'p_noshow'=>'გამოუცხადებლობა: თუ შესვლის დღეს 23:59-მდე არ გამოცხადდებით და უფრო გვიან ჩამოსვლის წერილობითი დადასტურება არ გაქვთ, ფაქტობრივად გადახდილი თანხა არ დაბრუნდება, გარდა კანონის სავალდებულო ნორმებით გათვალისწინებული შემთხვევებისა ან წერილობით შეთანხმებული გამონაკლისისა. გადაუხდელი 70% ავტომატურად არ ჩამოიჭრება მხოლოდ ჯავშნის გაუქმების ან გამოუცხადებლობის გამო.',
 'p_rights'=>'მოქმედებს ჯავშნის პირობები, რომლებსაც დაეთანხმეთ. ეს პირობები არ ზღუდავს თქვენს კანონიერ უფლებებს, მათ შორის შეთანხმებული მომსახურების გაუწევლობის შემთხვევაში.',
 'requests_h'=>'სურვილები და შეთანხმებები','requests_note'=>'დამატებითი სურვილები ცალკე დადასტურებას საჭიროებს.',
 'help_h'=>'მზად ვართ დაგეხმაროთ','reservations'=>'დაჯავშნა','phone'=>'ტელეფონი',
 'office_line'=>'კომპანიის ოფისი ბათუმში · ყოველდღე 10:00–20:00 (საქართველოს დროით)','office_addr'=>'ბათუმი, შერიფ ხიმშიაშვილის ქ. 7d, Orbi City, ბლოკი C მე-13 სართული, ოფისი 1333',
 'office_note_batumi'=>'თქვენი აპარტამენტი და რეგისტრაციის დახლი შესაძლოა სხვა კორპუსში მდებარეობდეს. იხელმძღვანელეთ ზემოთ მითითებული ობიექტის დადასტურებული მონაცემებითა და გასაღებების მიღების ინსტრუქციებით.',
 'office_note_gudauri'=>'ეს ჩვენი ბათუმის ოფისის მისამართია. გუდაურში განთავსებისას იხელმძღვანელეთ ზემოთ მითითებული ობიექტისა და რეგისტრაციის დახლის მონაცემებით.',
 'city_batumi'=>'ბათუმი','city_gudauri'=>'გუდაური','addr_batumi'=>'შერიფ ხიმშიაშვილის ქ. 7d, Orbi City, ბათუმი, საქართველო','addr_gudauri'=>'Redco New Gudauri, გუდაური 4702, საქართველო',
 'mail_subject'=>'თქვენი ჯავშანი დადასტურებულია · %s','mail_subject_update'=>'ჯავშნის განახლებული დადასტურება · %s',
 'mail_body'=>'გამარჯობა, %s!<br>ჯავშნის დადასტურება თანდართულია PDF ფორმატში. შეინახეთ და წარადგინეთ შესვლისას პასპორტის ან პირადობის დამადასტურებელი დოკუმენტის ორიგინალთან ერთად.',
 'mail_link'=>'დადასტურების ონლაინ ნახვა','download'=>'PDF-ის ჩამოტვირთვა','print'=>'ბეჭდვა',
 'months'=>['იანვარი','თებერვალი','მარტი','აპრილი','მაისი','ივნისი','ივლისი','აგვისტო','სექტემბერი','ოქტომბერი','ნოემბერი','დეკემბერი'],
],
];}

// ---------- Formatting (amounts are kept in tetri, 1 GEL = 100 tetri) ----------
function luxv_date($ymd,$loc){$d=$ymd instanceof DateTimeInterface?$ymd:lux_ymd((string)$ymd);if(!$d)return (string)$ymd;$m=luxv_t($loc,'months')[(int)$d->format('n')-1];
 return $loc==='ka'?$d->format('j').' '.$m.', '.$d->format('Y'):$d->format('j').' '.$m.' '.$d->format('Y');}
function luxv_datetime($mysql,$loc){$t=strtotime((string)$mysql);return $t?luxv_date(gmdate('Y-m-d',$t),$loc).', '.gmdate('H:i',$t):'';}
function luxv_money($tetri,$loc){$neg=$tetri<0;$t=abs((int)$tetri);$int=intdiv($t,100);$frac=str_pad((string)($t%100),2,'0',STR_PAD_LEFT);
 $g=$loc==='en'?number_format($int,0,'.',','):number_format($int,0,'.',"\u{00A0}");return ($neg?'−':'').$g.($loc==='en'?'.':',').$frac."\u{00A0}GEL";}
function luxv_pct($v,$loc){$s=rtrim(rtrim(number_format($v,2,'.',''),'0'),'.');return $loc==='en'?$s:str_replace('.',',',$s);}
function luxv_tetri($gel){return (int)round(((float)str_replace([' ',','],['','.'],(string)$gel))*100);}

// ---------- Numbers, language, property ----------
function luxv_next_invoice(){
 $lock='lux_invoice_seq_lock';for($i=0;$i<50&&!add_option($lock,time(),'','no');$i++){if((int)get_option($lock)<time()-10)delete_option($lock);usleep(100000);}
 $n=(int)get_option('lux_invoice_seq',0)+1;update_option('lux_invoice_seq',$n,false);delete_option($lock);
 return 'INV-'.wp_date('Y').'-'.str_pad((string)$n,6,'0',STR_PAD_LEFT);
}
function luxv_invoice($id){$n=(string)get_post_meta($id,'_lux_invoice',true);if($n==='')add_post_meta($id,'_lux_invoice',luxv_next_invoice(),true);return (string)get_post_meta($id,'_lux_invoice',true);}
// The language the guest used on the site (Google Translate cookie), saved with the booking.
function luxv_detect_locale(){$c=isset($_COOKIE['googtrans'])?sanitize_text_field(wp_unslash($_COOKIE['googtrans'])):'';$g=strtolower(substr((string)strrchr('/'.$c,'/'),1));return isset(LUXV_LOCALES[$g])?$g:'en';}
function luxv_locale($id){$v=(string)get_post_meta($id,'_lux_voucher_locale',true);if(isset(LUXV_LOCALES[$v]))return $v;$d=get_post_meta($id,'_lux_request',true);return isset(LUXV_LOCALES[$d['locale']??''])?$d['locale']:'en';}
function luxv_city($d){foreach(($d['apartments']??[]) as $a)if(($a['city']??'')==='gudauri')return 'gudauri';return 'batumi';}
// Defaults for each apartment: block from the listing, number from the title ("ORBI - A - 38/01" → 38/01).
function luxv_apartment_defaults($a){$id=(int)($a['id']??0);$parts=array_map('trim',preg_split('/\s+[-–—]\s+/u',(string)($a['title']??'')));
 return ['property'=>($a['city']??'')==='gudauri'?'Four Seasons':'Orbi City','block'=>(string)get_post_meta($id,'_lux_block',true)?:(count($parts)>2?$parts[1]:''),'number'=>count($parts)>1?end($parts):'','category'=>(string)get_post_meta($id,'_lux_bedrooms',true)];}

// ---------- Payments and balance ----------
function luxv_payments($id){$p=get_post_meta($id,'_lux_payments',true);return is_array($p)?$p:[];}
function luxv_total($id){$o=get_post_meta($id,'_lux_agreed_total',true);if($o!==''&&$o!==false&&$o!==null)return (int)$o;$d=get_post_meta($id,'_lux_request',true);$t=$d['breakdown']['total']??null;return $t===null?null:luxv_tetri($t);}
function luxv_balance($id){
 $T=luxv_total($id);$P=array_sum(array_map(fn($p)=>(int)$p['amount'],luxv_payments($id)));
 if(!$T)return ['total'=>$T,'paid'=>$P,'balance'=>null,'over'=>0,'paid_pct'=>null,'balance_pct'=>null,'status'=>$P>0?'partial':'unpaid'];
 $B=$T-$P;$over=$B<0?-$B:0;$B=max(0,$B);
 $pp=$P>=$T?100.0:floor($P*10000/$T)/100;if($B>0&&$pp>=100)$pp=99.99; // 0.01 GEL left is never shown as 100%
 return ['total'=>$T,'paid'=>$P,'balance'=>$B,'over'=>$over,'paid_pct'=>$pp,'balance_pct'=>$B>0?round(100-$pp,2):0.0,'status'=>$P<=0?'unpaid':($B===0?'full':'partial')];
}
// Standard Booking, or Last Minute when the booking was made from 00:00 on the day before arrival (Georgia time).
function luxv_rate($d){$in=lux_ymd($d['checkin']??'');$c=substr((string)($d['created']??''),0,10);return $in&&$c&&$c>=$in->modify('-1 day')->format('Y-m-d')?'last_minute':'standard';}
function luxv_required($id,$d){$bal=luxv_balance($id);if(!$bal['total'])return null;if(luxv_rate($d)==='last_minute')return $bal['total'];return (int)ceil($bal['total']*30/100);}

// What is still missing before the final voucher can be issued.
function luxv_missing($id){
 $d=get_post_meta($id,'_lux_request',true);if(!is_array($d)||($d['kind']??'')==='experience')return ['not an apartment booking'];$m=[];
 if(get_post_meta($id,'_lux_status',true)!=='confirmed')$m[]='status “Confirmed by manager”';
 $bal=luxv_balance($id);if(!$bal['total'])$m[]='agreed total (price on request)';
 else{$req=luxv_required($id,$d);if($bal['paid']<$req)$m[]='payment of at least '.luxv_money($req,'en').' ('.(luxv_rate($d)==='last_minute'?'Last Minute: 100%':'30% prepayment').')';}
 $ov=(array)get_post_meta($id,'_lux_apartments_voucher',true);
 foreach($d['apartments'] as $i=>$a){$def=luxv_apartment_defaults($a);foreach(['block'=>'block','number'=>'apartment number'] as $k=>$label)if(trim((string)($ov[$i][$k]??''))===''&&$def[$k]==='')$m[]=$label.' for '.$a['title'];}
 return $m;
}

// ---------- Data snapshot for one voucher version ----------
function luxv_snapshot($id){
 $d=get_post_meta($id,'_lux_request',true);$loc=luxv_locale($id);$city=luxv_city($d);$x=(array)get_post_meta($id,'_lux_voucher_fields',true);$ov=(array)get_post_meta($id,'_lux_apartments_voucher',true);
 $in=lux_ymd($d['checkin']);$out=lux_ymd($d['checkout']);$aps=[];$guests=0;
 foreach($d['apartments'] as $i=>$a){$def=luxv_apartment_defaults($a);$o=(array)($ov[$i]??[]);$guests+=(int)$a['guests'];$ac=($a['city']??'')==='gudauri'?'gudauri':'batumi';
  $aps[]=['title'=>$a['title'],'city'=>$ac,'property'=>trim($o['property']??'')?:$def['property'],'address'=>trim($o['address']??'')?:luxv_t($loc,'addr_'.$ac),'block'=>trim($o['block']??'')?:$def['block'],'number'=>trim($o['number']??'')?:$def['number'],'category'=>$def['category']];}
 return ['booking_id'=>$id,'reference'=>$d['reference'],'invoice'=>luxv_invoice($id),'locale'=>$loc,'city'=>$city,'name'=>$d['name'],'email'=>$d['email'],'phone'=>$d['phone'],
  'adults'=>($x['adults']??'')!==''?(int)$x['adults']:$guests,'children'=>(int)($x['children']??0),'checkin'=>$d['checkin'],'checkout'=>$d['checkout'],'nights'=>$in&&$out?$out->diff($in)->days:0,
  'apartments'=>$aps,'rate'=>luxv_rate($d),'created'=>$d['created']??'','breakdown'=>$d['breakdown']??null,'balance'=>luxv_balance($id),'payments'=>luxv_payments($id),'booking_status'=>get_post_meta($id,'_lux_status',true),
  'fields'=>$x,'terms_url'=>home_url('/booking-and-payment-terms/'),'terms_version'=>LUXV_TERMS_VERSION];
}

// ---------- Template (same HTML for the PDF and the web page; tables only, so the PDF engine lays it out exactly) ----------
function luxv_html($s){
 $L=$s['locale'];$t=fn($k)=>luxv_t($L,$k);$e='esc_html';$bal=$s['balance'];$f=$s['fields'];$b=$s['breakdown'];$city=$s['city'];
 $logo=is_readable(__DIR__.'/assets/voucher-logo.jpg')?'data:image/jpeg;base64,'.base64_encode((string)file_get_contents(__DIR__.'/assets/voucher-logo.jpg')):'';
 $up=fn($x)=>$L==='ka'?$x:mb_strtoupper($x); // Georgian capitals (Mtavruli) are not used in running text and the PDF font has no glyphs for them
 $cell=fn($label,$value,$extra='')=>'<td class="cell'.$extra.'"><div class="lab">'.$e($label).'</div><div class="val">'.$value.'</div></td>';
 $h='<div class="v lang-'.esc_attr($L).'">';
 $h.='<table class="head"><tr><td style="width:84px">'.($logo?'<img src="'.$logo.'" alt="Luxury Apart Hotel Group" style="width:72px;height:auto">':'').'</td><td class="brand">LUXURY APART HOTEL GROUP &nbsp;|&nbsp; '.$e($up($t('city_'.$city))).'</td></tr></table>';
 $h.='<h1>'.$e($t('title')).'</h1>';
 $h.='<p class="gold">'.$e($t('confirmed')).' · '.$e($t('booking_no')).' '.$e($s['reference']).'<br>'.$e($t('invoice_no')).' '.$e($s['invoice']).' · '.$e($t('version')).' '.(int)$s['version'].' · '.$e($t('issued')).' '.$e(luxv_datetime($s['issued'],$L)).'</p>';
 $h.='<p class="lead">'.$e(sprintf($t('greeting'),$s['name'])).'</p>';
 $h.='<table class="grid"><tr>'.$cell($t('lead_guest'),$e($s['name'])).$cell($t('guests_stay'),$e($t('adults').': '.$s['adults'].' · '.$t('children').': '.$s['children'].' · '.$t('nights').': '.$s['nights'])).'</tr>';
 $multi=count($s['apartments'])>1;
 foreach($s['apartments'] as $n=>$a){
  if($multi)$h.='<tr><td colspan="2" class="aphead">'.$e($t('apartment').' '.($n+1).' · '.$a['title']).'</td></tr>';
  $h.='<tr>'.$cell($t('location'),$e($t('city_'.$a['city']).' · '.$a['property'])).$cell($t('address'),$e($a['address'])).'</tr>';
  $h.='<tr>'.$cell($t('block'),$e($a['block'])).$cell($t('apt'),$e($a['number'])).'</tr>';
 }
 $h.='<tr>'.$cell($t('checkin'),'<span class="big">'.$e(luxv_date($s['checkin'],$L)).'</span><div class="small">'.$e($t('checkin_time')).'</div>',' shade').$cell($t('checkout'),'<span class="big">'.$e(luxv_date($s['checkout'],$L)).'</span><div class="small">'.$e($t('checkout_time')).'</div>',' shade').'</tr></table>';
 $cats=array_unique(array_filter(array_column($s['apartments'],'category')));
 $h.='<p class="meta">'.($cats?$e($t('category')).': '.$e(implode(', ',$cats)).' · ':'').$e($t('rate')).': '.$e($s['rate']==='last_minute'?'Last Minute':'Standard Booking').'<br>'.$e($t('contact')).': '.$e($s['email'].' / '.$s['phone']);
 if(!empty($f['arrival_date'])||!empty($f['arrival_time']))$h.='<br>'.$e($t('arrival')).': '.$e(trim((!empty($f['arrival_date'])?luxv_date($f['arrival_date'],$L):'').(!empty($f['arrival_time'])?' · '.$f['arrival_time']:''),' ·')).' '.$e($t('arrival_tz'));
 $h.='</p>';
 // Payment
 $h.='<h2>'.$e($t('pay_h')).'</h2><table class="grid pay"><tr>'.$cell($t('total'),'<span class="big">'.$e(luxv_money((int)$bal['total'],$L)).'</span>',' shade');
 $h.=$cell(sprintf($t('paid'),luxv_pct((float)$bal['paid_pct'],$L)),'<span class="big">'.$e(luxv_money($bal['paid'],$L)).'</span>',' shade');
 $h.=$cell(sprintf($t('balance'),luxv_pct((float)$bal['balance_pct'],$L)),'<span class="big">'.$e(luxv_money((int)$bal['balance'],$L)).'</span>',' shade').'</tr></table>';
 foreach($s['payments'] as $p)$h.='<p class="small">'.$e($t('payment').': '.$t('m_'.($p['method']??'card')).' · '.luxv_date($p['date']??'',$L).(!empty($p['txn'])?' · '.$t('txn').' '.$p['txn']:'').' · '.luxv_money((int)$p['amount'],$L)).'</p>';
 if($bal['over']>0)$h.='<p class="small">'.$e($t('overpaid').': '.luxv_money($bal['over'],$L)).'</p>';
 $h.='<p class="status"><strong>'.$e($t('pay_status')).':</strong> '.$e($t('st_'.$bal['status'])).'</p>';
 if($s['booking_status']==='confirmed'&&$bal['status']==='partial'&&$bal['balance']>0)$h.='<p class="status">'.$e($t('balance_line')).'</p>';
 // Services
 $acc=isset($b['accommodation'])&&$b['accommodation']!==null?luxv_money(luxv_tetri($b['accommodation']),$L):'—';
 $bf=$b['breakfast']??null;$tr=$b['transfer']??null;
 $h.='<h2 class="xl">'.$e($t('services_h')).'</h2><table class="svc"><tr><th>'.$e($up($t('svc_col'))).'</th><th class="r">'.$e($up($t('amt_col'))).'</th></tr>';
 $h.='<tr><td>'.$e(sprintf($t('accommodation'),$s['nights'])).'</td><td class="r">'.$e($acc).'</td></tr>';
 $h.='<tr><td>'.$e($t('breakfast').' · '.(!empty($bf['guests'])?$t('added'):$t('not_booked'))).'</td><td class="r">'.$e(!empty($bf['guests'])?luxv_money(luxv_tetri($bf['total']),$L):'—').'</td></tr>';
 $h.='<tr><td>'.$e($t('transfer').' · '.($tr?$t('added'):$t('not_booked'))).'</td><td class="r">'.$e($tr?($tr['total']===null?$t('on_request'):luxv_money(luxv_tetri($tr['total']),$L)):'—').'</td></tr></table>';
 $h.='<p class="small">'.$e($t('taxes')).'</p>';
 if(!empty($bf['guests'])){$bits=[luxv_date($s['checkin'],$L).' – '.luxv_date($s['checkout'],$L),$t('guests').': '.$bf['guests']];foreach(['breakfast_format','breakfast_venue','breakfast_time'] as $k)if(!empty($f[$k]))$bits[]=$f[$k];$h.='<h3>'.$e($t('breakfast')).'</h3><p>'.$e(implode(' · ',$bits)).'</p>';}
 if($tr){$lines=[$tr['name'].' · '.$t($tr['trip']==='round'?'round_trip':'one_way').' · '.$t(($tr['vehicle']??'car')==='minivan'?'minivan':'car')];
  if(!empty($f['pickup'])||!empty($f['meeting']))$lines[]=trim((!empty($f['pickup'])?$t('pickup').': '.$f['pickup']:'').(!empty($f['meeting'])?' · '.$t('meeting').': '.$f['meeting']:''),' ·');
  if(!empty($f['airport']))$lines[]=$t('airport').': '.$f['airport'].(!empty($f['terminal'])?' · '.$t('terminal').' '.$f['terminal']:'');
  if(!empty($f['flight_date'])||!empty($f['flight_time']))$lines[]=$t('flight_arrival').': '.trim((!empty($f['flight_date'])?luxv_date($f['flight_date'],$L):'').(!empty($f['flight_time'])?' · '.$f['flight_time']:''),' ·').' '.$t('airport_tz');
  if(!empty($f['airline'])||!empty($f['flight_no']))$lines[]=$t('airline').': '.trim(($f['airline']??'').' · '.($f['flight_no']??''),' ·');
  if(!empty($f['ticket']))$lines[]=$t('ticket').': '.$t('ticket_'.$f['ticket']);
  if(!empty($f['pax']))$lines[]=$t('pax').': '.$f['pax'];
  if(!empty($f['driver']))$lines[]=$t('driver').': '.$f['driver'];
  $h.='<h3>'.$e($t('transfer')).'</h3><p>'.implode('<br>',array_map($e,$lines)).'</p><p class="small">'.$e($t('transfer_note')).'</p>';}
 $h.='<p class="small">'.$e($t('only_confirmed')).'</p>';
 // Page 2
 $h.='<div class="page2"><h2>'.$e($t('before_h')).'</h2><p class="gold">'.$e($up($t('guest_info'))).' · '.$e($t('booking_no').' '.$s['reference']).' · '.$e($t('invoice_no').' '.$s['invoice']).'</p>';
 $h.='<h2>'.$e($t('checkin_h')).'</h2>';
 if(!empty($f['keys'])||!empty($f['instructions']))$h.='<p>'.(!empty($f['keys'])?'<strong>'.$e($t('key_collection')).':</strong> '.$e($f['keys']):'').(!empty($f['keys'])&&!empty($f['instructions'])?'<br>':'').(!empty($f['instructions'])?'<strong>'.$e($t('checkin_instr')).':</strong> '.nl2br($e($f['instructions'])):'').'</p>';
 foreach(['p_present','p_arrival','office_'.$city,'p_keys'] as $k)$h.='<p>'.$e($t($k)).'</p>';
 // Cancellation (R3.3): D = check-in date in Georgia time.
 $h.='<h2 class="xl">'.$e($t('cancel_h')).'</h2><p>'.$e($t('confirmed_rate')).': '.$e($s['rate']==='last_minute'?'Last Minute':'Standard Booking').' · '.$e($t('accepted_terms')).': '.$e($s['terms_version'].' · '.luxv_date(substr($s['created'],0,10),$L)).'<br>'.$e($t('terms_accepted')).': '.$e(luxv_datetime($s['created'],$L)).' · '.$e($t('full_terms')).': <a href="'.esc_url($s['terms_url']).'">'.$e(preg_replace('#^https?://#','',$s['terms_url'])).'</a></p>';
 $D=lux_ymd($s['checkin']);$P=(int)$bal['paid'];
 if($s['rate']==='last_minute')$h.='<p>'.$e($t('c_lastmin')).'</p>';
 elseif($D){$ret=(int)round((int)$bal['total']*0.3);
  $h.='<p>'.$e(sprintf($t('c_free'),luxv_date($D->modify('-7 day'),$L),luxv_money($P,$L))).'<br>'.$e(sprintf($t('c_mid'),luxv_date($D->modify('-6 day'),$L),luxv_date($D->modify('-2 day'),$L),luxv_money($ret,$L),luxv_money(max(0,$P-$ret),$L))).'<br>'.$e(sprintf($t('c_late'),luxv_date($D->modify('-1 day'),$L),luxv_money($P,$L))).'</p>';}
 if(!empty($bf['guests'])||$tr)$h.='<p>'.$e($t('c_extras')).': '.$e(!empty($f['extras_terms'])?$f['extras_terms']:$t('c_extras_default')).'</p>';
 foreach(['p_tz','p_noshow','p_rights'] as $k)$h.='<p class="small">'.$e($t($k)).'</p>';
 if(!empty($f['arrangements']))$h.='<h2>'.$e($t('requests_h')).'</h2><p>'.nl2br($e($f['arrangements'])).'</p><p class="small">'.$e($t('requests_note')).'</p>';
 $h.='<h2>'.$e($t('help_h')).'</h2><table class="contacts"><tr><td><strong>WhatsApp</strong><br>+995 557 528 285</td><td><strong>'.$e($t('reservations')).'</strong><br>reservations@luxuryaparthotel.ge</td><td><strong>'.$e($t('phone')).'</strong><br>+995 555 907 333</td></tr></table>';
 $h.='<p class="small">'.$e($t('office_line')).'<br>'.$e($t('office_addr')).'</p><p class="small">'.$e($t('office_note_'.$city)).'</p></div></div>';
 return $h;
}
// Fonts follow the templates: Georgia headings + Calibri text (RU/EN), Noto Serif Georgian + Noto Sans Georgian (KA).
// Georgia and Calibri cannot be shipped, so the PDF uses their open counterparts: Noto Serif and Carlito (Calibri-metric).
// Noto Georgian has no Latin or digits; those characters fall back to the next font in the list.
function luxv_fonts(){return ['Carlito'=>'Carlito','Noto Serif'=>'NotoSerif','Noto Sans Georgian'=>'NotoSansGeorgian','Noto Serif Georgian'=>'NotoSerifGeorgian'];}
function luxv_font_faces($base){$css='';foreach(luxv_fonts() as $fam=>$file)foreach(['normal'=>'Regular','bold'=>'Bold'] as $w=>$sfx)$css.="@font-face{font-family:'".$fam."';font-weight:".$w.";font-style:normal;src:url('".$base.$file.'-'.$sfx.".ttf') format('truetype')}";return $css;}
function luxv_css($forPdf){
 $sz=fn($pt,$px)=>$forPdf?$pt.'pt':$px.'px';
 $sans=$forPdf?"'Carlito','DejaVu Sans'":"Calibri,Carlito,'Segoe UI',Helvetica,Arial,sans-serif";
 $serif=$forPdf?"'Noto Serif','DejaVu Sans'":"Georgia,'Noto Serif','Times New Roman',serif";
 $kaSans="'Noto Sans Georgian',".$sans;$kaSerif="'Noto Serif Georgian',".$serif;
 return luxv_font_faces($forPdf?__DIR__.'/assets/fonts/':plugins_url('assets/fonts/',__FILE__)).($forPdf?'@page{margin:18mm 18mm 16mm}':'').'
 .v{font-family:'.$sans.';color:#171717;font-size:'.$sz(10.5,16).';line-height:1.3}
 .v h1,.v h2{font-family:'.$serif.';font-weight:normal;color:#171717;page-break-after:avoid;line-height:1.15}
 .v h1,.v h2.xl{font-size:'.$sz(24,34).';margin:'.$sz(4,8).' 0 '.$sz(6,10).'}.v h2{font-size:'.$sz(14,21).';margin:'.$sz(14,26).' 0 '.$sz(6,10).'}
 .v h3{font-size:'.$sz(10.5,16).';font-weight:bold;margin:'.$sz(10,16).' 0 '.$sz(3,4).';page-break-after:avoid}
 .v p{margin:0 0 '.$sz(5,8).'}.v .gold{color:#92754B;font-weight:bold;font-size:'.$sz(9,13).'}.v .lead{margin:'.$sz(8,12).' 0 '.$sz(10,14).';font-size:'.$sz(10.5,16).'}
 .v table{width:100%;border-collapse:collapse}.v .head td{vertical-align:bottom}.v .brand{font-size:'.$sz(9,13).';letter-spacing:.04em;padding-bottom:4px}
 .v .grid td.cell{border:1px solid #DCDCD6;padding:'.$sz(4,7).' '.$sz(6,9).';vertical-align:top;width:50%}.v .pay td.cell{width:33.3%}.v tr{page-break-inside:avoid}
 .v .shade{background:#F4F4F2}.v .lab{font-size:'.$sz(8,11).';color:#666666;text-transform:uppercase;letter-spacing:.03em}.v .pay .lab{font-size:'.$sz(8.5,12).'}.v .val{margin-top:2px;font-size:'.$sz(11,16).'}
 .v .big{font-size:'.$sz(14,21).';font-family:'.$serif.'}.v .small{font-size:'.$sz(9,13).';color:#666666}
 .v .aphead{padding:'.$sz(6,10).' 0 '.$sz(3,4).';font-weight:bold;border:0}.v .meta{font-size:'.$sz(9,13).';color:#444;margin-top:'.$sz(4,6).'}.v .status{margin:'.$sz(3,4).' 0;font-size:'.$sz(9.5,14).'}
 .v .svc th{background:#303030;color:#fff;text-align:left;padding:'.$sz(4,7).' '.$sz(6,9).';font-size:'.$sz(10,14).'}.v .svc td{border:1px solid #DCDCD6;padding:'.$sz(4,7).' '.$sz(6,9).';font-size:'.$sz(10,15).'}.v .r{text-align:right}
 .v .contacts td{padding:'.$sz(5,8).' '.$sz(6,9).';border:1px solid #DCDCD6;vertical-align:top;font-size:'.$sz(11,15).'}.v a{color:#171717}
 .v.lang-ka{font-family:'.$kaSans.'}.v.lang-ka h1,.v.lang-ka h2,.v.lang-ka .big{font-family:'.$kaSerif.'}.v.lang-ka .lab{text-transform:none;letter-spacing:0}
 .v .page2{margin-top:'.$sz(14,36).';padding-top:'.$sz(6,24).';border-top:1px solid #DCDCD6}.v h3+p,.v .lab+.val{page-break-before:avoid}';}

// ---------- PDF ----------
function luxv_pdf($s){
 if(!class_exists('\Dompdf\Dompdf'))require_once __DIR__.'/lib/vendor/autoload.php';
 $tmp=trailingslashit(get_temp_dir()).'lux-dompdf';wp_mkdir_p($tmp);
 // Metrics of the embedded fonts are cached in a writable, web-protected folder (lux-vouchers has "deny all").
 $cache=luxv_dir().'/fonts';wp_mkdir_p($cache);
 $o=new \Dompdf\Options();$o->set('defaultFont','Carlito');$o->set('isRemoteEnabled',false);$o->set('isFontSubsettingEnabled',true);
 $o->set('chroot',[__DIR__,$cache,$tmp]);$o->set('tempDir',$tmp);$o->set('fontDir',$cache);$o->set('fontCache',$cache);
 $pdf=new \Dompdf\Dompdf($o);
 $dejavu="@font-face{font-family:'DejaVu Sans';font-weight:normal;src:url('".__DIR__."/lib/vendor/dompdf/dompdf/lib/fonts/DejaVuSans.ttf')}@font-face{font-family:'DejaVu Sans';font-weight:bold;src:url('".__DIR__."/lib/vendor/dompdf/dompdf/lib/fonts/DejaVuSans-Bold.ttf')}";
 $pdf->loadHtml('<!doctype html><html lang="'.esc_attr($s['locale']).'"><head><meta charset="utf-8"><style>'.$dejavu.luxv_css(true).'</style></head><body>'.luxv_html($s).'</body></html>','UTF-8');
 $pdf->setPaper('A4');$pdf->render();
 $pdf->addInfo('Title',luxv_t($s['locale'],'title').' '.$s['reference'].' v'.$s['version']);$pdf->addInfo('Author','LLC Luxury Apart Hotel Group');
 return $pdf->output();
}
function luxv_dir(){$u=wp_upload_dir();$dir=trailingslashit($u['basedir']).'lux-vouchers';if(!is_dir($dir)){wp_mkdir_p($dir);file_put_contents($dir.'/.htaccess',"Require all denied\nDeny from all\n");file_put_contents($dir.'/index.php','<?php // Silence.');}return $dir;}
function luxv_versions($id){$v=get_post_meta($id,'_lux_voucher_versions',true);return is_array($v)?$v:[];}
function luxv_current($id){$v=luxv_versions($id);return $v?end($v):null;}
function luxv_file($v){if(!$v)return '';$f=luxv_dir().'/'.basename((string)($v['file']??''));return is_readable($f)?$f:'';}

// Issues the next version: snapshot → one PDF → stored with its SHA-256 → sent to the guest and, separately, to the company.
function luxv_issue($id,$reason='issued'){
 if(luxv_missing($id))return false;
 $lock='lux_vlock_'.$id;if(!add_option($lock,time(),'','no')){if((int)get_option($lock)<time()-60)delete_option($lock);return false;}
 $versions=luxv_versions($id);$n=count($versions)+1;$s=luxv_snapshot($id);$s['version']=$n;$s['issued']=current_time('mysql');
 try{$bytes=luxv_pdf($s);}catch(\Throwable $e){delete_option($lock);update_post_meta($id,'_lux_voucher_error',$e->getMessage());return false;}
 $name=sanitize_file_name($s['reference'].'-v'.$n.'-'.wp_generate_password(12,false).'.pdf');file_put_contents(luxv_dir().'/'.$name,$bytes);
 $versions[]=['version'=>$n,'file'=>$name,'sha256'=>hash('sha256',$bytes),'issued'=>$s['issued'],'locale'=>$s['locale'],'paid'=>$s['balance']['paid'],'total'=>$s['balance']['total'],'reason'=>$reason,'by'=>get_current_user_id(),'snapshot'=>$s];
 update_post_meta($id,'_lux_voucher_versions',$versions);delete_post_meta($id,'_lux_voucher_error');delete_option($lock);
 luxv_deliver($id,$n);return $n;
}
// Sends the stored file of version $n (never a regenerated one). Guest and company deliveries are logged separately.
function luxv_deliver($id,$n,$only=null){
 if(defined('LUXURY_DEMO')&&LUXURY_DEMO)return;
 $v=null;foreach(luxv_versions($id) as $x)if((int)$x['version']===(int)$n)$v=$x;if(!$v)return;$file=luxv_file($v);if(!$file)return;$s=$v['snapshot'];$L=$v['locale'];
 $log=get_post_meta($id,'_lux_voucher_log',true);$log=is_array($log)?$log:[];$company=function_exists('lux_booking_notify_email')?lux_booking_notify_email():'reservations@luxuryaparthotel.ge';
 $link=lux_voucher_url($id);
 if(!$only||$only==='guest'){
  $body='<div style="font-family:Helvetica,Arial,sans-serif;font-size:15px;color:#171717;line-height:1.5"><p>'.sprintf(luxv_t($L,'mail_body'),esc_html($s['name'])).'</p><p><a href="'.esc_url($link).'" style="color:#171717">'.esc_html(luxv_t($L,'mail_link')).'</a></p><p style="color:#666;font-size:13px">Luxury Apart Hotel Group · reservations@luxuryaparthotel.ge · WhatsApp +995 557 528 285</p></div>';
  $ok=wp_mail($s['email'],sprintf(luxv_t($L,$n>1?'mail_subject_update':'mail_subject'),$s['reference']),$body,['Content-Type: text/html; charset=UTF-8',luxv_from_header(),'Reply-To: Luxury Apart Hotel Group <reservations@luxuryaparthotel.ge>'],[$file]);
  $log[]=['version'=>$n,'to'=>$s['email'],'who'=>'guest','time'=>current_time('mysql'),'result'=>$ok?'sent':'failed','sha256'=>$v['sha256']];
  if($n===1)update_post_meta($id,'_lux_voucher_confirmed',$ok?current_time('mysql'):'failed');
 }
 if(!$only||$only==='company'){
  $body="Copy of the booking confirmation sent to the guest (same PDF).\n\nBooking: ".$s['reference']."\nInvoice: ".$s['invoice']."\nVersion: ".$n." (".$v['reason'].")\nLanguage: ".$L."\nGuest: ".$s['name']." <".$s['email'].">\nPaid: ".luxv_money($s['balance']['paid'],'en')." of ".luxv_money((int)$s['balance']['total'],'en')."\nPDF SHA-256: ".$v['sha256']."\n\n".admin_url('post.php?post='.$id.'&action=edit');
  $ok=wp_mail($company,'[Voucher copy] '.$s['reference'].' v'.$n.' · '.$s['name'],$body,[luxv_from_header(),'Reply-To: '.$s['name'].' <'.$s['email'].'>'],[$file]);
  $log[]=['version'=>$n,'to'=>$company,'who'=>'company','time'=>current_time('mysql'),'result'=>$ok?'sent':'failed','sha256'=>$v['sha256']];
 }
 update_post_meta($id,'_lux_voucher_log',$log);
}

// ---------- "Request received" email (sent on submit; it is not the confirmation voucher) ----------
// Mail goes out from the real Reservations mailbox: messages "from" a non-existent wordpress@ address are often dropped by Gmail.
function luxv_from_header(){return 'From: Luxury Apart Hotel Group <reservations@luxuryaparthotel.ge>';}
function luxv_request_texts($L){$T=[
 'en'=>['subject'=>'We received your booking request · %s','status'=>'REQUEST RECEIVED','title'=>'Booking request received','intro'=>'Dear %s, thank you for choosing Luxury Apart Hotel Group. We have received your request and are checking availability for your dates.','apartments'=>'Apartments','estimate'=>'Estimated total','prepay'=>'Prepayment','next'=>'Next steps: our team will confirm your booking and send you a secure payment link for the prepayment. As soon as the payment is received, you will get your booking confirmation (voucher) as a PDF.','note'=>'This email is not a booking confirmation.','on_request'=>'on request'],
 'ru'=>['subject'=>'Мы получили ваш запрос на бронирование · %s','status'=>'ЗАПРОС ПОЛУЧЕН','title'=>'Запрос на бронирование получен','intro'=>'Здравствуйте, %s! Спасибо, что выбрали Luxury Apart Hotel Group. Мы получили ваш запрос и проверяем наличие на ваши даты.','apartments'=>'Апартаменты','estimate'=>'Предварительная стоимость','prepay'=>'Предоплата','next'=>'Что дальше: наш менеджер подтвердит бронирование и пришлёт защищённую ссылку на предоплату. Как только оплата поступит, вы получите подтверждение бронирования (ваучер) в PDF.','note'=>'Это письмо не является подтверждением бронирования.','on_request'=>'по запросу'],
 'ka'=>['subject'=>'თქვენი დაჯავშნის მოთხოვნა მიღებულია · %s','status'=>'მოთხოვნა მიღებულია','title'=>'დაჯავშნის მოთხოვნა მიღებულია','intro'=>'გამარჯობა, %s! გმადლობთ, რომ აირჩიეთ Luxury Apart Hotel Group. თქვენი მოთხოვნა მიღებულია და ვამოწმებთ ხელმისაწვდომობას თქვენს თარიღებზე.','apartments'=>'აპარტამენტები','estimate'=>'სავარაუდო ღირებულება','prepay'=>'წინასწარი გადახდა','next'=>'შემდეგი ნაბიჯები: ჩვენი გუნდი დაადასტურებს ჯავშანს და გამოგიგზავნით წინასწარი გადახდის დაცულ ბმულს. გადახდის მიღებისთანავე მიიღებთ ჯავშნის დადასტურებას (ვაუჩერს) PDF ფორმატში.','note'=>'ეს წერილი არ არის ჯავშნის დადასტურება.','on_request'=>'მოთხოვნით'],
];return $T[$L]??$T['en'];}
function luxv_request_email($id){
 $d=get_post_meta($id,'_lux_request',true);if(!is_array($d))return null;$L=luxv_locale($id);$r=luxv_request_texts($L);$t=fn($k)=>luxv_t($L,$k);$e='esc_html';
 $in=lux_ymd($d['checkin']);$out=lux_ymd($d['checkout']);$n=$in&&$out?$out->diff($in)->days:0;$b=$d['breakdown']??null;
 $ka=$L==='ka'?"'Noto Sans Georgian',":'';$font="font-family:".$ka."Calibri,Carlito,'Segoe UI',Helvetica,Arial,sans-serif";$serif="font-family:".($L==='ka'?"'Noto Serif Georgian',":'')."Georgia,'Times New Roman',serif";
 $row=fn($k,$v)=>'<tr><td style="padding:8px 10px;border:1px solid #DCDCD6;color:#666;font-size:13px;width:42%">'.$e($k).'</td><td style="padding:8px 10px;border:1px solid #DCDCD6;font-size:15px">'.$e($v).'</td></tr>';
 $logo=esc_url(plugins_url('assets/voucher-logo.jpg',__FILE__)); // JPG: WebP is not shown by Outlook and some mail apps
 $aps=implode(', ',array_map(fn($a)=>$a['title'].' · '.$t('city_'.(($a['city']??'')==='gudauri'?'gudauri':'batumi')),$d['apartments']));
 $h='<div style="background:#f8f7f3;padding:24px 12px"><div style="max-width:640px;margin:0 auto;background:#fff;border:1px solid #e4e4dc;padding:28px 30px;color:#171717;'.$font.';line-height:1.4">';
 $h.=($logo?'<img src="'.$logo.'" alt="Luxury Apart Hotel Group" width="64" style="width:64px;height:auto;display:block;margin-bottom:10px">':'').'<div style="font-size:12px;letter-spacing:.04em">LUXURY APART HOTEL GROUP</div>';
 $h.='<h1 style="'.$serif.';font-weight:normal;font-size:28px;margin:14px 0 6px">'.$e($r['title']).'</h1><p style="color:#92754B;font-weight:bold;font-size:13px;margin:0 0 14px">'.$e($r['status']).' · '.$e($t('booking_no').' '.$d['reference']).'</p>';
 $h.='<p style="font-size:15px;margin:0 0 16px">'.$e(sprintf($r['intro'],$d['name'])).'</p><table style="width:100%;border-collapse:collapse">';
 $h.=$row($t('checkin'),$in?luxv_date($in,$L):'').$row($t('checkout'),$out?luxv_date($out,$L):'').$row($t('nights'),(string)$n).$row($r['apartments'],$aps);
 if($b){$h.=$row($r['estimate'],$b['total']===null?$r['on_request']:luxv_money(luxv_tetri($b['total']),$L));if($b['payment']['due_now']!==null)$h.=$row($r['prepay'].' ('.$b['payment']['percent'].'%)',luxv_money(luxv_tetri($b['payment']['due_now']),$L));}
 $next=function_exists('luxf_online_for')&&luxf_online_for($id)?luxf_texts($L)['next_online']:$r['next'];
 $h.='</table><p style="font-size:15px;margin:18px 0 8px">'.$e($next).'</p><p style="font-size:13px;color:#666;margin:0 0 18px"><strong>'.$e($r['note']).'</strong></p>';
 $h.='<p style="font-size:13px;color:#666;margin:0">WhatsApp +995 557 528 285 · reservations@luxuryaparthotel.ge · +995 555 907 333</p></div></div>';
 return [sprintf($r['subject'],$d['reference']),$h];
}

// ---------- Admin ----------
add_action('add_meta_boxes',function(){add_meta_box('lux-voucher-v14','Confirmation voucher (PDF) and payments','luxv_box','lux_booking','normal','default');});
function luxv_box($post){
 $id=$post->ID;$d=get_post_meta($id,'_lux_request',true);if(!is_array($d)||($d['kind']??'')==='experience'){echo '<p>Not an apartment booking.</p>';return;}
 wp_nonce_field('luxv_save','luxv_nonce');$x=(array)get_post_meta($id,'_lux_voucher_fields',true);$ov=(array)get_post_meta($id,'_lux_apartments_voucher',true);$v=fn($k)=>esc_attr($x[$k]??'');
 $bal=luxv_balance($id);$missing=luxv_missing($id);$versions=luxv_versions($id);$guests=array_sum(array_column($d['apartments'],'guests'));
 echo '<style>.luxv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px 16px;margin:8px 0 14px}.luxv-grid label{display:block;font-weight:600}.luxv-grid input,.luxv-grid select,.luxv-grid textarea{width:100%}.luxv h4{margin:18px 0 4px}.luxv table.widefat input,.luxv table.widefat select{width:100%}</style><div class="luxv">';
 echo $missing?'<div class="notice notice-warning inline"><p><strong>The final voucher is not issued yet.</strong> Still needed: '.esc_html(implode('; ',$missing)).'.</p></div>':'<div class="notice notice-success inline"><p>'.($versions?'Current version: '.count($versions).'. A new version is issued and emailed automatically when payments or the agreed total change.':'Ready: the voucher is issued and emailed to the guest and the company when you click “Update”.').'</p></div>';
 if($err=get_post_meta($id,'_lux_voucher_error',true))echo '<div class="notice notice-error inline"><p>PDF error: '.esc_html($err).'</p></div>';
 echo '<p>Invoice no.: <strong>'.esc_html(luxv_invoice($id)).'</strong> · Rate: <strong>'.(luxv_rate($d)==='last_minute'?'Last Minute (100%)':'Standard Booking').'</strong> · Total: <strong>'.esc_html($bal['total']?luxv_money($bal['total'],'en'):'on request').'</strong> · Paid: <strong>'.esc_html(luxv_money($bal['paid'],'en')).($bal['total']?' ('.luxv_pct((float)$bal['paid_pct'],'en').'%)':'').'</strong> · Balance: <strong>'.esc_html($bal['balance']===null?'—':luxv_money($bal['balance'],'en')).'</strong>'.($bal['over']?' · Overpaid: '.esc_html(luxv_money($bal['over'],'en')):'').'</p>';
 echo '<h4>Payments received (GEL)</h4><p class="description">Record only payments confirmed by the bank or received by staff. The paid amount, percentages and payment status on the voucher come from this list.</p><table class="widefat"><thead><tr><th>Date</th><th>Amount, GEL</th><th>Method</th><th>Transaction / receipt no.</th><th>Recorded by</th></tr></thead><tbody>';
 $rows=luxv_payments($id);$rows[]=[];$rows[]=[];
 foreach($rows as $i=>$p){$m=$p['method']??'card';$u=isset($p['by'])?get_userdata($p['by']):null;echo '<tr><td><input type="date" name="luxv_pay['.$i.'][date]" value="'.esc_attr($p['date']??'').'"></td><td><input type="text" inputmode="decimal" name="luxv_pay['.$i.'][amount]" value="'.esc_attr(isset($p['amount'])?number_format($p['amount']/100,2,'.',''):'').'" placeholder="0.00"></td><td><select name="luxv_pay['.$i.'][method]">';foreach(['card'=>'Bank card (online)','transfer'=>'Bank transfer','cash'=>'Cash','terminal'=>'Card terminal'] as $k=>$l)echo '<option value="'.$k.'" '.selected($m,$k,false).'>'.$l.'</option>';echo '</select></td><td><input type="text" name="luxv_pay['.$i.'][txn]" value="'.esc_attr($p['txn']??'').'"></td><td>'.(($p['source']??'')==='flitt'?esc_html('Flitt online · '.($p['card']??'').' · '.($p['at']??'')):(isset($p['by'])?esc_html(($u?$u->display_name:'').' · '.($p['at']??'')):'')).'</td></tr>';}
 echo '</tbody></table><p class="description">To remove a payment, clear its amount.</p>';
 $att=luxf_attempts($id);if($att){echo '<p><strong>Online payment attempts (Flitt)</strong></p><ul style="margin:0">';foreach(array_reverse($att,true) as $o=>$a)echo '<li>'.esc_html($o.' · '.luxv_money((int)($a['amount']??0),'en').' · '.($a['status']??'').' · '.($a['created']??'').(!empty($a['message'])?' · '.$a['message']:'').(($a['mode']??'')==='test'?' · TEST':'')).'</li>';echo '</ul>';}
 echo '<h4>Voucher details</h4><div class="luxv-grid"><p><label>Voucher language</label><select name="luxv[locale]">';foreach(LUXV_LOCALES as $k=>$l)echo '<option value="'.$k.'" '.selected(luxv_locale($id),$k,false).'>'.esc_html($l).'</option>';echo '</select></p>';
 $agreed=get_post_meta($id,'_lux_agreed_total',true);
 echo '<p><label>Agreed total, GEL</label><input type="text" name="luxv[agreed_total]" value="'.esc_attr($agreed!==''&&$agreed!==false?number_format((int)$agreed/100,2,'.',''):'').'" placeholder="'.esc_attr(isset($d['breakdown']['total'])&&$d['breakdown']['total']!==null?number_format($d['breakdown']['total'],2,'.',''):'price on request').'"></p>';
 echo '<p><label>Adults</label><input type="number" min="1" name="luxv[adults]" value="'.$v('adults').'" placeholder="'.(int)$guests.'"></p><p><label>Children</label><input type="number" min="0" name="luxv[children]" value="'.$v('children').'" placeholder="0"></p>';
 echo '<p><label>Estimated arrival date</label><input type="date" name="luxv[arrival_date]" value="'.$v('arrival_date').'"></p><p><label>Estimated arrival time (Georgia)</label><input type="time" name="luxv[arrival_time]" value="'.$v('arrival_time').'"></p></div>';
 foreach($d['apartments'] as $i=>$a){$def=luxv_apartment_defaults($a);$o=(array)($ov[$i]??[]);echo '<h4>'.esc_html($a['title']).'</h4><div class="luxv-grid">';
  foreach(['property'=>'Property / complex','address'=>'Accommodation address','block'=>'Block / building','number'=>'Apartment number'] as $k=>$l){$ph=$k==='address'?luxv_t(luxv_locale($id),'addr_'.(($a['city']??'')==='gudauri'?'gudauri':'batumi')):$def[$k];echo '<p><label>'.$l.'</label><input type="text" name="luxv_ap['.$i.']['.$k.']" value="'.esc_attr($o[$k]??'').'" placeholder="'.esc_attr($ph).'"></p>';}
  echo '</div>';}
 echo '<p class="description">Empty fields use the value in grey.</p><h4>Check-in, services and arrangements (shown on the voucher only when filled)</h4><div class="luxv-grid">';
 foreach(['keys'=>'Key collection (desk / address / meeting point)','instructions'=>'Check-in instructions','breakfast_format'=>'Breakfast format / menu','breakfast_venue'=>'Breakfast venue and address','breakfast_time'=>'Breakfast serving time','pickup'=>'Transfer pick-up date and time','meeting'=>'Transfer meeting point','airport'=>'Arrival airport / code','terminal'=>'Terminal','flight_date'=>'Flight arrival date','flight_time'=>'Flight arrival time (airport local)','airline'=>'Airline','flight_no'=>'Flight number','pax'=>'Passengers and luggage','driver'=>'Driver or coordinator contact','extras_terms'=>'Breakfast and transfer cancellation terms','arrangements'=>'Confirmed special arrangements'] as $k=>$l){
  $type=$k==='flight_date'?'date':($k==='flight_time'?'time':'text');
  echo in_array($k,['instructions','arrangements'],true)?'<p><label>'.$l.'</label><textarea rows="3" name="luxv['.$k.']">'.esc_textarea($x[$k]??'').'</textarea></p>':'<p><label>'.$l.'</label><input type="'.$type.'" name="luxv['.$k.']" value="'.$v($k).'"></p>';}
 echo '<p><label>Ticket / itinerary</label><select name="luxv[ticket]"><option value="">—</option><option value="received" '.selected($x['ticket']??'','received',false).'>Received</option><option value="pending" '.selected($x['ticket']??'','pending',false).'>Pending</option></select></p></div>';
 echo '<h4>Versions</h4>';
 if(!$versions)echo '<p>No final voucher yet.</p>';else{echo '<table class="widefat"><thead><tr><th>Version</th><th>Issued</th><th>Language</th><th>Paid / total</th><th>SHA-256</th><th>PDF</th></tr></thead><tbody>';
  foreach(array_reverse($versions) as $ver)echo '<tr><td>'.(int)$ver['version'].' · '.esc_html($ver['reason']).'</td><td>'.esc_html($ver['issued']).'</td><td>'.esc_html($ver['locale']).'</td><td>'.esc_html(luxv_money($ver['paid'],'en').' / '.luxv_money((int)$ver['total'],'en')).'</td><td><code style="font-size:10px">'.esc_html(substr($ver['sha256'],0,16)).'…</code></td><td><a href="'.esc_url(wp_nonce_url(add_query_arg(['luxv_pdf'=>$id,'v'=>$ver['version']],admin_url('admin.php')),'luxv_pdf')).'" target="_blank">Open</a></td></tr>';
  echo '</tbody></table>';
  $log=get_post_meta($id,'_lux_voucher_log',true);if(is_array($log)&&$log){echo '<p><strong>Email log</strong></p><ul style="margin:0">';foreach(array_slice(array_reverse($log),0,12) as $l)echo '<li>v'.(int)$l['version'].' → '.esc_html($l['who'].' '.$l['to'].' · '.$l['time'].' · '.($l['result']==='failed'?'NOT delivered — check the site email (SMTP) settings':'sent')).'</li>';echo '</ul>';}
  echo '<p><label><input type="checkbox" name="luxv_resend" value="1"> Resend the current version (same PDF) to the guest and the company</label><br><label><input type="checkbox" name="luxv_new" value="1"> Issue a new version now (after changing the details above)</label></p>';}
 echo '</div>';
}
add_action('save_post_lux_booking',function($id){
 if(!current_user_can('manage_options')||!isset($_POST['luxv_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['luxv_nonce'])),'luxv_save'))return;
 $in=(array)wp_unslash($_POST['luxv']??[]);$x=[];
 foreach(['adults','children','arrival_date','arrival_time','keys','breakfast_format','breakfast_venue','breakfast_time','pickup','meeting','airport','terminal','flight_date','flight_time','airline','flight_no','pax','driver','extras_terms','ticket'] as $k)$x[$k]=sanitize_text_field($in[$k]??'');
 foreach(['instructions','arrangements'] as $k)$x[$k]=sanitize_textarea_field($in[$k]??'');
 $before=wp_json_encode(luxv_balance($id));
 update_post_meta($id,'_lux_voucher_fields',$x);if(isset(LUXV_LOCALES[$in['locale']??'']))update_post_meta($id,'_lux_voucher_locale',$in['locale']);
 $at=trim((string)($in['agreed_total']??''));if($at==='')delete_post_meta($id,'_lux_agreed_total');else update_post_meta($id,'_lux_agreed_total',luxv_tetri($at));
 $ap=[];foreach((array)wp_unslash($_POST['luxv_ap']??[]) as $i=>$row)foreach(['property','address','block','number'] as $k)$ap[(int)$i][$k]=sanitize_text_field($row[$k]??'');update_post_meta($id,'_lux_apartments_voucher',$ap);
 $old=luxv_payments($id);$pays=[];
 foreach((array)wp_unslash($_POST['luxv_pay']??[]) as $i=>$p){$amt=luxv_tetri($p['amount']??'');if($amt<=0)continue;$method=in_array($p['method']??'',['card','transfer','cash','terminal'],true)?$p['method']:'card';
  $row=['date'=>preg_match('/^\d{4}-\d{2}-\d{2}$/',$p['date']??'')?$p['date']:wp_date('Y-m-d'),'amount'=>$amt,'method'=>$method,'txn'=>sanitize_text_field($p['txn']??'')];
  $prev=$old[(int)$i]??null;$same=$prev&&$prev['amount']===$row['amount']&&$prev['date']===$row['date']&&$prev['method']===$row['method']&&$prev['txn']===$row['txn'];
  $row['by']=$same?($prev['by']??get_current_user_id()):get_current_user_id();$row['at']=$same?($prev['at']??current_time('mysql')):current_time('mysql');if($same)$row+=$prev; // keeps online-payment details (Flitt order, card)
  $pays[]=$row;}
 update_post_meta($id,'_lux_payments',$pays);
 $versions=luxv_versions($id);$changed=$before!==wp_json_encode(luxv_balance($id));
 if(!luxv_missing($id)){
  if(!$versions)luxv_issue($id,'issued');
  elseif($changed)luxv_issue($id,'payment or total changed');
  elseif(!empty($_POST['luxv_new']))luxv_issue($id,'details updated');
  elseif(!empty($_POST['luxv_resend']))luxv_deliver($id,count($versions));
 }elseif(!empty($_POST['luxv_resend'])&&$versions)luxv_deliver($id,count($versions));
},30);

// Stored PDF for staff (wp-admin link); the guest gets it through the private voucher link (?lux_voucher=…&vk=…&pdf=1, vouchers.php).
add_action('admin_init',function(){
 if(empty($_GET['luxv_pdf'])||!current_user_can('manage_options'))return;check_admin_referer('luxv_pdf');$id=absint($_GET['luxv_pdf']);$n=absint($_GET['v']??0);
 foreach(luxv_versions($id) as $ver)if((int)$ver['version']===$n&&($f=luxv_file($ver)))luxv_send_file($f,$ver['snapshot']['reference'].'-v'.$n.'.pdf');
 wp_die('Voucher file not found.');
});
function luxv_send_file($f,$name){nocache_headers();header('Content-Type: application/pdf');header('Content-Disposition: inline; filename="'.sanitize_file_name($name).'"');header('Content-Length: '.filesize($f));header('X-Robots-Tag: noindex');readfile($f);exit;}
