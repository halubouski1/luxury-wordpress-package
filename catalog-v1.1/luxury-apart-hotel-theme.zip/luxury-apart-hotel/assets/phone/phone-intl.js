/* Country-code phone selector (intl-tel-input) for every tel field:
   booking form, owner enquiry, property quiz, experience request.
   Default country Georgia; on submit the field is rewritten to the full
   international number so the country code is always sent. */
(function(){
  var PREF=['ge','ru','tr','am','az','ua','il','de','gb','us','ae','kz','by'];
  function fullNumber(iti,input){
    try{var n=iti.getNumber();if(n)return n;}catch(e){}
    try{var d=iti.getSelectedCountryData(),nat=(input.value||'').replace(/[^\d]/g,'');if(d&&d.dialCode&&nat)return '+'+d.dialCode+nat;}catch(e){}
    return input.value;
  }
  /* Browser autofill and paste often put the whole number ("+995557528285") into the field
     next to the dial code that is already shown, which gave "+995 +995557528285".
     A number with + or 00 sets its own country; a number that repeats the selected dial code loses it. */
  function normalize(iti,input){
    var v=(input.value||'').trim();if(!v)return;
    var digits=v.replace(/[^\d]/g,'');
    if(/^(\+|00)/.test(v)){if(/^00/.test(v))digits=digits.slice(2);if(digits.length>=8){try{iti.setNumber('+'+digits);}catch(e){}}return;}
    try{var d=iti.getSelectedCountryData();if(d&&d.dialCode&&digits.indexOf(d.dialCode)===0&&digits.length>=d.dialCode.length+8)iti.setNumber('+'+digits);}catch(e){}
  }
  function valid(iti){
    try{return !(window.intlTelInput&&window.intlTelInput.utils)||iti.isValidNumber()!==false;}catch(e){return true;}
  }
  function enhance(input){
    if(input.dataset.itiDone||!window.intlTelInput)return;
    input.dataset.itiDone='1';
    /* The dial code is shown beside the flag, so a "+995 ..." hint would repeat it. */
    if(/^\s*\+/.test(input.getAttribute('placeholder')||''))input.removeAttribute('placeholder');
    /* Inside a modal <dialog> everything outside it is inert, so the country list
       must open within the dialog or it can be seen but not tapped. */
    var dialog=input.closest('dialog');
    var iti=window.intlTelInput(input,{
      initialCountry:'ge',
      separateDialCode:true,
      countryOrder:PREF,
      dropdownContainer:dialog||null,
      loadUtils:function(){return import('https://cdn.jsdelivr.net/npm/intl-tel-input@23/build/js/utils.js');}
    });
    input.addEventListener('input',function(e){input.setCustomValidity('');if(!e.inputType||e.inputType==='insertReplacementText'||e.inputType==='insertFromPaste')normalize(iti,input);});
    input.addEventListener('change',function(){normalize(iti,input);});
    input.addEventListener('blur',function(){normalize(iti,input);});
    input.addEventListener('countrychange',function(){input.setCustomValidity('');});
    var form=input.closest('form');
    if(form&&!form.dataset.itiBound){form.dataset.itiBound='1';
      form.addEventListener('submit',function(e){
        normalize(iti,input);
        /* A wrong country or a missing digit means we cannot call the guest back: stop and say so. */
        if(input.value&&!valid(iti)){e.preventDefault();e.stopImmediatePropagation();input.setCustomValidity('Please check the phone number and the country code.');input.reportValidity();return;}
        input.value=fullNumber(iti,input);
      },true);
    }
  }
  /* Full-screen country list on phones: keep it above the sticky site header and
     the WP admin bar, so the Search row is not cut off at the top. */
  function style(){
    if(document.getElementById('lux-iti-style'))return;
    var s=document.createElement('style');s.id='lux-iti-style';
    s.textContent='.iti--fullscreen-popup.iti--container{z-index:2147483000;padding:calc(env(safe-area-inset-top,0px) + 24px) 16px calc(env(safe-area-inset-bottom,0px) + 24px)}';
    document.head.appendChild(s);
  }
  function scan(){if(!window.intlTelInput)return;document.querySelectorAll('input[type=tel]').forEach(enhance);}
  function ready(){style();scan();try{new MutationObserver(scan).observe(document.documentElement,{subtree:true,childList:true});}catch(e){}}
  if(document.readyState!=='loading')ready();else document.addEventListener('DOMContentLoaded',ready);
})();
