<?php
if(!defined('ABSPATH'))exit;
// Free website translation via Google's Website Translator widget (the same engine GTranslate's free tier uses).
// A custom language selector drives the hidden Google widget; English is the site's original language.
// Prices and payment stay in GEL — only the interface text is translated.

function lux_languages(){
 // code => [native label, Google Translate code, rtl]
 return [
  'en'=>['English','en',false],
  'ka'=>['ქართული','ka',false],
  'ru'=>['Русский','ru',false],
  'he'=>['עברית','iw',true],
  'ar'=>['العربية','ar',true],
  'tr'=>['Türkçe','tr',false],
  'de'=>['Deutsch','de',false],
  'fr'=>['Français','fr',false],
  'it'=>['Italiano','it',false],
 ];
}

add_action('wp_enqueue_scripts',function(){
 wp_enqueue_style('lux-translate',plugins_url('assets/translate.css',__FILE__),[],filemtime(__DIR__.'/assets/translate.css'));
 wp_enqueue_script('lux-translate',plugins_url('assets/translate.js',__FILE__),[],filemtime(__DIR__.'/assets/translate.js'),['in_footer'=>true]);
 $langs=[];foreach(lux_languages() as $code=>$l)$langs[$code]=['label'=>$l[0],'google'=>$l[1],'rtl'=>$l[2]];
 wp_add_inline_script('lux-translate','window.LUX_LANGS='.wp_json_encode(['languages'=>$langs,'default'=>'en']).';','before');
},60);

add_action('wp_footer',function(){
 $langs=lux_languages();$included=implode(',',array_map(fn($l)=>$l[1],$langs));
 ?>
 <div id="lux-lang" class="lux-lang" hidden>
  <button type="button" class="lux-lang-toggle" aria-haspopup="listbox" aria-expanded="false">
   <span class="lux-lang-globe" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></span>
   <span class="lux-lang-current" data-lux-current>English</span>
   <span class="lux-lang-caret" aria-hidden="true">▾</span>
  </button>
  <ul class="lux-lang-menu" role="listbox" aria-label="<?php echo esc_attr('Choose a language');?>" hidden>
   <?php foreach($langs as $code=>$l){?><li role="option" data-lang="<?php echo esc_attr($code);?>"<?php echo $l[2]?' dir="rtl"':'';?>><?php echo esc_html($l[0]);?></li><?php }?>
  </ul>
 </div>
 <div id="google_translate_element" aria-hidden="true"></div>
 <script>
  window.luxGoogleTranslateInit=function(){new google.translate.TranslateElement({pageLanguage:'en',includedLanguages:<?php echo wp_json_encode($included);?>,autoDisplay:false},'google_translate_element');};
 </script>
 <script src="https://translate.google.com/translate_a/element.js?cb=luxGoogleTranslateInit" defer></script>
 <?php
});
