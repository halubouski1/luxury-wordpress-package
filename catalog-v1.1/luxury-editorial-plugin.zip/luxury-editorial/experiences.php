<?php
if(!defined('ABSPATH'))exit;
// Experiences: three directions. Georgia Tours and Zanzibar are card collections of lux_experience posts
// (collection = "Experience collections" term); Concierge Service is a service page edited in Luxury Setup → Experiences page.

function lux_exp_collections(){return ['georgia-tours'=>'Georgia Tours','zanzibar'=>'Zanzibar Travel Experiences','concierge-service'=>'Concierge Service'];}
function lux_exp_list_fields(){return ['included'=>'What’s included','ideal_for'=>'Ideal for','addons'=>'Optional add-ons','notes'=>'Planning notes'];}

add_action('init',function(){
 register_taxonomy('lux_exp_type',['lux_experience'],['labels'=>['name'=>'Package types','singular_name'=>'Package type','add_new_item'=>'Add package type','search_items'=>'Search package types','popular_items'=>null],'public'=>false,'show_ui'=>true,'show_in_rest'=>true,'hierarchical'=>false,'show_admin_column'=>true,'rewrite'=>false]);
 add_rewrite_rule('^experiences/('.implode('|',array_map('preg_quote',array_keys(lux_exp_collections()))).')/?$','index.php?lux_exp_collection=$matches[1]','top');
 add_rewrite_rule('^guide/(batumi|gudauri|more-destinations)/?$','index.php?lux_guide_dest=$matches[1]','top');
 if(get_option('lux_exp_rewrite')!=='7'){flush_rewrite_rules(false);update_option('lux_exp_rewrite','7');}
},20);
add_filter('query_vars',fn($v)=>array_merge($v,['lux_exp_collection','lux_guide_dest']));
add_filter('redirect_canonical',fn($url)=>(get_query_var('lux_exp_collection')||get_query_var('lux_guide_dest'))?false:$url);
// Collection addresses are reserved so a tour can never hide a collection page.
add_filter('wp_unique_post_slug',function($slug,$id,$status,$type){return $type==='lux_experience'&&isset(lux_exp_collections()[$slug])?$slug.'-journey':$slug;},10,4);

function lux_exp_item($post){
 $id=is_object($post)?$post->ID:(int)$post;$get=fn($k)=>get_post_meta($id,'_lux_exp_'.$k,true);
 $terms=wp_get_object_terms($id,'lux_exp_group');$collection='';foreach(is_wp_error($terms)?[]:$terms as $t)if(isset(lux_exp_collections()[$t->slug])){$collection=$t->slug;break;}
 $types=wp_get_object_terms($id,'lux_exp_type');$types=is_wp_error($types)?[]:array_map(fn($t)=>['slug'=>$t->slug,'name'=>$t->name],$types);
 $lines=fn($k)=>array_values(array_filter(array_map('trim',(array)$get($k)),'strlen'));
 $item=['id'=>$id,'slug'=>get_post_field('post_name',$id),'title'=>html_entity_decode(get_the_title($id),ENT_QUOTES|ENT_HTML5,'UTF-8'),'url'=>get_permalink($id),'collection'=>$collection,'types'=>$types,'summary'=>has_excerpt($id)?get_the_excerpt($id):'','subtitle'=>(string)$get('subtitle'),'duration'=>(string)$get('duration'),'locations'=>(string)$get('locations'),'format'=>(string)$get('format'),'stay_title'=>(string)$get('stay_title'),'stay_text'=>(string)$get('stay_text'),'stay_image'=>(string)$get('stay_image'),'stay_gallery'=>array_values(array_filter((array)$get('stay_gallery'),'strlen')),'price_rows'=>(function($r){$o=[];foreach((array)$r as $row){if(is_array($row)&&isset($row['label'])&&is_numeric($row['amount']??null)&&$row['amount']>0)$o[]=['label'=>(string)$row['label'],'amount'=>(int)$row['amount']];}return $o;})($get('price_rows')),'price_currency'=>$get('price_currency')==='USD'?'USD':'GEL','price_unit'=>(string)$get('price_unit'),'price_from'=>0,'cta'=>(string)$get('cta')?:'Request this experience','image_id'=>(int)get_post_thumbnail_id($id)];
 foreach(array_keys(lux_exp_list_fields()) as $k)$item[$k]=$lines($k);
 $amts=array_column($item['price_rows'],'amount');$item['price_from']=$amts?min($amts):0;
 return $item;
}
function lux_exp_items($collection){
 $posts=get_posts(['post_type'=>'lux_experience','post_status'=>'publish','numberposts'=>-1,'orderby'=>['menu_order'=>'ASC','ID'=>'ASC'],'tax_query'=>[['taxonomy'=>'lux_exp_group','field'=>'slug','terms'=>$collection]]]);
 return array_map('lux_exp_item',$posts);
}

// Editor: one template for every tour and package.
add_action('add_meta_boxes',function(){add_meta_box('lux-exp-details','Experience details','lux_exp_box','lux_experience','normal','high');});
function lux_exp_box($post){
 wp_nonce_field('lux_exp_details','lux_exp_nonce');$v=fn($k)=>get_post_meta($post->ID,'_lux_exp_'.$k,true);
 $text=function($k,$label,$hint='',$ph='')use($v){echo '<p><label><strong>'.esc_html($label).'</strong><input class="widefat" name="lux_exp_'.esc_attr($k).'" value="'.esc_attr($v($k)).'" placeholder="'.esc_attr($ph).'"></label>'.($hint?'<span class="description">'.esc_html($hint).'</span>':'').'</p>';};
 $area=function($k,$label,$hint,$rows=5)use($v){$val=$v($k);echo '<p><label><strong>'.esc_html($label).'</strong><textarea class="widefat" rows="'.(int)$rows.'" name="lux_exp_'.esc_attr($k).'">'.esc_textarea(is_array($val)?implode("\n",$val):(string)$val).'</textarea></label><span class="description">'.esc_html($hint).'</span></p>';};
 echo '<p>Title, <strong>Featured image</strong> (hero and card photo) and <strong>Excerpt</strong> (short card text) are set in the editor sidebar. The main text in the editor becomes the <strong>Overview</strong>. Choose the collection under <strong>Experience collections</strong> — the card then appears on that collection page automatically. Empty sections are hidden on the page.</p>';
 echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:0 20px">';
 $text('subtitle','Subtitle','One short premium line under the title.','A romantic all-inclusive escape designed for couples.');
 $text('duration','Duration','Shown on the card and in quick facts.','7 nights');
 $text('locations','Locations','','Kendwa');
 $text('format','Format','Meals, accommodation or tour style.','All inclusive');
 $text('cta','Button text','Default: Request availability.','Request availability');
  echo '</div><h3 style="margin:18px 0 6px">Price &#8212; day tours &amp; experiences</h3><p class="description">One price row per line: <code>Label | amount</code> (e.g. <code>1 guest | 730</code>, <code>Per car (up to 6) | 610</code>, <code>30 min &#183; 1 guest | 310</code>). Leave empty for items priced on request. The lowest amount shows as &#8220;From &#8230;&#8221;.</p><div style="display:grid;grid-template-columns:1fr 160px 220px;gap:0 16px;max-width:780px;align-items:start">';
 $rows=(array)$v('price_rows');$txt=implode("\n",array_map(fn($r)=>is_array($r)?(($r['label']??'').' | '.($r['amount']??'')):'',$rows));
 echo '<p><label>Price rows<textarea class="widefat" rows="5" name="lux_exp_price_rows">'.esc_textarea($txt).'</textarea></label></p>';
 $cur=$v('price_currency')?:'GEL';echo '<p><label>Currency<select class="widefat" name="lux_exp_price_currency"><option value="GEL" '.selected($cur,'GEL',false).'>GEL</option><option value="USD" '.selected($cur,'USD',false).'>USD</option></select></label></p>';
 echo '<p><label>Unit caption<input class="widefat" name="lux_exp_price_unit" value="'.esc_attr($v('price_unit')).'" placeholder="per person / per group / per snowmobile"></label></p>';
 echo '</div>';
}
add_action('save_post_lux_experience',function($id){
 if(!isset($_POST['lux_exp_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['lux_exp_nonce'])),'lux_exp_details')||!current_user_can('edit_post',$id)||wp_is_post_autosave($id)||wp_is_post_revision($id))return;
 foreach(['subtitle','duration','locations','format','cta','stay_title'] as $k)update_post_meta($id,'_lux_exp_'.$k,sanitize_text_field(wp_unslash($_POST['lux_exp_'.$k]??'')));
 update_post_meta($id,'_lux_exp_stay_image',esc_url_raw(wp_unslash($_POST['lux_exp_stay_image']??'')));
 update_post_meta($id,'_lux_exp_stay_text',sanitize_textarea_field(wp_unslash($_POST['lux_exp_stay_text']??'')));
 update_post_meta($id,'_lux_exp_stay_gallery',array_values(array_unique(array_filter(array_map('esc_url_raw',preg_split('/\R/',wp_unslash($_POST['lux_exp_stay_gallery']??''))),'strlen'))));
 $rows=[];foreach(preg_split('/\R/',wp_unslash($_POST['lux_exp_price_rows']??'')) as $ln){$ln=trim($ln);if($ln==='')continue;$parts=array_map('trim',explode('|',$ln,2));if(count($parts)<2||!is_numeric($parts[1]))continue;$rows[]=['label'=>sanitize_text_field($parts[0]),'amount'=>(int)round((float)$parts[1])];}update_post_meta($id,'_lux_exp_price_rows',$rows);update_post_meta($id,'_lux_exp_price_currency',($_POST['lux_exp_price_currency']??'GEL')==='USD'?'USD':'GEL');update_post_meta($id,'_lux_exp_price_unit',sanitize_text_field(wp_unslash($_POST['lux_exp_price_unit']??'')));
 foreach(array_keys(lux_exp_list_fields()) as $k)update_post_meta($id,'_lux_exp_'.$k,array_values(array_filter(array_map('sanitize_text_field',preg_split('/\R/',wp_unslash($_POST['lux_exp_'.$k]??''))),'strlen')));
});
add_filter('manage_lux_experience_posts_columns',fn($c)=>array_merge($c,['lux_exp_facts'=>'Duration · Locations']));
add_action('manage_lux_experience_posts_custom_column',function($col,$id){if($col==='lux_exp_facts')echo esc_html(implode(' · ',array_filter([get_post_meta($id,'_lux_exp_duration',true),get_post_meta($id,'_lux_exp_locations',true)])));},10,2);

// Section-level content: hero, direction cards, collection headers, Concierge page, WhatsApp.
function lux_exp_defaults(){
 return [
  'hero_eyebrow'=>'CURATED TRAVEL EXPERIENCES','hero_title'=>'Beyond your stay.','hero_title_em'=>'A world of experiences.','hero_text'=>'Unique places, meaningful moments. Curated with care.','hero_image'=>'',
  'georgia-tours_card'=>'Mountains, culture and unforgettable journeys across Georgia.','georgia-tours_cta'=>'Explore Georgia Tours','georgia-tours_image'=>'',
  'georgia-tours_title'=>'Georgia Tours','georgia-tours_text'=>'Curated tours and routes across Georgia — from the Black Sea to the high Caucasus.','georgia-tours_hero'=>'',
  'zanzibar_card'=>'Founder-Curated Signature Journeys, created with our official local partner, Mars Tours & Safari Zanzibar.','zanzibar_cta'=>'Explore Zanzibar Packages','zanzibar_image'=>'',
  'zanzibar_title'=>'Zanzibar Travel Experiences','zanzibar_text'=>'Founder-Curated Signature Journeys, created with our official local partner, Mars Tours & Safari Zanzibar.','zanzibar_hero'=>'',
  'concierge-service_card'=>'Thoughtful assistance throughout your stay.','concierge-service_cta'=>'Our Concierge','concierge-service_image'=>'',
  'concierge-service_title'=>'Concierge Service','concierge-service_text'=>'Personal assistance throughout your stay — the details handled, so you can simply enjoy it.','concierge-service_hero'=>'',
  'service_1_title'=>'Dining','service_1_text'=>'Restaurant reservations, romantic dining and special dining requests.',
  'service_2_title'=>'Wellness','service_2_text'=>'Massage, spa and wellness bookings, and relaxing leisure arrangements.',
  'service_3_title'=>'Special requests','service_3_text'=>'Honeymoon setup, birthdays and anniversaries, flowers and gifts, personal surprises.',
  'service_4_title'=>'Guest assistance','service_4_text'=>'Support during your stay, household and organisational requests, personal assistance.',
  'concierge_cta'=>'Request concierge assistance','whatsapp'=>'','email'=>'concierge@luxuryaparthotel.ge','notify'=>'concierge@luxuryaparthotel.ge',
 ];
}
function lux_exp_settings(){$saved=get_option('lux_experiences',[]);return array_merge(lux_exp_defaults(),is_array($saved)?array_filter($saved,fn($v)=>$v!==''):[]);}
function lux_exp_default_image($key){$map=['hero_image'=>'zanzibar-8','georgia-tours_image'=>'gudauri-mountains','zanzibar_image'=>'zanzibar-4','concierge-service_image'=>'concierge-preview','georgia-tours_hero'=>'experiences-overlook','zanzibar_hero'=>'zanzibar-1','concierge-service_hero'=>'concierge-preview'];return isset($map[$key])&&function_exists('lux_theme_asset')?lux_theme_asset('images/'.$map[$key].'.webp'):'';}
function lux_exp_image($s,$key){return $s[$key]?:lux_exp_default_image($key);}
function lux_whatsapp_url($text=''){$n=preg_replace('/\D+/','',lux_exp_settings()['whatsapp']);return $n?'https://wa.me/'.$n.($text!==''?'?text='.rawurlencode($text):''):'';}

add_action('admin_menu',function(){add_submenu_page('luxury-setup','Experiences page','Experiences page','manage_options','luxury-experiences','lux_exp_settings_page');});
function lux_exp_settings_page(){
 if(!current_user_can('manage_options'))return;$s=lux_exp_settings();$saved=get_option('lux_experiences',[]);
 $field=function($k,$label,$type='text')use($saved){$val=$saved[$k]??'';$ph=lux_exp_defaults()[$k]??'';$id='lux-exp-'.$k;
  if($type==='image'){echo '<p><label for="'.esc_attr($id).'"><strong>'.esc_html($label).'</strong></label><br><input class="large-text" id="'.esc_attr($id).'" name="lux_experiences['.esc_attr($k).']" value="'.esc_attr($val).'" placeholder="Default: '.esc_attr(basename(lux_exp_default_image($k))).'"> <button type="button" class="button lux-media" data-target="'.esc_attr($id).'">Choose image</button></p>';return;}
  echo '<p><label for="'.esc_attr($id).'"><strong>'.esc_html($label).'</strong></label><br>'.($type==='textarea'?'<textarea class="large-text" rows="2" id="'.esc_attr($id).'" name="lux_experiences['.esc_attr($k).']" placeholder="'.esc_attr($ph).'">'.esc_textarea($val).'</textarea>':'<input class="large-text" id="'.esc_attr($id).'" name="lux_experiences['.esc_attr($k).']" value="'.esc_attr($val).'" placeholder="'.esc_attr($ph).'">').'</p>';};
 $box=function($title,$link,$cb){echo '<div style="background:#fff;border:1px solid #c3c4c7;padding:4px 20px 12px;margin:0 0 18px;max-width:900px"><h2>'.esc_html($title).($link?' <a class="page-title-action" href="'.esc_url($link).'" target="_blank">View</a>':'').'</h2>';$cb();echo '</div>';};
 $page=get_page_by_path('experiences');$base=$page?get_permalink($page):home_url('/experiences/');
 ?><div class="wrap"><h1>Experiences page</h1><?php if(isset($_GET['updated']))echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';?>
 <p>Texts and photos of the Experiences section. Empty fields use the text shown in grey. Tours and packages themselves are managed in <a href="<?php echo esc_url(admin_url('edit.php?post_type=lux_experience'));?>">Experiences</a>: add one, choose its collection, and its card appears automatically.</p>
 <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="lux_exp_settings"><?php wp_nonce_field('lux_exp_settings');
 $box('Main page — banner',$base,function()use($field){$field('hero_eyebrow','Small heading');$field('hero_title','Title');$field('hero_title_em','Title, second line (italic)');$field('hero_text','Text','textarea');$field('hero_image','Banner photo','image');});
 foreach(lux_exp_collections() as $slug=>$name){$box($name,trailingslashit($base).$slug.'/',function()use($field,$slug,$name){echo '<h3>Card on the main page</h3>';$field($slug.'_card','Card text','textarea');$field($slug.'_cta','Card link text');$field($slug.'_image','Card photo','image');echo '<h3>'.($slug==='concierge-service'?'Concierge page':'Collection page').'</h3>';$field($slug.'_title','Title');$field($slug.'_text','Subtitle','textarea');$field($slug.'_hero','Banner photo','image');if($slug==='concierge-service'){for($i=1;$i<=4;$i++){echo '<div style="display:grid;grid-template-columns:1fr 2fr;gap:12px">';$field('service_'.$i.'_title','Service '.$i.' title');$field('service_'.$i.'_text','Service '.$i.' text','textarea');echo '</div>';}$field('concierge_cta','Button text');}});}
 $box('Contact',null,function()use($field){$field('email','Email shown next to “Request availability”');$field('whatsapp','WhatsApp number (international format, e.g. +995 555 000 000). Leave empty to hide WhatsApp links.');$field('notify','Send new experience requests to (leave empty to use the notification email from Apartment setup)');echo '<p class="description">Requests from the “Request availability” forms are always saved in Booking requests.</p>';});
 submit_button('Save Experiences page');?></form></div><?php
}
add_action('admin_post_lux_exp_settings',function(){
 if(!current_user_can('manage_options'))wp_die('Not allowed',403);check_admin_referer('lux_exp_settings');
 $in=(array)wp_unslash($_POST['lux_experiences']??[]);$out=[];
 foreach(lux_exp_defaults() as $k=>$d){$v=(string)($in[$k]??'');$out[$k]=in_array($k,['email','notify'],true)?sanitize_email($v):(str_ends_with($k,'_image')||str_ends_with($k,'_hero')?esc_url_raw(trim($v)):(str_ends_with($k,'_text')||str_ends_with($k,'_card')?sanitize_textarea_field($v):sanitize_text_field($v)));}
 update_option('lux_experiences',$out);wp_safe_redirect(admin_url('admin.php?page=luxury-experiences&updated=1'));exit;
});
add_action('admin_enqueue_scripts',function($hook){$screen=get_current_screen();if($hook!=='luxury-setup_page_luxury-experiences'&&($screen->post_type??'')!=='lux_experience')return;wp_enqueue_media();wp_enqueue_script('lux-exp-admin',plugins_url('assets/experiences-admin.js',__FILE__),['jquery'],filemtime(__DIR__.'/assets/experiences-admin.js'),true);});

// "Request availability": saved privately in Booking requests.
add_action('rest_api_init',function(){register_rest_route('luxury/v1','/experience-request',['methods'=>'POST','callback'=>'lux_submit_experience_request','permission_callback'=>'__return_true']);});
function lux_submit_experience_request($request){
 $d=$request->get_json_params();if(!is_array($d)||!is_string($d['nonce']??null)||!wp_verify_nonce($d['nonce'],'lux_booking'))return lux_booking_error('Your form has expired. Please try again.',403);
 foreach(['name','email','phone','dates','notes','website','requestKey','format'] as $f)if(isset($d[$f])&&!is_string($d[$f]))return lux_booking_error('Please use valid text values.');
 if(!empty($d['website']))return lux_booking_error('Unable to submit this request.');
 $name=sanitize_text_field($d['name']??'');$email=sanitize_email($d['email']??'');$phone=sanitize_text_field($d['phone']??'');$dates=sanitize_text_field($d['dates']??'');$notes=sanitize_textarea_field($d['notes']??'');$format=sanitize_text_field($d['format']??'');if(strlen($format)>60)$format=substr($format,0,60);
 if(strlen($name)<2||strlen($name)>120||!is_email($email)||strlen($phone)<5||strlen($phone)>40||strlen($dates)>120||strlen($notes)>3000||empty($d['consent']))return lux_booking_error('Please check your name, email, phone and privacy consent.');
 $guests=filter_var($d['guests']??null,FILTER_VALIDATE_INT);if($guests!==false&&$guests!==null&&($guests<1||$guests>50))return lux_booking_error('Enter between 1 and 50 guests.');
 $target=$d['experience']??'';
 if(is_string($target)&&isset(lux_exp_collections()[$target])){$subject=['id'=>0,'title'=>lux_exp_settings()[$target.'_title'],'collection'=>$target,'url'=>home_url('/experiences/'.$target.'/')];}
 else{$id=absint($target);if(get_post_type($id)!=='lux_experience'||get_post_status($id)!=='publish')return lux_booking_error('This experience is no longer available. Please reload the page.');$it=lux_exp_item($id);$subject=['id'=>$id,'title'=>$it['title'],'collection'=>$it['collection'],'url'=>$it['url']];}
 $token=$d['requestKey']??'';if(!preg_match('/^[a-zA-Z0-9-]{16,80}$/',$token))return lux_booking_error('Please refresh the form and try again.');$key=hash('sha256','exp|'.$token.'|'.$email);
 $existing=get_posts(['post_type'=>'lux_booking','post_status'=>'private','meta_key'=>'_lux_request_key','meta_value'=>$key,'numberposts'=>1]);if($existing){$saved=get_post_meta($existing[0]->ID,'_lux_request',true);return new WP_REST_Response(['reference'=>$saved['reference'],'status'=>'received','demo'=>defined('LUXURY_DEMO')&&LUXURY_DEMO]);}
 $limit='lux_rate_'.hash('sha256',($_SERVER['REMOTE_ADDR']??'unknown').wp_salt());$count=(int)get_transient($limit);if($count>=10)return lux_booking_error('Too many requests. Please try again later.',429);
 $lock='lux_lock_'.$key;if(!add_option($lock,time(),'','no'))return lux_booking_error('Your request is being processed. Please retry in a moment.',409);
 $ref='LX-'.strtoupper(substr(str_replace('-','',wp_generate_uuid4()),0,10));
 $payload=['kind'=>'experience','reference'=>$ref,'experience'=>$subject,'name'=>$name,'email'=>$email,'phone'=>$phone,'dates'=>$dates,'guests'=>$guests?:'','format'=>$format,'notes'=>$notes,'created'=>current_time('mysql'),'apartments'=>[]];
 $id=wp_insert_post(['post_type'=>'lux_booking','post_status'=>'private','post_title'=>$ref.' · '.$subject['title'].' · '.$name],true);
 if(is_wp_error($id)){delete_option($lock);return lux_booking_error('We could not save your request. Please try again.',500);}
 update_post_meta($id,'_lux_request',$payload);update_post_meta($id,'_lux_request_key',$key);update_post_meta($id,'_lux_status','new');delete_option($lock);set_transient($limit,$count+1,10*MINUTE_IN_SECONDS);
 $to=lux_exp_settings()['notify']?:get_option('lux_booking_email','');$demo=defined('LUXURY_DEMO')&&LUXURY_DEMO;if(!$demo&&is_email($to)){$sent=wp_mail($to,'New experience request '.$ref,'A new request for '.$subject['title']." is saved in WordPress.\n".admin_url('post.php?post='.$id.'&action=edit'));update_post_meta($id,'_lux_notification_sent',$sent?'yes':'no');}
 return new WP_REST_Response(['reference'=>$ref,'status'=>'received','demo'=>$demo],201);
}

// Starter content: new tours and packages; legacy demo entries are moved to drafts, never deleted.
function lux_import_experiences(){
 $report=[];foreach(lux_exp_collections() as $slug=>$name)if(!term_exists($slug,'lux_exp_group'))wp_insert_term($name,'lux_exp_group',['slug'=>$slug]);
 foreach(['holidays-abroad','custom-trip'] as $old){$t=get_term_by('slug',$old,'lux_exp_group');if($t&&!$t->count)wp_delete_term($t->term_id,'lux_exp_group');}
 $legacy=['zanzibar-packages','island-escapes','city-breaks','batumi-coast-tour','tbilisi-city-tour','gudauri-mountain-tour','custom-trips','sea-and-mountains','private-driver','airport-transfers','concierge','special-occasions','a-day-by-the-sea','old-town-and-piazza','botanical-garden'];
 foreach(get_posts(['post_type'=>'lux_experience','post_status'=>'publish','numberposts'=>-1,'post_name__in'=>$legacy]) as $p)if(get_post_meta($p->ID,'_lux_seed_article',true)==='1'){wp_update_post(['ID'=>$p->ID,'post_status'=>'draft']);$report[]='Moved to drafts (old structure): '.$p->post_title;}
 $seed=json_decode(file_get_contents(__DIR__.'/experiences-seed.json'),true);
 foreach($seed as $i=>$e){
  $found=get_posts(['post_type'=>'lux_experience','post_status'=>['publish','draft','pending','private','future','trash'],'meta_key'=>'_lux_exp_seed','meta_value'=>$e['slug'],'numberposts'=>1]);
  if($found){$report[]='Kept experience: '.$e['title'];continue;}
  $status=($e['status']??'publish')==='draft'?'draft':'publish';
  $id=wp_insert_post(['post_type'=>'lux_experience','post_title'=>$e['title'],'post_name'=>$e['slug'],'post_excerpt'=>$e['summary'],'post_content'=>$e['content'],'post_status'=>$status,'menu_order'=>$i],true);
  if(is_wp_error($id)){$report[]=$id->get_error_message();continue;}
  $term=get_term_by('slug',$e['collection'],'lux_exp_group');if($term)wp_set_object_terms($id,[(int)$term->term_id],'lux_exp_group');
  if(!empty($e['types']))wp_set_object_terms($id,$e['types'],'lux_exp_type');
  foreach(['subtitle','duration','locations','format','stay_title','stay_text','cta'] as $k)if(isset($e[$k])&&$e[$k]!=='')update_post_meta($id,'_lux_exp_'.$k,$e[$k]);
  foreach(array_keys(lux_exp_list_fields()) as $k)update_post_meta($id,'_lux_exp_'.$k,$e[$k]??[]);
  if(!empty($e['price_rows'])){$rows=[];foreach($e['price_rows'] as $row){if(is_array($row)&&count($row)>=2)$rows[]=['label'=>(string)$row[0],'amount'=>(int)$row[1]];}update_post_meta($id,'_lux_exp_price_rows',$rows);update_post_meta($id,'_lux_exp_price_currency',($e['price_currency']??'GEL')==='USD'?'USD':'GEL');update_post_meta($id,'_lux_exp_price_unit',$e['price_unit']??'');}
  update_post_meta($id,'_lux_exp_seed',$e['slug']);
  if(function_exists('lux_import_image')){$img=lux_import_image($e['image'],$e['alt']);if($img)set_post_thumbnail($id,$img);if(!empty($e['stay_gallery'])&&function_exists('lux_theme_asset')){update_post_meta($id,'_lux_exp_stay_gallery',array_map(fn($n)=>lux_theme_asset('images/'.$n.'.webp'),$e['stay_gallery']));}
  if(!empty($e['stay_image'])){$s=lux_import_image($e['stay_image'],$e['stay_title']);if($s)update_post_meta($id,'_lux_exp_stay_image',wp_get_attachment_url($s));}}
  $report[]='Created experience: '.$e['title'];
 }
 flush_rewrite_rules(false);return $report;
}
