<?php
if(!defined('ABSPATH'))exit;
// Online prepayment through Flitt (https://docs.flitt.com). After the booking form the guest is sent to the Flitt payment page
// for the prepayment chosen in the form (30% or 100%). Flitt reports the result to the server (server_callback_url);
// only a correctly signed "approved" result for the exact amount in GEL is recorded. Then the booking is confirmed and the
// PDF confirmation is issued and emailed (voucher-doc.php). The browser return page alone never marks anything as paid.

const LUXF_API='https://pay.flitt.com/api';

function luxf_settings(){return wp_parse_args((array)get_option('lux_flitt',[]),['mode'=>'off','merchant_id'=>'','secret'=>'','auto_confirm'=>1]);}
// Test mode: only logged-in administrators are sent to payment, so real guests are never charged by a test page.
function luxf_enabled(){$s=luxf_settings();if(!$s['merchant_id']||!$s['secret'])return false;return $s['mode']==='live'||($s['mode']==='test'&&current_user_can('manage_options'));}

// Signature: SHA-1 of the secret and every non-empty parameter value, sorted by parameter name, joined with "|".
function luxf_signature($params,$secret){
 unset($params['signature'],$params['response_signature_string']);
 $params=array_filter(array_map(fn($v)=>is_scalar($v)?(string)$v:wp_json_encode($v),$params),'strlen');ksort($params);
 return sha1($secret.'|'.implode('|',$params));
}
function luxf_verified($data){$s=luxf_settings();return is_array($data)&&!empty($data['signature'])&&$s['secret']!==''&&hash_equals(luxf_signature($data,$s['secret']),(string)$data['signature']);}
function luxf_request($path,$params){
 $s=luxf_settings();$params['merchant_id']=(int)$s['merchant_id'];$params['version']='1.0.1';$params['signature']=luxf_signature($params,$s['secret']);
 $r=wp_remote_post(LUXF_API.$path,['timeout'=>25,'headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode(['request'=>$params])]);
 if(is_wp_error($r))return ['response_status'=>'failure','error_message'=>$r->get_error_message()];
 $j=json_decode(wp_remote_retrieve_body($r),true);return is_array($j['response']??null)?$j['response']:['response_status'=>'failure','error_message'=>'Unexpected answer from Flitt'];
}

// How much to collect now: the prepayment the guest chose (Last Minute: 100%), minus what is already paid. In tetri.
function luxf_due_now($id){
 $d=get_post_meta($id,'_lux_request',true);$b=$d['breakdown']??null;if(!$b||$b['total']===null)return 0;
 $bal=luxv_balance($id);$target=luxv_rate($d)==='last_minute'?$bal['total']:luxv_tetri($b['payment']['due_now']);
 $target=max($target,(int)luxv_required($id,$d));return max(0,min($target,(int)$bal['total'])-(int)$bal['paid']);
}
function luxf_attempts($id){$a=get_post_meta($id,'_lux_pay_attempts',true);return is_array($a)?array_filter($a,'is_array'):[];}
function luxf_key_ok($id,$key){return $id&&$key!==''&&hash_equals((string)get_post_meta($id,'_lux_voucher_key',true),(string)$key);}
function luxf_booking_by_ref($ref){$p=get_posts(['post_type'=>'lux_booking','post_status'=>'private','numberposts'=>1,'meta_key'=>'_lux_reference','meta_value'=>sanitize_text_field($ref)]);return $p?$p[0]->ID:0;}
function luxf_pay_url($id){$d=get_post_meta($id,'_lux_request',true);return add_query_arg(['lux_pay'=>rawurlencode($d['reference']),'vk'=>get_post_meta($id,'_lux_voucher_key',true)],home_url('/'));}
// Used by the booking form: with online payment on, the guest goes straight to the payment page.
function luxf_online_for($id){return luxf_enabled()&&luxf_due_now($id)>0;}
function luxf_after_submit_url($id){if(!luxf_online_for($id))return '';update_post_meta($id,'_lux_pay_online','1');return luxf_pay_url($id);}

function luxf_schedule_reminder($id){update_post_meta($id,'_lux_pay_online','1');wp_schedule_single_event(time()+30*MINUTE_IN_SECONDS,'luxf_unpaid_reminder',[$id]);}
add_action('luxf_unpaid_reminder',function($id){if(luxf_due_now($id)<=0||get_post_meta($id,'_lux_voucher_received',true))return;lux_send_voucher($id,'received');});
function luxf_texts($L){$T=[
 'en'=>['pay_btn'=>'Complete the prepayment','ok_title'=>'Payment received','ok_text'=>'Thank you! Your prepayment is received and your booking is confirmed. The booking confirmation (voucher) has been sent to %s.','ok_pending'=>'Thank you! Your payment is received. Our team will send your booking confirmation (voucher) shortly.','view'=>'View your confirmation','fail_title'=>'Payment not completed','fail_text'=>'The payment was not completed and no money has been taken. You can try again or contact us — your booking request is saved.','processing_title'=>'Payment is being processed','processing_text'=>'Your bank is still processing the payment. As soon as it is approved you will receive the booking confirmation by email.','retry'=>'Try the payment again','error'=>'The payment page could not be opened. Please try again in a few minutes or contact us.','desc'=>'Prepayment for booking %s · Luxury Apart Hotel Group','next_online'=>'Next step: complete the prepayment on the secure payment page. As soon as the payment is received, your booking confirmation (voucher) is sent to you as a PDF.'],
 'ru'=>['pay_btn'=>'Внести предоплату','ok_title'=>'Оплата получена','ok_text'=>'Спасибо! Предоплата получена, бронирование подтверждено. Подтверждение бронирования (ваучер) отправлено на %s.','ok_pending'=>'Спасибо! Оплата получена. Наш менеджер в ближайшее время пришлёт подтверждение бронирования (ваучер).','view'=>'Открыть подтверждение','fail_title'=>'Оплата не завершена','fail_text'=>'Оплата не прошла, деньги не списаны. Попробуйте ещё раз или свяжитесь с нами — ваш запрос на бронирование сохранён.','processing_title'=>'Оплата обрабатывается','processing_text'=>'Банк ещё обрабатывает платёж. Как только он будет подтверждён, вы получите подтверждение бронирования по email.','retry'=>'Попробовать оплатить ещё раз','error'=>'Не удалось открыть страницу оплаты. Попробуйте через несколько минут или свяжитесь с нами.','desc'=>'Предоплата за бронирование %s · Luxury Apart Hotel Group','next_online'=>'Следующий шаг: внесите предоплату на защищённой странице оплаты. Как только оплата поступит, вы получите подтверждение бронирования (ваучер) в PDF.'],
 'ka'=>['pay_btn'=>'წინასწარი გადახდის შესრულება','ok_title'=>'გადახდა მიღებულია','ok_text'=>'გმადლობთ! წინასწარი გადახდა მიღებულია და ჯავშანი დადასტურებულია. ჯავშნის დადასტურება (ვაუჩერი) გაიგზავნა მისამართზე %s.','ok_pending'=>'გმადლობთ! გადახდა მიღებულია. ჩვენი გუნდი მალე გამოგიგზავნით ჯავშნის დადასტურებას (ვაუჩერს).','view'=>'დადასტურების ნახვა','fail_title'=>'გადახდა არ დასრულდა','fail_text'=>'გადახდა არ შესრულდა და თანხა არ ჩამოჭრილა. სცადეთ ხელახლა ან დაგვიკავშირდით — თქვენი მოთხოვნა შენახულია.','processing_title'=>'გადახდა მუშავდება','processing_text'=>'ბანკი ჯერ კიდევ ამუშავებს გადახდას. დადასტურებისთანავე ელფოსტით მიიღებთ ჯავშნის დადასტურებას.','retry'=>'გადახდის ხელახლა ცდა','error'=>'გადახდის გვერდი ვერ გაიხსნა. სცადეთ რამდენიმე წუთში ან დაგვიკავშირდით.','desc'=>'წინასწარი გადახდა ჯავშნისთვის %s · Luxury Apart Hotel Group','next_online'=>'შემდეგი ნაბიჯი: შეასრულეთ წინასწარი გადახდა დაცულ გადახდის გვერდზე. გადახდის მიღებისთანავე მიიღებთ ჯავშნის დადასტურებას (ვაუჩერს) PDF ფორმატში.'],
];return $T[$L]??$T['en'];}

// Records an approved payment once (keyed by Flitt payment_id), confirms the booking and issues the PDF confirmation.
function luxf_apply($id,$data,$source){
 $order=(string)($data['order_id']??'');$attempts=luxf_attempts($id);if(!isset($attempts[$order]))return 'unknown order';
 $status=(string)($data['order_status']??'');$attempts[$order]['status']=$status;$attempts[$order]['checked']=current_time('mysql');$attempts[$order]['via']=$source;
 if(!empty($data['response_description']))$attempts[$order]['message']=sanitize_text_field($data['response_description']);
 update_post_meta($id,'_lux_pay_attempts',$attempts);
 if($status!=='approved'||($data['response_status']??'')!=='success')return $status?:'not approved';
 $amount=(int)($data['actual_amount']??$data['amount']??0);
 if(strtoupper((string)($data['currency']??''))!=='GEL'||(int)($data['amount']??0)!==(int)$attempts[$order]['amount']||$amount<=0){$attempts[$order]['status']='mismatch';update_post_meta($id,'_lux_pay_attempts',$attempts);return 'amount or currency mismatch';}
 $lock='lux_paylock_'.$id;for($i=0;$i<30&&!add_option($lock,time(),'','no');$i++){if((int)get_option($lock)<time()-30)delete_option($lock);usleep(200000);}
 $pays=luxv_payments($id);$txn=(string)($data['payment_id']??$order);
 foreach($pays as $p)if(($p['txn']??'')===$txn||($p['order_id']??'')===$order){delete_option($lock);return 'approved';}
 $pays[]=['date'=>wp_date('Y-m-d'),'amount'=>$amount,'method'=>'card','txn'=>$txn,'by'=>0,'at'=>current_time('mysql'),'source'=>'flitt','order_id'=>$order,'card'=>sanitize_text_field((string)($data['masked_card']??''))];
 update_post_meta($id,'_lux_payments',$pays);delete_option($lock);
 $s=luxf_settings();if($s['auto_confirm']&&in_array(get_post_meta($id,'_lux_status',true),['new','reviewing',''],true))update_post_meta($id,'_lux_status','confirmed');
 if(!luxv_missing($id))luxv_issue($id,'online payment');
 else{$d=get_post_meta($id,'_lux_request',true);wp_mail(lux_booking_notify_email(),'Online payment received '.$d['reference'].' · voucher not issued yet',"An online payment of ".luxv_money($amount,'en')." was received (Flitt payment ".$txn.").\nThe confirmation voucher was not issued automatically. Still needed: ".implode('; ',luxv_missing($id)).".\n\n".admin_url('post.php?post='.$id.'&action=edit'),[luxv_from_header()]);}
 return 'approved';
}

// Payment page: /?lux_pay=LAH-2026-0001&vk=… creates a Flitt order for the amount due and sends the guest there.
// Return page: /?lux_pay_return=…&vk=… (Flitt posts the result here; it is checked, then the guest sees the outcome).
add_filter('query_vars',fn($v)=>array_merge($v,['lux_pay','lux_pay_return']));
add_action('template_redirect',function(){
 $pay=get_query_var('lux_pay');$ret=get_query_var('lux_pay_return');if(!$pay&&!$ret)return;
 $id=luxf_booking_by_ref($pay?:$ret);$key=(string)($_GET['vk']??'');if(!luxf_key_ok($id,$key)){status_header(404);nocache_headers();exit('This link is not valid.');}
 $d=get_post_meta($id,'_lux_request',true);$L=luxv_locale($id);$T=luxf_texts($L);nocache_headers();header('X-Robots-Tag: noindex, nofollow');
 if($pay){
  $due=luxf_due_now($id);if($due<=0){wp_safe_redirect(lux_voucher_url($id));exit;}
  $s=luxf_settings();if(!$s['merchant_id']||!$s['secret']||$s['mode']==='off'){luxf_page($L,$T['fail_title'],$T['error'],[]);}
  $order=$d['reference'].'-'.time();
  $r=luxf_request('/checkout/url',['order_id'=>$order,'order_desc'=>sprintf($T['desc'],$d['reference']),'amount'=>$due,'currency'=>'GEL','lang'=>$L,'sender_email'=>$d['email'],'lifetime'=>3600,
   'response_url'=>add_query_arg(['lux_pay_return'=>rawurlencode($d['reference']),'vk'=>$key],home_url('/')),'server_callback_url'=>rest_url('luxury/v1/flitt-callback')]);
  if(($r['response_status']??'')!=='success'||empty($r['checkout_url'])){update_post_meta($id,'_lux_pay_error',sanitize_text_field(($r['error_code']??'').' '.($r['error_message']??'')));luxf_page($L,$T['fail_title'],$T['error'],[['url'=>luxf_pay_url($id),'label'=>$T['retry']]]);}
  $attempts=luxf_attempts($id);$attempts[$order]=['amount'=>$due,'status'=>'created','created'=>current_time('mysql'),'mode'=>$s['mode']];update_post_meta($id,'_lux_pay_attempts',$attempts);add_post_meta($id,'_lux_pay_order',$order);
  wp_redirect($r['checkout_url']);exit;
 }
 // Return: use the signed data Flitt posts; otherwise ask Flitt for the latest order status.
 $data=wp_unslash($_POST);$attempts=luxf_attempts($id);
 if(!luxf_verified($data)){$last=array_key_last($attempts);$data=$last?luxf_request('/status/order_id',['order_id'=>$last]):[];if(!luxf_verified($data))$data=['order_id'=>$last,'order_status'=>$attempts[$last]['status']??''];}
 $result=!empty($data['signature'])?luxf_apply($id,$data,'return'):($data['order_status']??'');
 $bal=luxv_balance($id);
 if($result==='approved'||($bal['paid']>0&&$bal['paid']>=(int)luxv_required($id,$d))){$issued=(bool)luxv_versions($id);luxf_page($L,$T['ok_title'],$issued?sprintf($T['ok_text'],$d['email']):$T['ok_pending'],$issued?[['url'=>lux_voucher_url($id),'label'=>$T['view']]]:[]);}
 if(in_array($result,['processing','created'],true))luxf_page($L,$T['processing_title'],$T['processing_text'],[]);
 luxf_page($L,$T['fail_title'],$T['fail_text'],[['url'=>luxf_pay_url($id),'label'=>$T['retry']]]);
},5);
function luxf_page($L,$title,$text,$buttons){
 $ka=$L==='ka'?"'Noto Sans Georgian',":'';
 echo '<!doctype html><html lang="'.esc_attr($L).'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="google" content="notranslate"><title>'.esc_html($title).'</title><style>'.(function_exists('luxv_font_faces')?luxv_font_faces(plugins_url('assets/fonts/',__FILE__)):'').'body{margin:0;background:#f8f7f3;color:#171717;font-family:'.$ka.'Calibri,Carlito,Helvetica,Arial,sans-serif;display:grid;place-items:center;min-height:100vh;padding:24px;box-sizing:border-box}.box{max-width:560px;background:#fff;border:1px solid #e4e4dc;padding:36px 34px}h1{font-family:'.($L==='ka'?"'Noto Serif Georgian',":'').'Georgia,serif;font-weight:normal;font-size:32px;margin:14px 0 12px}p{font-size:16px;line-height:1.55;color:#474e42}a.btn{display:inline-block;background:#050505;color:#fff;text-decoration:none;padding:13px 20px;margin:10px 10px 0 0;font-size:15px}.c{font-size:13px;color:#666;margin-top:22px}</style></head><body class="notranslate" translate="no"><div class="box"><img src="'.esc_url(plugins_url('assets/voucher-logo.jpg',__FILE__)).'" alt="Luxury Apart Hotel Group" width="64"><h1>'.esc_html($title).'</h1><p>'.esc_html($text).'</p>';
 foreach($buttons as $b)echo '<a class="btn" href="'.esc_url($b['url']).'">'.esc_html($b['label']).'</a>';
 echo '<a class="btn" style="background:#fff;color:#171717;border:1px solid #171717" href="'.esc_url(home_url('/')).'">Luxury Apart Hotel Group</a><p class="c">WhatsApp +995 557 528 285 · reservations@luxuryaparthotel.ge · +995 555 907 333</p></div></body></html>';exit;
}

// Host-to-host result from Flitt (JSON POST). Answered with 200 once processed, so Flitt stops retrying.
add_action('rest_api_init',function(){register_rest_route('luxury/v1','/flitt-callback',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>function($request){
 $data=$request->get_json_params();if(!is_array($data)||!$data)$data=$request->get_body_params();
 if(!luxf_verified($data))return new WP_REST_Response(['ok'=>false,'error'=>'bad signature'],400);
 $order=sanitize_text_field((string)($data['order_id']??''));$p=get_posts(['post_type'=>'lux_booking','post_status'=>'private','numberposts'=>1,'meta_key'=>'_lux_pay_order','meta_value'=>$order]);
 if(!$p)return new WP_REST_Response(['ok'=>true,'note'=>'unknown order'],200);
 return new WP_REST_Response(['ok'=>true,'result'=>luxf_apply($p[0]->ID,$data,'callback')],200);
}]);});

// Settings: Luxury → Online payment.
add_action('admin_menu',function(){add_submenu_page('luxury-setup','Online payment (Flitt)','Online payment','manage_options','luxury-payment','luxf_settings_page');});
add_action('admin_post_luxf_save',function(){
 if(!current_user_can('manage_options'))wp_die('No access');check_admin_referer('luxf_save');$old=luxf_settings();$in=wp_unslash($_POST);
 $secret=trim((string)($in['secret']??''));
 update_option('lux_flitt',['mode'=>in_array($in['mode']??'',['off','test','live'],true)?$in['mode']:'off','merchant_id'=>preg_replace('/\D/','',(string)($in['merchant_id']??'')),'secret'=>$secret!==''?$secret:$old['secret'],'auto_confirm'=>empty($in['auto_confirm'])?0:1],false);
 wp_safe_redirect(admin_url('admin.php?page=luxury-payment&updated=1'));exit;
});
function luxf_settings_page(){
 if(!current_user_can('manage_options'))return;$s=luxf_settings();?>
 <div class="wrap"><h1>Online payment (Flitt)</h1><?php if(isset($_GET['updated']))echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';?>
 <p>After the booking form the guest pays the chosen prepayment (30% or 100%) on the Flitt payment page. When Flitt confirms the payment, it is recorded in the booking, the booking is confirmed and the PDF confirmation is emailed to the guest and to Reservations.</p>
 <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="luxf_save"><?php wp_nonce_field('luxf_save');?>
 <table class="form-table" role="presentation">
 <tr><th scope="row">Mode</th><td><select name="mode"><option value="off" <?php selected($s['mode'],'off');?>>Off — booking requests only</option><option value="test" <?php selected($s['mode'],'test');?>>Test — only for logged-in administrators</option><option value="live" <?php selected($s['mode'],'live');?>>Live — all guests pay online</option></select><p class="description">In Test mode guests keep sending requests as before; only you (logged in) are sent to the Flitt test page. Test cards: 4444 5555 1111 6666 (approved), 4444 1111 5555 6666 (declined), any expiry date and CVV.</p></td></tr>
 <tr><th scope="row">Merchant ID</th><td><input name="merchant_id" value="<?php echo esc_attr($s['merchant_id']);?>" class="regular-text" placeholder="e.g. 1549901"><p class="description">portal.flitt.com → Merchant → Technical settings. Flitt's public test merchant: 1549901 with key <code>test</code>.</p></td></tr>
 <tr><th scope="row">Payment secret key</th><td><input type="password" name="secret" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo $s['secret']?'saved — leave empty to keep':'';?>"></td></tr>
 <tr><th scope="row">After payment</th><td><label><input type="checkbox" name="auto_confirm" value="1" <?php checked($s['auto_confirm'],1);?>> Confirm the booking automatically and email the PDF confirmation</label></td></tr>
 <tr><th scope="row">Callback URL</th><td><code><?php echo esc_html(rest_url('luxury/v1/flitt-callback'));?></code><p class="description">Sent to Flitt with every payment; nothing to set in the portal. Flitt calls it from 54.154.216.60 and 3.75.125.89 — these must not be blocked by a firewall.</p></td></tr>
 </table><?php submit_button();?></form></div><?php
}
