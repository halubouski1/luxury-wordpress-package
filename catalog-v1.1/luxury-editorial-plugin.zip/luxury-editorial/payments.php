<?php
if(!defined('ABSPATH'))exit;
// Online prepayment through Flitt (https://docs.flitt.com). After the booking form the guest is sent to the Flitt payment page
// for the prepayment chosen in the form (30% or 100%). Flitt reports the result to the server (server_callback_url);
// only a correctly signed "approved" result for the exact amount in GEL is recorded. Then the booking is confirmed and the
// PDF confirmation is issued and emailed (voucher-doc.php). The browser return page alone never marks anything as paid.

const LUXF_API='https://pay.flitt.com/api';

function luxf_settings(){return wp_parse_args((array)get_option('lux_flitt',[]),['mode'=>'off','merchant_id'=>'','secret'=>'','auto_confirm'=>1]);}
// Test mode: only logged-in administrators are sent to payment, so real guests are never charged by a test page.
function luxf_enabled(){$s=luxf_settings();if(!$s['merchant_id']||!$s['secret'])return false;return $s['mode']==='live'||($s['mode']==='test'&&current_user_can('manage_options'));}

// Signature: SHA-1 of the secret and every non-empty parameter value, sorted by parameter name, joined with "|".
function luxf_signature($params,$secret){
 unset($params['signature'],$params['response_signature_string']);
 $params=array_filter(array_map(fn($v)=>is_scalar($v)?(string)$v:wp_json_encode($v),$params),'strlen');ksort($params);
 return sha1($secret.'|'.implode('|',$params));
}
function luxf_verified($data){$s=luxf_settings();return is_array($data)&&!empty($data['signature'])&&$s['secret']!==''&&hash_equals(luxf_signature($data,$s['secret']),(string)$data['signature']);}
function luxf_request($path,$params){
 $s=luxf_settings();$params['merchant_id']=(int)$s['merchant_id'];$params['version']='1.0.1';$params['signature']=luxf_signature($params,$s['secret']);
 $r=wp_remote_post(LUXF_API.$path,['timeout'=>25,'headers'=>['Content-Type'=>'application/json'],'body'=>wp_json_encode(['request'=>$params])]);
 if(is_wp_error($r))return ['response_status'=>'failure','error_message'=>$r->get_error_message()];
 $j=json_decode(wp_remote_retrieve_body($r),true);return is_array($j['response']??null)?$j['response']:['response_status'=>'failure','error_message'=>'Unexpected answer from Flitt'];
}

// How much to collect now: the prepayment the guest chose (Last Minute: 100%), minus what is already paid. In tetri.
function luxf_due_now($id){
 $d=get_post_meta($id,'_lux_request',true);$b=$d['breakdown']??null;if(!$b||$b['total']===null)return 0;
 $bal=luxv_balance($id);$target=luxv_rate($d)==='last_minute'?$bal['total']:luxv_tetri($b['payment']['due_now']);
 $target=max($target,(int)luxv_required($id,$d));return max(0,min($target,(int)$bal['total'])-(int)$bal['paid']);
}
function luxf_attempts($id){$a=get_post_meta($id,'_lux_pay_attempts',true);return is_array($a)?array_filter($a,'is_array'):[];}
function luxf_key_ok($id,$key){return $id&&$key!==''&&hash_equals((string)get_post_meta($id,'_lux_voucher_key',true),(string)$key);}
function luxf_booking_by_ref($ref){$p=get_posts(['post_type'=>'lux_booking','post_status'=>'private','numberposts'=>1,'meta_key'=>'_lux_reference','meta_value'=>sanitize_text_field($ref)]);return $p?$p[0]->ID:0;}
function luxf_pay_url($id){$d=get_post_meta($id,'_lux_request',true);return add_query_arg(['lux_pay'=>rawurlencode($d['reference']),'vk'=>get_post_meta($id,'_lux_voucher_key',true)],home_url('/'));}
// Used by the booking form: with online payment on, the guest goes straight to the payment page.
function luxf_online_for($id){return luxf_enabled()&&luxf_due_now($id)>0;}
function luxf_after_submit_url($id){if(!luxf_online_for($id))return '';update_post_meta($id,'_lux_pay_online','1');return luxf_pay_url($id);}

function luxf_schedule_reminder($id){update_post_meta($id,'_lux_pay_online','1');wp_schedule_single_event(time()+30*MINUTE_IN_SECONDS,'luxf_unpaid_reminder',[$id]);}
add_action('luxf_unpaid_reminder',function($id){if(luxf_due_now($id)<=0||get_post_meta($id,'_lux_voucher_received',true))return;lux_send_voucher($id,'received');});
function luxf_texts($L){$T=[
 'en'=>['ok_full'=>'Your booking is confirmed. Paid: %1$s. Balance due: %2$s. Your voucher has been sent to %3$s.','ok_nomail'=>'Your booking is confirmed. Paid: %1$s. Balance due: %2$s. The confirmation email to %3$s is on its way — you can also open or download your voucher here.','download'=>'Download PDF','taken_title'=>'These dates are no longer available','taken_text'=>'Sorry — this apartment has just been booked for these dates. No payment has been taken. Please choose other dates or contact us and we will find another apartment for you.','pay_btn'=>'Complete the prepayment','ok_title'=>'Payment received','ok_text'=>'Thank you! Your prepayment is received and your booking is confirmed. The booking confirmation (voucher) has been sent to %s.','ok_pending'=>'Thank you! Your payment is received. Our team will send your booking confirmation (voucher) shortly.','view'=>'View your confirmation','fail_title'=>'Payment not completed','fail_text'=>'The payment was not completed and no money has been taken. You can try again or contact us — your booking request is saved.','processing_title'=>'Payment is being processed','processing_text'=>'Your bank is still processing the payment. As soon as it is approved you will receive the booking confirmation by email.','retry'=>'Try the payment again','error'=>'The payment page could not be opened. Please try again in a few minutes or contact us.','desc'=>'Prepayment for booking %s · Luxury Apart Hotel Group','next_online'=>'Next step: complete the prepayment on the secure payment page. As soon as the payment is received, your booking confirmation (voucher) is sent to you as a PDF.'],
 'ru'=>['ok_full'=>'Ваше бронирование подтверждено. Оплачено: %1$s. Остаток к оплате: %2$s. Ваучер отправлен на %3$s.','ok_nomail'=>'Ваше бронирование подтверждено. Оплачено: %1$s. Остаток к оплате: %2$s. Письмо с подтверждением на %3$s отправляется — ваучер можно открыть или скачать здесь.','download'=>'Скачать PDF','taken_title'=>'Эти даты уже недоступны','taken_text'=>'К сожалению, эти апартаменты только что забронировали на ваши даты. Оплата не списана. Выберите другие даты или свяжитесь с нами — мы подберём другие апартаменты.','pay_btn'=>'Внести предоплату','ok_title'=>'Оплата получена','ok_text'=>'Спасибо! Предоплата получена, бронирование подтверждено. Подтверждение бронирования (ваучер) отправлено на %s.','ok_pending'=>'Спасибо! Оплата получена. Наш менеджер в ближайшее время пришлёт подтверждение бронирования (ваучер).','view'=>'Открыть подтверждение','fail_title'=>'Оплата не завершена','fail_text'=>'Оплата не прошла, деньги не списаны. Попробуйте ещё раз или свяжитесь с нами — ваш запрос на бронирование сохранён.','processing_title'=>'Оплата обрабатывается','processing_text'=>'Банк ещё обрабатывает платёж. Как только он будет подтверждён, вы получите подтверждение бронирования по email.','retry'=>'Попробовать оплатить ещё раз','error'=>'Не удалось открыть страницу оплаты. Попробуйте через несколько минут или свяжитесь с нами.','desc'=>'Предоплата за бронирование %s · Luxury Apart Hotel Group','next_online'=>'Следующий шаг: внесите предоплату на защищённой странице оплаты. Как только оплата поступит, вы получите подтверждение бронирования (ваучер) в PDF.'],
 'ka'=>['ok_full'=>'თქვენი ჯავშანი დადასტურებულია. გადახდილია: %1$s. გადასახდელი ნაშთი: %2$s. ვაუჩერი გაიგზავნა მისამართზე %3$s.','ok_nomail'=>'თქვენი ჯავშანი დადასტურებულია. გადახდილია: %1$s. გადასახდელი ნაშთი: %2$s. დადასტურების წერილი მისამართზე %3$s იგზავნება — ვაუჩერის ნახვა ან ჩამოტვირთვა შეგიძლიათ აქ.','download'=>'PDF-ის ჩამოტვირთვა','taken_title'=>'ეს თარიღები უკვე დაკავებულია','taken_text'=>'სამწუხაროდ, ეს აპარტამენტი ამ თარიღებზე ახლახან დაიჯავშნა. თანხა არ ჩამოჭრილა. აირჩიეთ სხვა თარიღები ან დაგვიკავშირდით — სხვა აპარტამენტს შემოგთავაზებთ.','pay_btn'=>'წინასწარი გადახდის შესრულება','ok_title'=>'გადახდა მიღებულია','ok_text'=>'გმადლობთ! წინასწარი გადახდა მიღებულია და ჯავშანი დადასტურებულია. ჯავშნის დადასტურება (ვაუჩერი) გაიგზავნა მისამართზე %s.','ok_pending'=>'გმადლობთ! გადახდა მიღებულია. ჩვენი გუნდი მალე გამოგიგზავნით ჯავშნის დადასტურებას (ვაუჩერს).','view'=>'დადასტურების ნახვა','fail_title'=>'გადახდა არ დასრულდა','fail_text'=>'გადახდა არ შესრულდა და თანხა არ ჩამოჭრილა. სცადეთ ხელახლა ან დაგვიკავშირდით — თქვენი მოთხოვნა შენახულია.','processing_title'=>'გადახდა მუშავდება','processing_text'=>'ბანკი ჯერ კიდევ ამუშავებს გადახდას. დადასტურებისთანავე ელფოსტით მიიღებთ ჯავშნის დადასტურებას.','retry'=>'გადახდის ხელახლა ცდა','error'=>'გადახდის გვერდი ვერ გაიხსნა. სცადეთ რამდენიმე წუთში ან დაგვიკავშირდით.','desc'=>'წინასწარი გადახდა ჯავშნისთვის %s · Luxury Apart Hotel Group','next_online'=>'შემდეგი ნაბიჯი: შეასრულეთ წინასწარი გადახდა დაცულ გადახდის გვერდზე. გადახდის მიღებისთანავე მიიღებთ ჯავშნის დადასტურებას (ვაუჩერს) PDF ფორმატში.'],
];return array_merge($T[$L]??$T['en'],luxf_confirm_texts($L));}
// Confirmation screen after a successful payment (client spec of 25 Nov 2026).
function luxf_confirm_texts($L){$T=[
 'en'=>['c_title'=>'Your booking is confirmed','c_thanks'=>'Thank you for your payment! We look forward to welcoming you.','c_sent'=>'We have sent your voucher to %s.','c_later'=>'Your voucher is ready to download below. A copy will also be sent to %s.','c_details'=>'Booking details','c_help'=>'Questions about your booking? Contact our reservations team.','c_prep_title'=>'Payment received','c_prep'=>'Thank you! Your payment is received. We are preparing your voucher — this page will update in a few seconds.','c_apartment'=>'Apartment','c_balance_note'=>'The balance is paid on arrival.'],
 'ru'=>['c_title'=>'Ваше бронирование подтверждено','c_thanks'=>'Спасибо за оплату! Будем рады вашему приезду.','c_sent'=>'Мы отправили ваучер на %s.','c_later'=>'Ваучер можно скачать ниже. Копию мы также отправим на %s.','c_details'=>'Детали бронирования','c_help'=>'Есть вопросы по брони? Свяжитесь с отделом бронирования.','c_prep_title'=>'Оплата получена','c_prep'=>'Спасибо! Оплата получена. Готовим ваш ваучер — страница обновится через несколько секунд.','c_apartment'=>'Апартаменты','c_balance_note'=>'Остаток оплачивается при заселении.'],
 'ka'=>['c_title'=>'თქვენი ჯავშანი დადასტურებულია','c_thanks'=>'გმადლობთ გადახდისთვის! მოხარულები ვიქნებით თქვენი ჩამოსვლით.','c_sent'=>'ვაუჩერი გამოგიგზავნეთ მისამართზე %s.','c_later'=>'ვაუჩერის ჩამოტვირთვა შეგიძლიათ ქვემოთ. ასლს ასევე გამოგიგზავნით მისამართზე %s.','c_details'=>'ჯავშნის დეტალები','c_help'=>'კითხვები გაქვთ ჯავშანთან დაკავშირებით? დაუკავშირდით დაჯავშნის განყოფილებას.','c_prep_title'=>'გადახდა მიღებულია','c_prep'=>'გმადლობთ! გადახდა მიღებულია. ვამზადებთ თქვენს ვაუჩერს — გვერდი რამდენიმე წამში განახლდება.','c_apartment'=>'აპარტამენტი','c_balance_note'=>'ნაშთი გადაიხდება დაბინავებისას.'],
];return $T[$L]??$T['en'];}

// Records an approved payment once (keyed by Flitt payment_id), confirms the booking and issues the PDF confirmation.
function luxf_apply($id,$data,$source){
 $order=(string)($data['order_id']??'');$attempts=luxf_attempts($id);if(!isset($attempts[$order]))return 'unknown order';
 $status=(string)($data['order_status']??'');$attempts[$order]['status']=$status;$attempts[$order]['checked']=current_time('mysql');$attempts[$order]['via']=$source;
 if(!empty($data['response_description']))$attempts[$order]['message']=sanitize_text_field($data['response_description']);
 update_post_meta($id,'_lux_pay_attempts',$attempts);
 if(in_array($status,['declined','expired'],true)&&!luxv_payments($id)&&get_post_meta($id,'_lux_status',true)==='awaiting_payment')update_post_meta($id,'_lux_status','payment_failed');
 if($status!=='approved'||($data['response_status']??'')!=='success')return $status?:'not approved';
 $amount=(int)($data['actual_amount']??$data['amount']??0);
 if(strtoupper((string)($data['currency']??''))!=='GEL'||(int)($data['amount']??0)!==(int)$attempts[$order]['amount']||$amount<=0){$attempts[$order]['status']='mismatch';update_post_meta($id,'_lux_pay_attempts',$attempts);return 'amount or currency mismatch';}
 $lock='lux_paylock_'.$id;for($i=0;$i<30&&!add_option($lock,time(),'','no');$i++){if((int)get_option($lock)<time()-30)delete_option($lock);usleep(200000);}
 $pays=luxv_payments($id);$txn=(string)($data['payment_id']??$order);
 foreach($pays as $p)if(($p['txn']??'')===$txn||($p['order_id']??'')===$order){delete_option($lock);return 'approved';}
 $pays[]=['date'=>wp_date('Y-m-d'),'amount'=>$amount,'method'=>'card','txn'=>$txn,'by'=>0,'at'=>current_time('mysql'),'source'=>'flitt','order_id'=>$order,'card'=>sanitize_text_field((string)($data['masked_card']??''))];
 update_post_meta($id,'_lux_payments',$pays);delete_option($lock);
 $s=luxf_settings();$st=get_post_meta($id,'_lux_status',true);$clash=function_exists('lux_booking_conflicts')?lux_booking_conflicts($id):[];
 // Paid after the hold ended and the apartment was taken meanwhile: never confirm two guests for the same nights.
 if($clash&&$st!=='confirmed'){update_post_meta($id,'_lux_status','reviewing');$dd=get_post_meta($id,'_lux_request',true);wp_mail(lux_booking_notify_email(),'CONFLICT: payment received but dates are taken · '.$dd['reference'],"The guest paid ".luxv_money($amount,'en')." (Flitt payment ".$txn."), but the apartment is no longer free:\n".implode("\n",$clash)."\nThe booking was NOT confirmed automatically. Please resolve it (another apartment or a refund).\n\n".admin_url('post.php?post='.$id.'&action=edit'),[luxv_from_header()]);return 'approved';}
 if($s['auto_confirm']&&in_array($st,['new','reviewing','awaiting_payment','payment_failed',''],true))update_post_meta($id,'_lux_status','confirmed');
 if(!luxv_missing($id))luxv_issue($id,'online payment');
 else{$d=get_post_meta($id,'_lux_request',true);wp_mail(lux_booking_notify_email(),'Online payment received '.$d['reference'].' · voucher not issued yet',"An online payment of ".luxv_money($amount,'en')." was received (Flitt payment ".$txn.").\nThe confirmation voucher was not issued automatically. Still needed: ".implode('; ',luxv_missing($id)).".\n\n".admin_url('post.php?post='.$id.'&action=edit'),[luxv_from_header()]);}
 return 'approved';
}

// Payment page: /?lux_pay=LAH-2026-0001&vk=… creates a Flitt order for the amount due and sends the guest there.
// Return page: /?lux_pay_return=…&vk=… (Flitt posts the result here; it is checked, then the guest sees the outcome).
add_filter('query_vars',fn($v)=>array_merge($v,['lux_pay','lux_pay_return']));
add_action('template_redirect',function(){
 $pay=get_query_var('lux_pay');$ret=get_query_var('lux_pay_return');if(!$pay&&!$ret)return;
 $id=luxf_booking_by_ref($pay?:$ret);$key=(string)($_GET['vk']??'');if(!luxf_key_ok($id,$key)){status_header(404);nocache_headers();exit('This link is not valid.');}
 $d=get_post_meta($id,'_lux_request',true);$L=luxv_locale($id);$T=luxf_texts($L);nocache_headers();header('X-Robots-Tag: noindex, nofollow');
 if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);header('X-LiteSpeed-Cache-Control: no-cache'); // never cached by the speed plugins
 $self=add_query_arg(['lux_pay_return'=>rawurlencode($d['reference']),'vk'=>$key],home_url('/'));
 if($pay){
  // A previous attempt may already be paid or still processing: ask Flitt before offering a new charge.
  foreach(array_reverse(luxf_attempts($id),true) as $o=>$a){if(in_array($a['status']??'',['created','processing'],true)){$st=luxf_request('/status/order_id',['order_id'=>$o]);if(luxf_verified($st))luxf_apply($id,$st,'pay-check');
   // Flitt's "processing" means the order is still open (not paid yet, or a card was declined and another one can be tried).
   // The guest goes back to that same order, so one booking never has two open payments.
   if(in_array($st['order_status']??'',['created','processing'],true)&&!empty($a['url'])&&strtotime((string)$a['created'])>current_time('timestamp')-3300&&(int)$a['amount']===luxf_due_now($id)){wp_redirect($a['url']);exit;}
   if(($st['order_status']??'')==='processing'&&empty($st['response_description']))luxf_page($L,$T['processing_title'],$T['processing_text'],[]);}break;}
  $due=luxf_due_now($id);if($due<=0){wp_safe_redirect($self,303);exit;} // already paid: show the confirmation, never a second charge
  // The dates are checked again right before the payment and held while the guest pays.
  if(get_post_meta($id,'_lux_status',true)!=='confirmed'){lux_availability_lock();$clash=lux_booking_conflicts($id);if($clash){lux_availability_unlock();luxf_page($L,$T['taken_title'],$T['taken_text'],[]);}update_post_meta($id,'_lux_status','awaiting_payment');lux_hold($id);lux_availability_unlock();}
  $s=luxf_settings();if(!$s['merchant_id']||!$s['secret']||$s['mode']==='off'){luxf_page($L,$T['fail_title'],$T['error'],[]);}
  $order=$d['reference'].'-'.time();
  $r=luxf_request('/checkout/url',['order_id'=>$order,'order_desc'=>sprintf($T['desc'],$d['reference']),'amount'=>$due,'currency'=>'GEL','lang'=>$L,'sender_email'=>$d['email'],'lifetime'=>3600,
   'response_url'=>$self,'server_callback_url'=>rest_url('luxury/v1/flitt-callback')]);
  if(($r['response_status']??'')!=='success'||empty($r['checkout_url'])){update_post_meta($id,'_lux_pay_error',sanitize_text_field(($r['error_code']??'').' '.($r['error_message']??'')));luxf_page($L,$T['fail_title'],$T['error'],[['url'=>luxf_pay_url($id),'label'=>$T['retry']]]);}
  $attempts=luxf_attempts($id);$attempts[$order]=['amount'=>$due,'status'=>'created','created'=>current_time('mysql'),'mode'=>$s['mode'],'url'=>esc_url_raw($r['checkout_url'])];update_post_meta($id,'_lux_pay_attempts',$attempts);add_post_meta($id,'_lux_pay_order',$order);
  wp_redirect($r['checkout_url']);exit;
 }
 // Return from Flitt. The browser comes back with a POST (the signed result): it is recorded and answered with a 303 redirect
 // to this same address, so the confirmation is an ordinary GET page. Back (e.g. after the PDF) and Refresh show the saved
 // state again — no "resubmit the form?", no ERR_CACHE_MISS, and never a new payment.
 if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){$data=wp_unslash($_POST);if(luxf_verified($data))luxf_apply($id,$data,'return');wp_safe_redirect($self,303);exit;}
 $paid=function()use($id,$d){$b=luxv_balance($id);return $b['paid']>0&&$b['paid']>=(int)luxv_required($id,$d);};
 $attempts=luxf_attempts($id);$last=array_key_last($attempts);
 // Nothing recorded yet (the server callback may still be on its way): ask Flitt once about the latest order.
 if(!$paid()&&$last&&in_array($attempts[$last]['status']??'',['created','processing'],true)){$st=luxf_request('/status/order_id',['order_id'=>$last]);if(luxf_verified($st))luxf_apply($id,$st,'return-check');$attempts=luxf_attempts($id);}
 if($paid()){
  if(luxv_versions($id)&&get_post_meta($id,'_lux_status',true)==='confirmed')luxf_confirm_page($id,$L);
  // The voucher is being issued by the parallel callback: refresh shortly. Otherwise staff must finish it (missing details, date conflict).
  if(!luxv_missing($id)&&!get_post_meta($id,'_lux_voucher_error',true)&&(int)($_GET['w']??0)<8)luxf_page($L,$T['c_prep_title'],$T['c_prep'],[],add_query_arg('w',(int)($_GET['w']??0)+1,$self));
  luxf_page($L,$T['ok_title'],$T['ok_pending'],[]);}
 $status=$last?(string)($attempts[$last]['status']??''):'';
 // "processing" with a bank answer = the card was declined and nothing was taken; without one the bank is still deciding.
 if($status==='processing'&&empty($attempts[$last]['message']))luxf_page($L,$T['processing_title'],$T['processing_text'],[]);
 luxf_page($L,$T['fail_title'],$T['fail_text'],[['url'=>luxf_pay_url($id),'label'=>$T['retry']]]);
},5);
// Shared look of the guest pages after payment: the site's colours, serif headings, a full-width main button on phones.
function luxf_head($L,$title,$refresh=''){
 $ka=$L==='ka'?"'Noto Sans Georgian',":'';$kaS=$L==='ka'?"'Noto Serif Georgian',":'';
 return '<!doctype html><html lang="'.esc_attr($L).'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="google" content="notranslate">'.($refresh?'<meta http-equiv="refresh" content="3;url='.esc_url($refresh).'">':'').'<title>'.esc_html($title).'</title><style>'.(function_exists('luxv_font_faces')?luxv_font_faces(plugins_url('assets/fonts/',__FILE__)):'')
 .'*{box-sizing:border-box}body{margin:0;background:#f8f7f3;color:#171717;font-family:'.$ka.'Calibri,Carlito,"Segoe UI",Helvetica,Arial,sans-serif;font-size:16px;line-height:1.5;padding:32px 12px}.box{max-width:600px;margin:0 auto;background:#fff;border:1px solid #e4e4dc;padding:36px 36px 30px}'
 .'.brand{display:flex;align-items:center;gap:12px;font-size:12px;letter-spacing:.08em}.brand img{width:56px;height:auto}h1{font-family:'.$kaS.'Georgia,"Noto Serif",serif;font-weight:normal;font-size:32px;line-height:1.15;margin:22px 0 8px}h2{font-family:'.$kaS.'Georgia,"Noto Serif",serif;font-weight:normal;font-size:20px;margin:26px 0 6px}'
 .'.gold{color:#92754B;font-weight:bold;font-size:13px;letter-spacing:.04em;margin:0}.lead{font-size:17px;color:#2f352b;margin:0 0 6px}p{margin:0 0 10px;color:#474e42}'
 .'table{width:100%;border-collapse:collapse}td{padding:10px 0;border-bottom:1px solid #e4e4dc;vertical-align:top}td.k{color:#5b6155;padding-right:14px}td.r{text-align:right}.amounts td{font-size:17px}.amounts td.r{font-family:'.$kaS.'Georgia,"Noto Serif",serif;white-space:nowrap}.full td{color:#2e6b34;font-weight:bold;border-bottom:0}.nw{white-space:nowrap}'
 .'.mail{margin:20px 0 4px;padding:12px 14px;background:#f4f2ea;color:#2f352b}.acts{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0 4px}.btn{display:inline-block;text-decoration:none;padding:14px 22px;font-size:16px;text-align:center;border:1px solid #050505}.btn.primary{background:#050505;color:#fff}.btn.second{background:#fff;color:#171717}'
 .'.contacts a{color:#171717}.home{display:inline-block;margin-top:22px;color:#171717}.c{font-size:13px;color:#666;margin-top:22px}'
 .'@media(max-width:520px){body{padding:12px 8px}.box{padding:24px 16px 22px}h1{font-size:27px}.acts .btn{flex:1 1 100%}.contacts td{display:block;padding:0;border:0;text-align:left}.contacts td.k{padding-top:10px;font-size:13px}.contacts tr td.r{padding-bottom:10px;border-bottom:1px solid #e4e4dc}}'
 .'</style></head><body class="notranslate" translate="no"><main class="box"><div class="brand"><img src="'.esc_url(plugins_url('assets/voucher-logo.jpg',__FILE__)).'" alt="Luxury Apart Hotel Group" width="56"><span>LUXURY APART HOTEL GROUP</span></div>';
}
function luxf_contacts($L){
 return '<h2>'.esc_html(luxv_t($L,'res_dept')).'</h2><table class="contacts"><tr><td class="k">WhatsApp</td><td class="r"><a class="nw" href="https://wa.me/995557528285">+995 557 528 285</a></td></tr><tr><td class="k">'.esc_html(luxv_t($L,'phone')).'</td><td class="r"><a class="nw" href="tel:+995555907333">+995 555 907 333</a></td></tr><tr><td class="k">'.esc_html(luxv_t($L,'email')).'</td><td class="r"><a href="mailto:reservations@luxuryaparthotel.ge">reservations@luxuryaparthotel.ge</a></td></tr></table>';
}
// "Your booking is confirmed": shown only after the payment is recorded and the voucher issued. Everything comes from the saved booking.
function luxf_confirm_page($id,$L){
 $T=luxf_texts($L);$t=fn($k)=>luxv_t($L,$k);$e='esc_html';$d=get_post_meta($id,'_lux_request',true);$bal=luxv_balance($id);$cur=luxv_current($id);$s=$cur['snapshot'];$m=fn($x)=>$e(luxv_money((int)$x,$L));
 $sent=false;foreach((array)get_post_meta($id,'_lux_voucher_log',true) as $l)if(is_array($l)&&($l['who']??'')==='guest'&&($l['result']??'')==='sent')$sent=true;
 $vurl=lux_voucher_url($id);$row=fn($k,$v,$cls='')=>'<tr'.($cls?' class="'.$cls.'"':'').'><td class="k">'.$e($k).'</td><td class="r">'.$v.'</td></tr>';
 $aps=implode(', ',array_map(fn($a)=>$a['title'].' · '.$t('city_'.$a['city']),$s['apartments']));
 $guests=luxv_plural($s['adults'],'pl_adults',$L).($s['children']?' · '.luxv_plural($s['children'],'pl_children',$L):'').' · '.luxv_plural($s['nights'],'pl_nights',$L);
 $h=luxf_head($L,$T['c_title']).'<h1>'.$e($T['c_title']).'</h1><p class="lead">'.$e($T['c_thanks']).'</p>';
 $h.='<table>'.$row($t('booking_no'),'<strong class="nw">'.$e($d['reference']).'</strong>').$row($T['c_apartment'],$e($aps)).$row($t('checkin'),$e(luxv_date($s['checkin'],$L).', '.sprintf($t('from_time'),'14:00'))).$row($t('checkout'),$e(luxv_date($s['checkout'],$L).', '.sprintf($t('until_time'),'11:00'))).$row($t('guests_nights'),$e($guests)).'</table>';
 $h.='<h2>'.$e($t('pay_h')).'</h2><table class="amounts">'.$row($t('a_total'),$m($bal['total'])).$row($t('a_paid'),$m($bal['paid']));
 $h.=(int)$bal['balance']>0?$row($t('a_balance'),$m($bal['balance'])).'</table><p style="margin-top:8px">'.$e($T['c_balance_note']).'</p>':'<tr class="full"><td colspan="2">✓ '.$e($t('paid_full')).'</td></tr></table>';
 $h.='<p class="mail">'.$e(sprintf($sent?$T['c_sent']:$T['c_later'],$d['email'])).'</p>';
 $h.='<div class="acts"><a class="btn primary" href="'.esc_url(add_query_arg('pdf','1',$vurl)).'">'.$e($t('download_pdf')).'</a><a class="btn second" href="'.esc_url($vurl).'">'.$e($T['c_details']).'</a></div>';
 $h.='<p class="c" style="margin-top:26px">'.$e($T['c_help']).'</p>'.luxf_contacts($L).'<a class="home" href="'.esc_url(home_url('/')).'">'.$e($t('home')).'</a></main></body></html>';
 echo $h;exit;
}
function luxf_page($L,$title,$text,$buttons,$refresh=''){
 echo luxf_head($L,$title,$refresh).'<h1>'.esc_html($title).'</h1><p class="lead">'.esc_html($text).'</p>';
 if($buttons){echo '<div class="acts">';foreach($buttons as $b)echo '<a class="btn primary" href="'.esc_url($b['url']).'">'.esc_html($b['label']).'</a>';echo '</div>';}
 echo luxf_contacts($L).'<a class="home" href="'.esc_url(home_url('/')).'">'.esc_html(luxv_t($L,'home')).'</a></main></body></html>';exit;
}

// Host-to-host result from Flitt (JSON POST). Answered with 200 once processed, so Flitt stops retrying.
add_action('rest_api_init',function(){register_rest_route('luxury/v1','/flitt-callback',['methods'=>'POST','permission_callback'=>'__return_true','callback'=>function($request){
 $data=$request->get_json_params();if(!is_array($data)||!$data)$data=$request->get_body_params();
 if(!luxf_verified($data))return new WP_REST_Response(['ok'=>false,'error'=>'bad signature'],400);
 $order=sanitize_text_field((string)($data['order_id']??''));$p=get_posts(['post_type'=>'lux_booking','post_status'=>'private','numberposts'=>1,'meta_key'=>'_lux_pay_order','meta_value'=>$order]);
 if(!$p)return new WP_REST_Response(['ok'=>true,'note'=>'unknown order'],200);
 return new WP_REST_Response(['ok'=>true,'result'=>luxf_apply($p[0]->ID,$data,'callback')],200);
}]);});

// Settings: Luxury → Online payment.
add_action('admin_menu',function(){add_submenu_page('luxury-setup','Online payment (Flitt)','Online payment','manage_options','luxury-payment','luxf_settings_page');});
add_action('admin_post_luxf_save',function(){
 if(!current_user_can('manage_options'))wp_die('No access');check_admin_referer('luxf_save');$old=luxf_settings();$in=wp_unslash($_POST);
 $secret=trim((string)($in['secret']??''));
 update_option('lux_flitt',['mode'=>in_array($in['mode']??'',['off','test','live'],true)?$in['mode']:'off','merchant_id'=>preg_replace('/\D/','',(string)($in['merchant_id']??'')),'secret'=>$secret!==''?$secret:$old['secret'],'auto_confirm'=>empty($in['auto_confirm'])?0:1],false);
 wp_safe_redirect(admin_url('admin.php?page=luxury-payment&updated=1'));exit;
});
function luxf_settings_page(){
 if(!current_user_can('manage_options'))return;$s=luxf_settings();?>
 <div class="wrap"><h1>Online payment (Flitt)</h1><?php if(isset($_GET['updated']))echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';?>
 <p>After the booking form the guest pays the chosen prepayment (30% or 100%) on the Flitt payment page. When Flitt confirms the payment, it is recorded in the booking, the booking is confirmed and the PDF confirmation is emailed to the guest and to Reservations.</p>
 <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="luxf_save"><?php wp_nonce_field('luxf_save');?>
 <table class="form-table" role="presentation">
 <tr><th scope="row">Mode</th><td><select name="mode"><option value="off" <?php selected($s['mode'],'off');?>>Off — booking requests only</option><option value="live" <?php selected($s['mode'],'live');?>>On — every guest pays online</option><option value="test" <?php selected($s['mode'],'test');?>>Preview — only logged-in administrators</option></select><p class="description">On: after the booking form every guest goes to the Flitt payment page; while your Flitt shop is in its test environment the page shows “Test mode” and no real money is taken. Preview: only you (logged in) see the payment flow, guests send requests. Test cards: 4444 5555 1111 6666 (approved), 4444 1111 5555 6666 (declined), any expiry date and CVV.</p></td></tr>
 <tr><th scope="row">Merchant ID</th><td><input name="merchant_id" value="<?php echo esc_attr($s['merchant_id']);?>" class="regular-text" placeholder="e.g. 1549901"><p class="description">portal.flitt.com → Merchant → Technical settings. Flitt's public test merchant: 1549901 with key <code>test</code>.</p></td></tr>
 <tr><th scope="row">Payment secret key</th><td><input type="password" name="secret" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo $s['secret']?'saved — leave empty to keep':'';?>"></td></tr>
 <tr><th scope="row">After payment</th><td><label><input type="checkbox" name="auto_confirm" value="1" <?php checked($s['auto_confirm'],1);?>> Confirm the booking automatically and email the PDF confirmation</label></td></tr>
 <tr><th scope="row">Callback URL</th><td><code><?php echo esc_html(rest_url('luxury/v1/flitt-callback'));?></code><p class="description">Sent to Flitt with every payment; nothing to set in the portal. Flitt calls it from 54.154.216.60 and 3.75.125.89 — these must not be blocked by a firewall.</p></td></tr>
 </table><?php submit_button();?></form></div><?php
}

add_action('admin_notices',function(){$k='lux_conflict_'.get_current_user_id();$c=get_transient($k);if(!$c)return;delete_transient($k);echo '<div class="notice notice-error"><p><strong>Not confirmed:</strong> the dates overlap '.esc_html(implode('; ',(array)$c)).'. Resolve the overlap first (Luxury Setup → Availability).</p></div>';});
