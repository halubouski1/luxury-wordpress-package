(()=>{'use strict';
const config=window.LUX_LANGS;if(!config)return;
const widget=document.getElementById('lux-lang');if(!widget)return;
const toggle=widget.querySelector('.lux-lang-toggle'),menu=widget.querySelector('.lux-lang-menu'),current=widget.querySelector('[data-lux-current]');
const langs=config.languages;

// Read the Google Translate cookie (googtrans=/en/ru) to know the active language.
function activeCode(){
 const m=document.cookie.match(/(?:^|;\s*)googtrans=([^;]+)/);
 if(m){const g=decodeURIComponent(m[1]).split('/').pop();for(const c in langs)if(langs[c].google===g)return c;}
 return config.default;
}
function setCookie(google){
 const val=google===config.default?'':('/'+config.default+'/'+google);
 // Google also writes googtrans on parent domains (e.g. .luxuryaparthotel.ge for www.); a stale copy there
 // brings the old language back after reload. Clear and set it on the host and every parent level.
 const parts=location.hostname.split('.'),domains=[''];
 for(let i=0;i<parts.length-1;i++){const d=parts.slice(i).join('.');domains.push('; domain='+d,'; domain=.'+d);}
 for(const d of domains)document.cookie='googtrans=;expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/'+d;
 if(val)for(const d of domains)document.cookie='googtrans='+val+'; path=/'+d;
}
function applyDir(code){
 const rtl=langs[code]&&langs[code].rtl;
 document.documentElement.setAttribute('dir',rtl?'rtl':'ltr');
 document.documentElement.classList.toggle('lux-rtl',!!rtl);
}
function label(code){return (langs[code]||langs[config.default]).label;}

function paint(code){
 current.textContent=label(code);
 const flag=widget.querySelector('[data-lux-flag]'),src=(langs[code]||langs[config.default]).flag;
 if(flag&&src)flag.src=src;
 widget.querySelectorAll('[data-lang]').forEach(li=>li.setAttribute('aria-selected',String(li.dataset.lang===code)));
}

// Pages with separate language URLs declare <link rel="alternate" hreflang>; follow those instead of machine translation.
const alts={};document.querySelectorAll('link[rel="alternate"][hreflang]').forEach(l=>{alts[l.hreflang]=l.href;});
const bare=u=>u.split('#')[0].split('?')[0].replace(/\/$/,'');
function altFor(code){return alts[code]||alts['x-default']||'';}

function choose(code){
 if(!langs[code])return;
 setCookie(langs[code].google);
 applyDir(code);paint(code);
 const target=altFor(code);
 if(target&&bare(target)!==bare(location.href)){location.href=target;return;}
 // Re-run Google's translation for the new cookie value.
 location.reload();
}

toggle.addEventListener('click',()=>{const open=!menu.hidden;menu.hidden=open;toggle.setAttribute('aria-expanded',String(!open));});
document.addEventListener('click',e=>{if(!widget.contains(e.target)){menu.hidden=true;toggle.setAttribute('aria-expanded','false');}});
menu.addEventListener('click',e=>{const li=e.target.closest('[data-lang]');if(li)choose(li.dataset.lang);});

const code=activeCode();
// Arriving on one language version while another language is active: open the matching version.
{const want=altFor(code);if(want&&bare(want)!==bare(location.href)){location.replace(want);return;}}
paint(code);applyDir(code);widget.hidden=false;
// Lets CSS adapt to the chosen language (e.g. long Georgian words in the mobile menu).
document.documentElement.dataset.luxLang=code;

// Move the switcher into the header next to "Book your stay"; keep it there if the header re-renders.
function dock(){
 const actions=document.querySelector('.header-actions');
 // Move the same node (keeps its listeners and any open menu); never force-close here.
 if(actions){if(widget.parentElement!==actions){widget.classList.add('lux-lang-inheader');actions.insertBefore(widget,actions.firstChild);}}
 else if(widget.parentElement!==document.body){widget.classList.remove('lux-lang-inheader');document.body.appendChild(widget);}
}
// Place names and addresses must never go through machine translation ("Orbi City, Georgia" became a US state).
// Elements whose whole text matches get the approved spelling and are excluded from Google.
const PLACES=[
 [/^Batumi$/,{ru:'Батуми',ka:'ბათუმი'}],
 [/^BATUMI$/,{ru:'БАТУМИ',ka:'ბათუმი'}],
 [/^New Gudauri$/,{ru:'Новый Гудаури',ka:'ახალი გუდაური'}],
 [/^NEW GUDAURI$/,{ru:'НОВЫЙ ГУДАУРИ',ka:'ახალი გუდაური'}],
 [/^Gudauri$/,{ru:'Гудаури',ka:'გუდაური'}],
 [/^Tbilisi$/,{ru:'Тбилиси',ka:'თბილისი'}],
 [/^Zanzibar$/,{ru:'Занзибар',ka:'ზანზიბარი'}],
 [/^BATUMI, GEORGIA$/,{ru:'БАТУМИ, ГРУЗИЯ',ka:'ბათუმი, საქართველო'}],
 [/^NEW GUDAURI, GEORGIA$/,{ru:'НОВЫЙ ГУДАУРИ, ГРУЗИЯ',ka:'ახალი გუდაური, საქართველო'}],
 [/^TBILISI, GEORGIA$/,{ru:'ТБИЛИСИ, ГРУЗИЯ',ka:'თბილისი, საქართველო'}],
 [/^Batumi · Orbi City$/,{ru:'Батуми · Orbi City',ka:'ბათუმი · ორბი სითი'}],
 [/^New Gudauri · Four Seasons$/,{ru:'Новый Гудаури · Four Seasons',ka:'ახალი გუდაური · Four Seasons'}],
 [/^Sherif Khimshiashvilis? 7d\s*Orbi City, Batumi, Georgia$/,{ru:'ул. Шерифа Химшиашвили, 7d<br>Orbi City, Батуми, Грузия',ka:'შერიფ ხიმშიაშვილის ქ. 7d<br>ორბი სითი, ბათუმი, საქართველო'},true],
 // About us: Google renders "water" literally; the meaning is the sea.
 [/^A life by the water\.$/,{ru:'Жизнь у моря.',ka:'ცხოვრება ზღვასთან.'}],
 [/^Georgia$/,{ru:'Грузия',ka:'საქართველო'}],
 // Company name stays as registered in every language.
 [/^© \d{4} LLC LUXURY APART HOTEL GROUP$/,{}],
 [/^Luxury Apart Hotel( Group)?$/i,{}],
 [/^Redco New Gudauri\s*Gudauri 4702, Georgia$/,{ru:'Redco New Gudauri<br>Гудаури 4702, Грузия',ka:'Redco New Gudauri<br>გუდაური 4702, საქართველო'},true],
];
function places(){
 document.querySelectorAll('h1,h2,h3,h4,p,address,span,a,li,strong,em').forEach(el=>{
  if(el.dataset.luxPlace||el.querySelector('*:not(br)'))return;
  const txt=el.textContent.replace(/\s+/g,' ').trim();
  for(const [re,map,html] of PLACES){
   if(!re.test(txt))continue;
   el.dataset.luxPlace='1';el.classList.add('notranslate');el.setAttribute('translate','no');
   const t=map[code];
   if(t){if(html)el.innerHTML=t;else el.textContent=t;}
   break;
  }
 });
}

// Georgian: Google mistranslates place names inside sentences (Batumi → "garden", Orbi City → "ორბი სიტი").
// Before it translates, put the correct spelling in an untranslated span; the rest of the sentence is translated as usual.
const KA_NAMES={'Four Seasons':'Four Seasons','FOUR SEASONS':'FOUR SEASONS','New Gudauri':'ახალი გუდაური','NEW GUDAURI':'ახალი გუდაური','Orbi City':'ორბი სითი','ORBI CITY':'ორბი სითი','Batumi':'ბათუმი','BATUMI':'ბათუმი','Gudauri':'გუდაური','GUDAURI':'გუდაური','Tbilisi':'თბილისი','TBILISI':'თბილისი'};
const KA_RE=/\b(Four Seasons|FOUR SEASONS|New Gudauri|NEW GUDAURI|Orbi City|ORBI CITY|Batumi|BATUMI|Gudauri|GUDAURI|Tbilisi|TBILISI)\b/;
function kaNames(){
 if(code!=='ka'||!document.body)return;
 const nodes=[],walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(n){
  if(!KA_RE.test(n.nodeValue))return NodeFilter.FILTER_REJECT;
  const p=n.parentElement;
  return !p||p.closest('script,style,textarea,input,.notranslate,[translate="no"],#lux-lang')?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT;
 }});
 while(walker.nextNode())nodes.push(walker.currentNode);
 nodes.forEach(n=>{
  const frag=document.createDocumentFragment();
  const parts=n.nodeValue.split(new RegExp(KA_RE.source,'g'));
  parts.forEach((part,i)=>{
   if(i%2){
    // Google trims the text around an untranslated span, so keep the neighbouring spaces inside it.
    const pre=/\s$/.test(parts[i-1]||'')?' ':'',post=/^\s/.test(parts[i+1]||'')?' ':'';
    const s=document.createElement('span');s.className='notranslate lux-place-name';s.setAttribute('translate','no');s.textContent=pre+KA_NAMES[part]+post;frag.appendChild(s);
   }
   else if(part)frag.appendChild(document.createTextNode(part));
  });
  n.parentNode.replaceChild(frag,n);
 });
}

// Client-approved copy: elements with data-lux-i18n='{"ru":"…"}' show that text and are skipped by Google.
// Email addresses and phone numbers are never translated ("concierge@" became "კონსიერჟი@").
function contacts(){
 document.querySelectorAll('a[href^="mailto:"],a[href^="tel:"]').forEach(a=>{if(!a.classList.contains('notranslate')){a.classList.add('notranslate');a.setAttribute('translate','no');}});
 if(!document.body)return;
 const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode(n){return /\S+@\S+\.\w/.test(n.nodeValue)&&n.parentElement&&!n.parentElement.closest('.notranslate,script,style,textarea')?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;}});
 const els=new Set();while(w.nextNode())els.add(w.currentNode.parentElement);
 els.forEach(el=>{el.classList.add('notranslate');el.setAttribute('translate','no');});
}

function manual(){
 contacts();places();kaNames();
 document.querySelectorAll('[data-lux-i18n]').forEach(el=>{
  let map;try{map=JSON.parse(el.dataset.luxI18n);}catch(e){return;}
  const t=map[code];
  if(t){if(el.textContent!==t)el.textContent=t;el.classList.add('notranslate');el.setAttribute('translate','no');}
 });
 // Links to a separate language version (e.g. RU article) when that language is active.
 document.querySelectorAll('[data-lux-hrefs]').forEach(el=>{
  let map;try{map=JSON.parse(el.dataset.luxHrefs);}catch(e){return;}
  if(map[code]&&el.getAttribute('href')!==map[code])el.setAttribute('href',map[code]);
 });
}
dock();manual();
const host=document.getElementById('luxury-app')||document.body;
let queued=false;
new MutationObserver(()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;dock();manual();});}).observe(host,{childList:true,subtree:true});
})();
