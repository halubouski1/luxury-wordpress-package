<?php
if(!defined('ABSPATH'))exit;
// Free website translation via Google's Website Translator widget (the same engine GTranslate's free tier uses).
// A custom language selector with flags drives the hidden Google widget; English is the site's original language.
// Prices and payment stay in GEL — only the interface text is translated. A WhatsApp button sits on the opposite side.

function lux_languages(){
 // code => [English label, Google Translate code, rtl, flag file]
 return [
  'en'=>['English','en',false,'en'],
  'ka'=>['Georgian','ka',false,'ka'],
  'ru'=>['Russian','ru',false,'ru'],
  'he'=>['Hebrew','iw',true,'he'],
  'ar'=>['Arabic','ar',true,'ar'],
  'tr'=>['Turkish','tr',false,'tr'],
  'de'=>['German','de',false,'de'],
  'fr'=>['French','fr',false,'fr'],
  'it'=>['Italian','it',false,'it'],
 ];
}
// WhatsApp contact number (digits only for the wa.me link).
function lux_whatsapp_number(){return apply_filters('lux_whatsapp_number','995557528285');}

add_action('wp_enqueue_scripts',function(){
 wp_enqueue_style('lux-translate',plugins_url('assets/translate.css',__FILE__),[],filemtime(__DIR__.'/assets/translate.css'));
 wp_enqueue_script('lux-translate',plugins_url('assets/translate.js',__FILE__),[],filemtime(__DIR__.'/assets/translate.js'),['in_footer'=>true]);
 $base=plugins_url('assets/flags/',__FILE__);$langs=[];
 foreach(lux_languages() as $code=>$l)$langs[$code]=['label'=>$l[0],'google'=>$l[1],'rtl'=>$l[2],'flag'=>$base.$l[3].'.svg'];
 wp_add_inline_script('lux-translate','window.LUX_LANGS='.wp_json_encode(['languages'=>$langs,'default'=>'en']).';','before');
},60);

add_action('wp_footer',function(){
 $langs=lux_languages();$included=implode(',',array_map(fn($l)=>$l[1],$langs));$base=plugins_url('assets/flags/',__FILE__);
 $wa=lux_whatsapp_number();
 ?>
 <div id="lux-lang" class="lux-lang notranslate" translate="no" hidden>
  <button type="button" class="lux-lang-toggle" aria-haspopup="listbox" aria-expanded="false" aria-label="<?php echo esc_attr('Choose a language');?>">
   <img class="lux-flag" data-lux-flag src="<?php echo esc_url($base.'en.svg');?>" alt="" width="24" height="18">
   <span class="lux-lang-current" data-lux-current>English</span>
   <span class="lux-lang-caret" aria-hidden="true">▾</span>
  </button>
  <ul class="lux-lang-menu" role="listbox" aria-label="<?php echo esc_attr('Choose a language');?>" hidden>
   <?php foreach($langs as $code=>$l){?><li role="option" data-lang="<?php echo esc_attr($code);?>"<?php echo $l[2]?' dir="rtl"':'';?>><img class="lux-flag" src="<?php echo esc_url($base.$l[3].'.svg');?>" alt="" width="24" height="18" loading="lazy"><span><?php echo esc_html($l[0]);?></span></li><?php }?>
  </ul>
 </div>
 <?php if($wa){?>
 <a class="lux-whatsapp-fab" href="https://wa.me/<?php echo esc_attr($wa);?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr('Chat with us on WhatsApp');?>">
  <svg viewBox="0 0 32 32" width="30" height="30" aria-hidden="true" fill="currentColor"><path d="M16.003 3C9.383 3 4 8.383 4 15.003c0 2.117.553 4.185 1.603 6.007L4 29l8.16-1.57a11.94 11.94 0 0 0 3.84.63h.003C22.62 28.06 28 22.677 28 16.057 28 12.86 26.75 9.86 24.49 7.6A11.9 11.9 0 0 0 16.003 3zm0 2.2a9.76 9.76 0 0 1 6.94 2.86 9.72 9.72 0 0 1 2.857 6.997c0 5.42-4.41 9.83-9.834 9.83a9.8 9.8 0 0 1-3.31-.57l-.237-.084-4.842.93.92-4.72-.155-.244a9.7 9.7 0 0 1-1.49-5.192c0-5.42 4.41-9.83 9.83-9.83zm-4.64 5.03c-.22 0-.577.083-.88.412-.303.33-1.155 1.128-1.155 2.75s1.183 3.19 1.348 3.41c.165.22 2.322 3.71 5.76 5.06 2.855 1.125 3.436.9 4.056.843.62-.055 2-.816 2.28-1.605.28-.79.28-1.466.196-1.606-.083-.14-.303-.22-.633-.385s-1.953-.964-2.256-1.074c-.303-.11-.523-.165-.743.166-.22.33-.852 1.073-1.045 1.293-.193.22-.385.248-.715.083s-1.393-.513-2.653-1.637c-.98-.875-1.642-1.955-1.835-2.285-.193-.33-.02-.508.145-.673.148-.148.33-.385.495-.578.165-.193.22-.33.33-.55.11-.22.055-.412-.028-.578-.083-.165-.727-1.797-1.02-2.457-.24-.54-.492-.552-.715-.56-.185-.008-.398-.01-.61-.01z"/></svg>
 </a>
 <?php }?>
 <div id="google_translate_element" aria-hidden="true"></div>
 <script>
  window.luxGoogleTranslateInit=function(){new google.translate.TranslateElement({pageLanguage:'en',includedLanguages:<?php echo wp_json_encode($included);?>,autoDisplay:false},'google_translate_element');};
 </script>
 <script src="https://translate.google.com/translate_a/element.js?cb=luxGoogleTranslateInit" defer></script>
 <?php
});
