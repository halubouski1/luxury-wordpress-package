(()=>{'use strict';
const config=window.LUX_LANGS;if(!config)return;
const widget=document.getElementById('lux-lang');if(!widget)return;
const toggle=widget.querySelector('.lux-lang-toggle'),menu=widget.querySelector('.lux-lang-menu'),current=widget.querySelector('[data-lux-current]');
const langs=config.languages;

// Read the Google Translate cookie (googtrans=/en/ru) to know the active language.
function activeCode(){
 const m=document.cookie.match(/(?:^|;\s*)googtrans=([^;]+)/);
 if(m){const g=decodeURIComponent(m[1]).split('/').pop();for(const c in langs)if(langs[c].google===g)return c;}
 return config.default;
}
function setCookie(google){
 const val=google===config.default?'':('/'+config.default+'/'+google);
 const host=location.hostname;
 // Clear then set across host variants so Google picks it up.
 for(const d of ['', '; domain='+host, '; domain=.'+host]){
  document.cookie='googtrans=;expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/'+d;
 }
 if(val){document.cookie='googtrans='+val+'; path=/';document.cookie='googtrans='+val+'; path=/; domain='+host;}
}
function applyDir(code){
 const rtl=langs[code]&&langs[code].rtl;
 document.documentElement.setAttribute('dir',rtl?'rtl':'ltr');
 document.documentElement.classList.toggle('lux-rtl',!!rtl);
}
function label(code){return (langs[code]||langs[config.default]).label;}

function paint(code){
 current.textContent=label(code);
 const flag=widget.querySelector('[data-lux-flag]'),src=(langs[code]||langs[config.default]).flag;
 if(flag&&src)flag.src=src;
 widget.querySelectorAll('[data-lang]').forEach(li=>li.setAttribute('aria-selected',String(li.dataset.lang===code)));
}

function choose(code){
 if(!langs[code])return;
 setCookie(langs[code].google);
 applyDir(code);paint(code);
 // Re-run Google's translation for the new cookie value.
 location.reload();
}

toggle.addEventListener('click',()=>{const open=!menu.hidden;menu.hidden=open;toggle.setAttribute('aria-expanded',String(!open));});
document.addEventListener('click',e=>{if(!widget.contains(e.target)){menu.hidden=true;toggle.setAttribute('aria-expanded','false');}});
menu.addEventListener('click',e=>{const li=e.target.closest('[data-lang]');if(li)choose(li.dataset.lang);});

const code=activeCode();paint(code);applyDir(code);widget.hidden=false;

// Move the switcher into the header next to "Book your stay"; keep it there if the header re-renders.
function dock(){
 const actions=document.querySelector('.header-actions');
 if(actions&&widget.parentElement!==actions){actions.insertBefore(widget,actions.firstChild);widget.classList.add('lux-lang-inheader');menu.hidden=true;toggle.setAttribute('aria-expanded','false');}
 if(!actions&&widget.parentElement!==document.body){document.body.appendChild(widget);widget.classList.remove('lux-lang-inheader');}
}
dock();
const host=document.getElementById('luxury-app')||document.body;
new MutationObserver(()=>dock()).observe(host,{childList:true,subtree:true});
})();
