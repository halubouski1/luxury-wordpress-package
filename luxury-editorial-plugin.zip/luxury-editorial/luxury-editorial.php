<?php
/**
 * Plugin Name: Luxury Editorial
 * Description: Guides, Experiences, apartments, group booking requests and starter content for Luxury Apart Hotel. Content remains available when themes change.
 * Version: 1.1.0
 * Requires at least: 6.6
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 * Text Domain: luxury-editorial
 */
if (!defined('ABSPATH')) exit;
function lux_register_content() {
 foreach (['lux_guide'=>['Guides','Guide','guides-insights','dashicons-book-alt'], 'lux_experience'=>['Experiences','Experience','experiences','dashicons-location-alt']] as $type=>$v) {
  register_post_type($type, ['labels'=>['name'=>$v[0], 'singular_name'=>$v[1], 'add_new_item'=>'Add new '.$v[1], 'edit_item'=>'Edit '.$v[1], 'all_items'=>'All '.$v[0]], 'public'=>true, 'show_in_rest'=>true, 'menu_icon'=>$v[3], 'has_archive'=>false, 'rewrite'=>['slug'=>$v[2], 'with_front'=>false], 'supports'=>['title','editor','excerpt','thumbnail','revisions','page-attributes'], 'taxonomies'=>[$type==='lux_guide'?'lux_guide_group':'lux_exp_group']]);
 }
 register_taxonomy('lux_guide_group',['lux_guide'],['label'=>'Guide sections','public'=>true,'show_in_rest'=>true,'hierarchical'=>true,'rewrite'=>false,'show_admin_column'=>true]);
 register_taxonomy('lux_exp_group',['lux_experience'],['label'=>'Experience collections','public'=>true,'show_in_rest'=>true,'hierarchical'=>true,'rewrite'=>false,'show_admin_column'=>true]);
}
add_action('init','lux_register_content');
function lux_default_terms(){
 $terms=['lux_exp_group'=>['georgia-tours'=>'Georgia Tours','zanzibar'=>'Zanzibar Travel Experiences','concierge-service'=>'Concierge Service'], 'lux_guide_group'=>['local-knowledge'=>'Local knowledge','behind-the-stay'=>'Behind the stay','batumi'=>'Batumi Guide','gudauri'=>'Gudauri Guide','more-destinations'=>'More Destinations','our-hospitality'=>'Our Hospitality','property-investment'=>'Property & Investment Guide']];
 foreach($terms as $taxonomy=>$items)foreach($items as $slug=>$name)if(!term_exists($slug,$taxonomy))wp_insert_term($name,$taxonomy,['slug'=>$slug]);
}
register_activation_hook(__FILE__,function(){lux_register_content();lux_default_terms();flush_rewrite_rules();});
// Plugin updates skip activation: make sure newly added sections (e.g. Property & Investment Guide) exist.
add_action('admin_init','lux_default_terms');
register_deactivation_hook(__FILE__,function(){flush_rewrite_rules();});
add_action('after_setup_theme',function(){add_theme_support('post-thumbnails');});
add_action('wp_after_insert_post',function($id,$post){
 if(!in_array($post->post_type,['lux_guide','lux_experience'],true)||wp_is_post_revision($id))return;
 $tax=$post->post_type==='lux_guide'?'lux_guide_group':'lux_exp_group';
 if(!wp_get_object_terms($id,$tax,['fields'=>'ids'])){lux_default_terms();$term=get_term_by('slug',$post->post_type==='lux_guide'?'local-knowledge':'georgia-tours',$tax);if($term)wp_set_object_terms($id,[(int)$term->term_id],$tax);}
},10,2);
add_action('add_meta_boxes',function(){foreach(['lux_guide','lux_experience'] as $type)add_meta_box('lux-card-options','Card settings','lux_card_box',$type,'side','default');});
function lux_card_box($post){wp_nonce_field('lux_card_settings','lux_card_nonce');echo '<p>The title and featured image appear on the card. Use <strong>Excerpt</strong> for the short description. Choose a section in the sidebar.</p><p><label for="lux-card-order">Card order (lower comes first)</label><input id="lux-card-order" name="lux_card_order" type="number" min="0" value="'.esc_attr($post->menu_order).'" class="widefat"></p>';if($post->post_type==='lux_guide')echo '<p><label><input type="checkbox" name="lux_featured" value="1" '.checked(get_post_meta($post->ID,'_lux_featured',true),'1',false).'> Featured guide on the Guides landing page</label></p>';}
add_action('save_post',function($id){
 if(!isset($_POST['lux_card_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['lux_card_nonce'])),'lux_card_settings')||!current_user_can('edit_post',$id)||wp_is_post_autosave($id)||wp_is_post_revision($id))return;
 if(!in_array(get_post_type($id),['lux_guide','lux_experience'],true))return;
 if(isset($_POST['lux_card_order'])){global $wpdb;$wpdb->update($wpdb->posts,['menu_order'=>absint($_POST['lux_card_order'])],['ID'=>$id],['%d'],['%d']);clean_post_cache($id);}
 if(get_post_type($id)==='lux_guide')update_post_meta($id,'_lux_featured',isset($_POST['lux_featured'])?'1':'0');
});
add_filter('manage_lux_guide_posts_columns','lux_admin_columns');add_filter('manage_lux_experience_posts_columns','lux_admin_columns');
function lux_admin_columns($cols){$cols['lux_cover']='Cover';$cols['lux_order']='Order';return $cols;}
function lux_admin_column_value($col,$id){if($col==='lux_cover')echo get_the_post_thumbnail($id,[64,48]);if($col==='lux_order')echo (int)get_post_field('menu_order',$id);}
add_action('manage_lux_guide_posts_custom_column','lux_admin_column_value',10,2);add_action('manage_lux_experience_posts_custom_column','lux_admin_column_value',10,2);
add_action('admin_menu',function(){add_menu_page('Luxury setup','Luxury Setup','manage_options','luxury-setup','lux_setup_page','dashicons-admin-home',59);});
function lux_setup_page(){if(!current_user_can('manage_options'))return;?><div class="wrap"><h1>Luxury Apart Hotel Group · Content setup</h1><p>Manage cards in <strong>Guides</strong> and <strong>Experiences</strong>. Edit the title, featured image, excerpt, section and card order. Build articles with headings, paragraphs, photos, galleries and lists in the block editor.</p><p>The theme preserves the design and animation. This plugin stores your content independently of the theme.</p><?php if(isset($_GET['imported']))echo '<div class="notice notice-success"><p>Starter import completed. Existing pages and articles were not overwritten. See the report below.</p></div>'; $report=get_option('lux_import_report',[]);if($report)echo '<pre style="white-space:pre-wrap">'.esc_html(implode("\n",$report)).'</pre>';?><h2>Import starter content</h2><p>Creates only missing pages and demo articles. Imports bundled covers into the Media Library when the Luxury theme is installed. Existing content is kept. Can be run again to finish importing missing covers.</p><form action="<?php echo esc_url(admin_url('admin-post.php'));?>" method="post"><?php wp_nonce_field('lux_import');?><input type="hidden" name="action" value="lux_import"><p><label><input type="checkbox" name="set_front" value="1"> Set the imported Home page as the front page</label></p><?php submit_button('Import missing starter content');?></form><p><a href="<?php echo esc_url(admin_url('edit.php?post_type=lux_guide'));?>">Manage Guides</a> · <a href="<?php echo esc_url(admin_url('edit.php?post_type=lux_experience'));?>">Manage Experiences</a></p></div><?php }
function lux_import_image($name,$alt){
 $existing=get_posts(['post_type'=>'attachment','post_status'=>'inherit','meta_key'=>'_lux_seed_asset','meta_value'=>$name,'numberposts'=>1]);if($existing)return $existing[0]->ID;
 $themes=wp_get_themes();$theme_dir=isset($themes['luxury-apart-hotel'])?$themes['luxury-apart-hotel']->get_stylesheet_directory():'';
 $file=$theme_dir.'/assets/images/'.sanitize_file_name($name).'.webp';if(!$theme_dir||!is_readable($file))return 0;
 require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
 $tmp=wp_tempnam($name);if(!$tmp||!copy($file,$tmp))return 0;
 $id=media_handle_sideload(['name'=>sanitize_file_name($name).'.webp','tmp_name'=>$tmp],0,$alt);if(is_wp_error($id)){if(file_exists($tmp))unlink($tmp);return 0;}update_post_meta($id,'_lux_seed_asset',$name);update_post_meta($id,'_wp_attachment_image_alt',$alt);return $id;
}
function lux_legal_html($raw){
 $title='';$subtitle='';$out='';$list=[];$tbl=[];
 $flush=function()use(&$list,&$out){if($list){$out.='<!-- wp:list -->'."\n".'<ul>';foreach($list as $li)$out.='<li>'.esc_html($li).'</li>';$out.='</ul>'."\n".'<!-- /wp:list -->'."\n";$list=[];}};
 $flushTable=function()use(&$tbl,&$out){if($tbl){$out.='<!-- wp:table -->'."\n".'<figure class="wp-block-table legal-table"><table>';
   $head=array_shift($tbl);$out.='<thead><tr>';foreach($head as $c)$out.='<th>'.esc_html($c).'</th>';$out.='</tr></thead>';
   if($tbl){$out.='<tbody>';foreach($tbl as $r){$out.='<tr>';foreach($r as $c)$out.='<td>'.esc_html($c).'</td>';$out.='</tr>';}$out.='</tbody>';}
   $out.='</table></figure>'."\n".'<!-- /wp:table -->'."\n";$tbl=[];}};
 foreach(preg_split('/\R/u',$raw) as $line){
  $line=trim($line);
  if($line===''){$flush();$flushTable();continue;}
  if(strpos($line,'@title ')===0){$title=trim(substr($line,7));continue;}
  if(strpos($line,'@subtitle ')===0){$subtitle=trim(substr($line,10));continue;}
  // Markdown-style table row: | cell | cell |
  if($line[0]==='|'&&substr($line,-1)==='|'){
   $cells=array_map('trim',explode('|',substr($line,1,-1)));
   $isSep=true;foreach($cells as $c){if($c!==''&&!preg_match('/^:?-+:?$/',$c)){$isSep=false;break;}}
   if($isSep)continue;
   $flush();$tbl[]=$cells;continue;
  }
  $flushTable();
  if(strpos($line,'## ')===0){$flush();$out.='<!-- wp:heading -->'."\n".'<h2 class="wp-block-heading">'.esc_html(trim(substr($line,3))).'</h2>'."\n".'<!-- /wp:heading -->'."\n";continue;}
  $first=mb_substr($line,0,1,'UTF-8');
  if($first==='•'||substr($line,0,2)==='- '){$list[]=trim(preg_replace('/^[\x{2022}\-\s]+/u','',$line));continue;}
  $flush();
  if(preg_match('/^\d+\s+\S/u',$line))$out.='<!-- wp:heading -->'."\n".'<h2 class="wp-block-heading">'.esc_html($line).'</h2>'."\n".'<!-- /wp:heading -->'."\n";
  else $out.='<!-- wp:paragraph -->'."\n".'<p>'.esc_html($line).'</p>'."\n".'<!-- /wp:paragraph -->'."\n";
 }
 $flush();$flushTable();
 $sub=$subtitle?'<!-- wp:paragraph -->'."\n".'<p class="legal-subtitle"><em>'.esc_html($subtitle).'</em></p>'."\n".'<!-- /wp:paragraph -->'."\n":'';
 return [$title,$sub.$out];
}
function lux_import_legal(){
 $report=[];$map=['terms-conditions'=>'terms-conditions','booking-and-payment-terms'=>'booking-and-payment-terms','booking-cancellation-and-refund-policy'=>'booking-cancellation-and-refund-policy','privacy-policy'=>'privacy-policy'];
 foreach($map as $slug=>$base){
  $path=__DIR__.'/legal/'.$base.'.txt';if(!is_readable($path)){$report[]='Legal file missing: '.$base.'.txt';continue;}
  list($title,$html)=lux_legal_html(file_get_contents($path));
  $existing=get_page_by_path($slug,OBJECT,'page');
  if($existing){
   wp_update_post(['ID'=>$existing->ID,'post_title'=>$title,'post_content'=>$html,'post_status'=>'publish']);
   $id=$existing->ID;$report[]='Updated legal page: '.$title;
  }else{
   $id=wp_insert_post(['post_type'=>'page','post_title'=>$title,'post_name'=>$slug,'post_content'=>$html,'post_status'=>'publish'],true);
   if(is_wp_error($id)){$report[]=$id->get_error_message();continue;}
   $report[]='Created legal page: '.$title;
  }
  update_post_meta($id,'_lux_legal_seed','1');
  // Manual per-language overrides: legal/<base>.<lang>.txt rendered verbatim (notranslate) instead of Google.
  foreach(['ru','ka'] as $lang){
   $lp=__DIR__.'/legal/'.$base.'.'.$lang.'.txt';
   if(is_readable($lp)){
    list($lt,$lh)=lux_legal_html(file_get_contents($lp));
    update_post_meta($id,'_lux_legal_title_'.$lang,$lt);
    update_post_meta($id,'_lux_legal_html_'.$lang,$lh);
    $report[]='  + '.$lang.' manual translation ('.$base.')';
   }else{
    delete_post_meta($id,'_lux_legal_title_'.$lang);
    delete_post_meta($id,'_lux_legal_html_'.$lang);
   }
  }
 }
 return $report;
}
function lux_import_thankyou(){
 $report=[];
 $pages=[
  'thank-you-rental'=>['Thank you for your booking','<!-- wp:paragraph --><p>Your booking request has been received.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>We have emailed your booking number and voucher. Our team will confirm availability for your dates and send you a secure payment link for the amount due now. Your voucher arrives by email &mdash; show it on arrival.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Questions? <a href="mailto:reservations@luxuryaparthotel.ge">reservations@luxuryaparthotel.ge</a></p><!-- /wp:paragraph --><!-- wp:paragraph --><p><a href="/apartments/">Back to apartments</a></p><!-- /wp:paragraph -->'],
  'thank-you-owner'=>['Thank you for your enquiry','<!-- wp:paragraph --><p>Thank you for your interest in our property management.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Your email app should have opened with your details &mdash; please send that message, or write to us directly at <a href="mailto:ownerrelations@luxuryaparthotel.ge">ownerrelations@luxuryaparthotel.ge</a>. Our team will get back to you shortly.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p><a href="/">Back to home</a></p><!-- /wp:paragraph -->'],
 ];
 foreach($pages as $slug=>$pc){
  $existing=get_page_by_path($slug,OBJECT,'page');
  if($existing){wp_update_post(['ID'=>$existing->ID,'post_title'=>$pc[0],'post_content'=>$pc[1],'post_status'=>'publish']);$id=$existing->ID;$report[]='Updated page: '.$pc[0];}
  else{$id=wp_insert_post(['post_type'=>'page','post_title'=>$pc[0],'post_name'=>$slug,'post_content'=>$pc[1],'post_status'=>'publish'],true);if(is_wp_error($id)){$report[]=$id->get_error_message();continue;}$report[]='Created page: '.$pc[0];}
  update_post_meta($id,'_lux_thankyou','1');
 }
 return $report;
}
function lux_import_guide_pages(){
 $report=[];$guide=get_page_by_path('guide');
 if($guide)$gid=$guide->ID; else {$gid=wp_insert_post(['post_type'=>'page','post_title'=>'Guide','post_name'=>'guide','post_status'=>'publish'],true);if(is_wp_error($gid))return [$gid->get_error_message()];$report[]='Created page: Guide';}
 wp_update_post(['ID'=>$gid,'post_status'=>'publish','post_parent'=>0]);
 update_post_meta($gid,'_lux_view','guide-home');
 // Destinations are routed via the lux_guide_dest query var, not child pages. Remove any legacy child pages.
 foreach(['batumi','gudauri','more-destinations'] as $slug){$child=get_page_by_path('guide/'.$slug);if($child&&(int)$child->post_parent===$gid){wp_delete_post($child->ID,true);$report[]='Removed legacy guide child page: '.$slug;}}
 return $report;
}
function lux_import_guides(){
 $path=__DIR__.'/guide-seed.json';if(!is_readable($path))return ['Guide seed missing'];
 $seed=json_decode(file_get_contents($path),true);if(!is_array($seed))return ['Guide seed invalid'];
 $report=[];$i=0;
 foreach($seed as $e){$i++;
  $found=get_posts(['post_type'=>'lux_guide','post_status'=>['publish','draft','pending','private','future','trash'],'meta_key'=>'_lux_guide_seed','meta_value'=>$e['slug'],'numberposts'=>1]);
  if(!$found)$found=get_posts(['post_type'=>'lux_guide','name'=>$e['slug'],'post_status'=>['publish','draft','pending','private','future','trash'],'numberposts'=>1]);
  if($found){$id=$found[0]->ID;wp_update_post(['ID'=>$id,'post_title'=>$e['title'],'post_excerpt'=>$e['excerpt'],'post_content'=>$e['content'],'post_status'=>'publish','menu_order'=>$i]);$report[]='Updated guide: '.$e['title'];}
  else{$id=wp_insert_post(['post_type'=>'lux_guide','post_title'=>$e['title'],'post_name'=>$e['slug'],'post_excerpt'=>$e['excerpt'],'post_content'=>$e['content'],'post_status'=>'publish','menu_order'=>$i],true);if(is_wp_error($id)){$report[]=$id->get_error_message();continue;}$report[]='Created guide: '.$e['title'];}
  $term=get_term_by('slug',$e['dest'],'lux_guide_group');if($term)wp_set_object_terms($id,[(int)$term->term_id],'lux_guide_group');
  update_post_meta($id,'_lux_guide_seed',$e['slug']);update_post_meta($id,'_lux_layout','editorial');delete_post_meta($id,'_lux_seed_article');if(!empty($e['subdest']))update_post_meta($id,'_lux_guide_subdest',$e['subdest']);
  // Owner guides: language version, its English original, article deck/caption and SEO fields.
  foreach(['lang'=>'_lux_lang','translation_of'=>'_lux_translation_of','deck'=>'_lux_deck','caption'=>'_lux_caption','meta_title'=>'_lux_meta_title','meta_desc'=>'_lux_meta_desc'] as $k=>$m){if(isset($e[$k])&&$e[$k]!=='')update_post_meta($id,$m,$e[$k]);else delete_post_meta($id,$m);}
  // Set the cover on first import, and replace it when the seed names a different image.
  if(!empty($e['image'])&&function_exists('lux_import_image')&&(!has_post_thumbnail($id)||get_post_meta($id,'_lux_seed_image',true)!==$e['image'])){$img=lux_import_image($e['image'],$e['alt']??$e['title']);if($img){set_post_thumbnail($id,$img);update_post_meta($id,'_lux_seed_image',$e['image']);}}
 }
 return $report;
}
// Sample monthly owner report (blank template) linked from For Owners: kept in the Media Library so it travels with the site.
function lux_import_sample_report(){
 $id=(int)get_option('lux_sample_report_id');if($id&&get_post_type($id)==='attachment')return $id;
 $src=__DIR__.'/assets/docs/lahg-sample-owner-report-en.pdf';if(!is_readable($src))return 0;
 require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
 $tmp=wp_tempnam('lahg-sample-owner-report-en.pdf');copy($src,$tmp);
 $id=media_handle_sideload(['name'=>'lahg-sample-owner-report-en.pdf','tmp_name'=>$tmp],0,'Sample owner report (blank template)');
 if(is_wp_error($id)){@unlink($tmp);return 0;}update_option('lux_sample_report_id',$id,false);return $id;
}
function lux_sample_report_url(){$id=(int)get_option('lux_sample_report_id');$url=$id?wp_get_attachment_url($id):'';return $url?:plugins_url('assets/docs/lahg-sample-owner-report-en.pdf',__FILE__);}
function lux_import_starter($set_front=false){
 lux_default_terms();$seed=json_decode(file_get_contents(__DIR__.'/starter-content.json'),true);$report=[];
 // The site name appears in every page title: always the full company name.
 if(in_array(get_option('blogname'),['','Luxury Apart Hotel','Luxury Apart Hotel (demo)'],true))update_option('blogname',get_option('blogname')==='Luxury Apart Hotel (demo)'?'Luxury Apart Hotel Group (demo)':'Luxury Apart Hotel Group');if(lux_import_sample_report())$report[]='Sample owner report in Media Library';
 foreach(['home'=>'Home','about-us'=>'About us','for-owners'=>'For owners','contact-us'=>'Contact us','experiences'=>'Experiences','guides-insights'=>'Guides & Insights'] as $slug=>$title){$found=get_page_by_path($slug,OBJECT,'page');if($found){$report[]='Kept existing page: '.$title;continue;}$id=wp_insert_post(['post_type'=>'page','post_title'=>$title,'post_name'=>$slug,'post_status'=>'publish'],true);if(is_wp_error($id)){$report[]=$id->get_error_message();continue;}update_post_meta($id,'_lux_view',['home'=>'home','about-us'=>'about','for-owners'=>'owners','contact-us'=>'contact','experiences'=>'experiences','guides-insights'=>'guides'][$slug]);$report[]='Created page: '.$title;}
 foreach($seed as $entry){$posts=get_posts(['post_type'=>$entry['type'],'name'=>$entry['slug'],'post_status'=>['publish','draft','pending','private','future','trash'],'numberposts'=>1]);if(!$posts)$posts=get_posts(['post_type'=>$entry['type'],'meta_key'=>'_lux_seed_key','meta_value'=>$entry['slug'],'post_status'=>['publish','draft','pending','private','future','trash'],'numberposts'=>1]);if($posts){$id=$posts[0]->ID;$report[]='Kept article: '.$entry['title'];foreach((array)($entry['extra_groups']??[]) as $g){$t2=get_term_by('slug',$g,'lux_guide_group');if($t2)wp_set_object_terms($id,[(int)$t2->term_id],'lux_guide_group',true);}}else{$id=wp_insert_post(['post_type'=>$entry['type'],'post_title'=>$entry['title'],'post_name'=>$entry['slug'],'post_excerpt'=>$entry['description'],'post_content'=>$entry['content'],'post_status'=>'publish','menu_order'=>$entry['order']],true);if(is_wp_error($id)){$report[]=$id->get_error_message();continue;}$term=get_term_by('slug',$entry['group'],$entry['type']==='lux_guide'?'lux_guide_group':'lux_exp_group');if($term)wp_set_object_terms($id,[(int)$term->term_id],$term->taxonomy);foreach((array)($entry['extra_groups']??[]) as $g){$t2=get_term_by('slug',$g,'lux_guide_group');if($t2)wp_set_object_terms($id,[(int)$t2->term_id],'lux_guide_group',true);}update_post_meta($id,'_lux_seed_article','1');update_post_meta($id,'_lux_seed_key',$entry['slug']);update_post_meta($id,'_lux_layout',$entry['layout']??'service');if(!empty($entry['featured']))update_post_meta($id,'_lux_featured','1');$report[]='Created article: '.$entry['title'];}
  if(get_post_meta($id,'_lux_seed_article',true)==='1'&&!empty($entry['image'])&&(!has_post_thumbnail($id)||get_post_meta($id,'_lux_seed_image',true)!==$entry['image'])){$image=lux_import_image($entry['image'],$entry['alt']);if($image){set_post_thumbnail($id,$image);update_post_meta($id,'_lux_seed_image',$entry['image']);}else $report[]='Cover pending (install theme and rerun): '.$entry['title'];}
 }
 if(function_exists('lux_import_legal'))$report=array_merge($report,lux_import_legal());
 if(function_exists('lux_import_thankyou'))$report=array_merge($report,lux_import_thankyou());
 if(function_exists('lux_import_guide_pages'))$report=array_merge($report,lux_import_guide_pages());
 if(function_exists('lux_import_guides'))$report=array_merge($report,lux_import_guides());
 if(function_exists('lux_import_catalog'))$report=array_merge($report,lux_import_catalog());
 if(function_exists('lux_import_experiences'))$report=array_merge($report,lux_import_experiences());
 if($set_front){$home=get_page_by_path('home');if($home){update_option('show_on_front','page');update_option('page_on_front',$home->ID);}}
 update_option('lux_import_report',$report,false);flush_rewrite_rules();return $report;
}
add_action('admin_post_lux_import',function(){if(!current_user_can('manage_options'))wp_die('Not allowed',403);check_admin_referer('lux_import');lux_import_starter(!empty($_POST['set_front']));wp_safe_redirect(admin_url('admin.php?page=luxury-setup&imported=1'));exit;});

require_once __DIR__."/catalog.php";
require_once __DIR__."/rates.php";
require_once __DIR__."/experiences.php";
require_once __DIR__."/ratings.php";
require_once __DIR__."/extras.php";
require_once __DIR__."/vouchers.php";
require_once __DIR__."/currency.php";
require_once __DIR__."/translate.php";
