<?php
if(!defined('ABSPATH'))exit;
// Seasonal nightly rates. A period covers every night from `from` to `to` inclusive (checkout day is not a night).
// When periods overlap, the shortest one wins, so a holiday week can sit inside a wider season. Nights outside all periods use the base rate.

function lux_ymd($v){if(!is_string($v))return false;$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v,new DateTimeZone('UTC'));return $d&&$d->format('Y-m-d')===$v?$d:false;}
function lux_today(){return wp_date('Y-m-d');}
function lux_period_days($r){return (int)lux_ymd($r['from'])->diff(lux_ymd($r['to']))->days+1;}
function lux_clean_rates($rows,&$rejected=0){
 $clean=[];$rejected=0;
 foreach((array)$rows as $r){
  if(!is_array($r))continue;$from=trim((string)($r['from']??''));$to=trim((string)($r['to']??''));$price=trim((string)($r['price']??''));
  if($from===''&&$to===''&&$price==='')continue;
  if(!lux_ymd($from)||!lux_ymd($to)||$to<$from||!is_numeric($price)||$price<0){$rejected++;continue;}
  $clean[]=['from'=>$from,'to'=>$to,'price'=>(int)round((float)$price),'label'=>mb_substr(sanitize_text_field((string)($r['label']??'')),0,60)];
 }
 usort($clean,fn($a,$b)=>[$a['from'],$a['to']]<=>[$b['from'],$b['to']]);return $clean;
}
function lux_rates($id){$r=get_post_meta($id,'_lux_rates',true);return is_array($r)?lux_clean_rates($r):[];}
function lux_upcoming_rates($id){$today=lux_today();return array_values(array_filter(lux_rates($id),fn($r)=>$r['to']>=$today));}

function lux_rate_for_night($base,$rates,$night){
 $best=null;$bestDays=PHP_INT_MAX;
 foreach($rates as $r)if($r['from']<=$night&&$night<=$r['to']){$days=lux_period_days($r);if($days<=$bestDays){$best=$r;$bestDays=$days;}}
 return $best?['price'=>(float)$best['price'],'label'=>$best['label']]:['price'=>(float)$base,'label'=>''];
}
// Returns nights, total, average and consecutive segments that share a rate. `on_request` means at least one night has no price.
function lux_quote($base,$rates,$checkin,$checkout){
 $in=lux_ymd($checkin);$out=lux_ymd($checkout);if(!$in||!$out||$out<=$in)return null;
 $total=0;$nights=0;$segments=[];$onRequest=false;
 for($d=$in;$d<$out;$d=$d->modify('+1 day')){
  $night=$d->format('Y-m-d');$rate=lux_rate_for_night($base,$rates,$night);$nights++;$total+=$rate['price'];if($rate['price']<=0)$onRequest=true;
  $last=count($segments)-1;
  if($last>=0&&$segments[$last]['price']===$rate['price']&&$segments[$last]['label']===$rate['label']){$segments[$last]['nights']++;$segments[$last]['to']=$night;}
  else $segments[]=['from'=>$night,'to'=>$night,'nights'=>1,'price'=>$rate['price'],'label'=>$rate['label']];
 }
 return ['nights'=>$nights,'total'=>$total,'average'=>$nights?round($total/$nights):0,'segments'=>$segments,'on_request'=>$onRequest];
}
// Lowest nightly rate a guest can still book: the base rate and any period that has not ended.
function lux_from_price($base,$rates){$prices=array_filter(array_merge([(float)$base],array_map(fn($r)=>(float)$r['price'],$rates)),fn($p)=>$p>0);return $prices?min($prices):0;}
function lux_money($v){return '$'.number_format((float)$v,0);}
function lux_short_date($ymd){$d=lux_ymd($ymd);return $d?$d->format('j M Y'):$ymd;}

// Apartment editor: one row per period.
add_action('add_meta_boxes',function(){add_meta_box('lux-rates','Seasonal rates','lux_rates_box',lux_room_type(),'normal','high');});
function lux_rate_row($i,$r=[]){$today=lux_today();$ended=!empty($r['to'])&&$r['to']<$today;?>
<tr class="lux-rate-row<?php echo $ended?' is-ended':'';?>">
 <td><input type="date" name="lux_rates[<?php echo esc_attr($i);?>][from]" value="<?php echo esc_attr($r['from']??'');?>" aria-label="First night"></td>
 <td><input type="date" name="lux_rates[<?php echo esc_attr($i);?>][to]" value="<?php echo esc_attr($r['to']??'');?>" aria-label="Last night"></td>
 <td><input type="number" min="0" step="1" name="lux_rates[<?php echo esc_attr($i);?>][price]" value="<?php echo esc_attr($r['price']??'');?>" aria-label="Nightly rate in USD" style="width:110px"></td>
 <td><input type="text" maxlength="60" name="lux_rates[<?php echo esc_attr($i);?>][label]" value="<?php echo esc_attr($r['label']??'');?>" placeholder="e.g. High season" aria-label="Season name" class="widefat"></td>
 <td><?php if($ended)echo '<span class="lux-rate-ended">Ended</span>';?><button type="button" class="button-link lux-rate-remove" aria-label="Remove period">Remove</button></td>
</tr><?php }
function lux_rates_box($post){
 $rates=lux_rates($post->ID);$base=(float)get_post_meta($post->ID,'_lux_price',true);
 $overlaps=[];for($i=0;$i<count($rates);$i++)for($j=$i+1;$j<count($rates);$j++)if($rates[$j]['from']<=$rates[$i]['to']&&$rates[$i]['from']<=$rates[$j]['to'])$overlaps[]=lux_short_date($rates[$i]['from']).'–'.lux_short_date($rates[$i]['to']).' and '.lux_short_date($rates[$j]['from']).'–'.lux_short_date($rates[$j]['to']);
 ?><style>#lux-rates table{border-collapse:collapse;width:100%;margin:10px 0}#lux-rates th{text-align:left;font-weight:600;padding:6px 8px 6px 0}#lux-rates td{padding:6px 8px 6px 0;vertical-align:middle}#lux-rates .is-ended input{opacity:.55}.lux-rate-ended{display:inline-block;margin-right:10px;padding:2px 7px;border-radius:3px;background:#f0f0f1;color:#646970;font-size:11px}.lux-rate-remove{color:#b32d2e}</style>
 <p>Set nightly rates in USD for any period ahead. Each night of a stay is priced by the period it falls in, so a stay across two seasons is charged accordingly. Nights outside every period use the base rate from Apartment details (<?php echo $base>0?esc_html(lux_money($base)):'not set — shown as “Rate on request”';?>).</p>
 <p>“Last night” is the final night charged: for a period from 1 October to 30 November, a guest leaving on 1 December pays the seasonal rate for every night. If periods overlap, the shorter period wins. The season name is shown to guests in the price breakdown.</p>
 <?php if($overlaps)echo '<div class="notice notice-info inline"><p>Overlapping periods (the shorter one applies): '.esc_html(implode('; ',$overlaps)).'</p></div>';?>
 <input type="hidden" name="lux_rates_present" value="1">
 <table><thead><tr><th>First night</th><th>Last night</th><th>Rate / night (USD)</th><th>Season name (optional)</th><th></th></tr></thead><tbody id="lux-rate-rows"><?php foreach($rates as $i=>$r)lux_rate_row($i,$r);if(!$rates)lux_rate_row(0);?></tbody></table>
 <template id="lux-rate-template"><?php lux_rate_row('__i__');?></template>
 <p><button type="button" class="button" id="lux-add-rate">Add period</button> <a href="<?php echo esc_url(admin_url('admin.php?page=luxury-rates'));?>">Edit seasons for several apartments</a></p><?php
}
add_action('save_post',function($id){
 if(!isset($_POST['lux_rates_present'],$_POST['lux_apartment_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['lux_apartment_nonce'])),'lux_apartment')||!current_user_can('edit_post',$id)||get_post_type($id)!==lux_room_type()||wp_is_post_revision($id)||wp_is_post_autosave($id))return;
 $rates=lux_clean_rates(wp_unslash($_POST['lux_rates']??[]),$rejected);update_post_meta($id,'_lux_rates',$rates);
 if($rejected)set_transient('lux_rates_notice_'.get_current_user_id(),$rejected,60);
},20);
add_action('admin_notices',function(){$key='lux_rates_notice_'.get_current_user_id();$n=(int)get_transient($key);if(!$n)return;delete_transient($key);echo '<div class="notice notice-warning is-dismissible"><p>'.esc_html(sprintf(_n('%d seasonal rate was not saved: check that it has both dates, the last night is not before the first, and a rate of 0 or more.','%d seasonal rates were not saved: check that each has both dates, the last night is not before the first, and a rate of 0 or more.',$n),$n)).'</p></div>';});

// Several apartments at once: add a season (fixed rate or % of each base rate) or remove periods with exact dates.
add_action('admin_menu',function(){add_submenu_page('luxury-setup','Seasonal rates','Seasonal rates','manage_options','luxury-rates','lux_rates_page');});
function lux_rates_page(){
 if(!current_user_can('manage_options'))return;$posts=lux_catalog_posts();$done=isset($_GET['lux_done'])?sanitize_text_field(wp_unslash($_GET['lux_done'])):'';
 ?><div class="wrap"><h1>Seasonal rates</h1>
 <?php if($done)echo '<div class="notice notice-success is-dismissible"><p>'.esc_html($done).'</p></div>';?>
 <p>Plan prices ahead for several apartments at once. To fine-tune one apartment, open it and edit its Seasonal rates.</p>
 <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="background:#fff;border:1px solid #c3c4c7;padding:16px 20px;max-width:980px">
 <input type="hidden" name="action" value="lux_bulk_rates"><?php wp_nonce_field('lux_bulk_rates');?>
 <h2 style="margin-top:0">Season</h2>
 <p><label>First night <input type="date" name="from" required></label> &nbsp; <label>Last night <input type="date" name="to" required></label> &nbsp; <label>Season name <input type="text" name="label" maxlength="60" placeholder="e.g. Autumn"></label></p>
 <p><label><input type="radio" name="kind" value="fixed" checked> Same nightly rate for every selected apartment: $ <input type="number" name="fixed" min="0" step="1" style="width:100px"></label></p>
 <p><label><input type="radio" name="kind" value="percent"> Change each apartment’s base rate by <input type="number" name="percent" min="-90" max="500" step="1" style="width:80px"> % (e.g. 20 for +20%, -15 for −15%)</label></p>
 <h2>Apartments</h2>
 <?php foreach(['batumi'=>'Batumi','gudauri'=>'New Gudauri'] as $city=>$name){$list=array_filter($posts,fn($p)=>get_post_meta($p->ID,'_lux_city',true)===$city);if(!$list)continue;?>
 <fieldset style="margin:0 0 14px"><legend><strong><?php echo esc_html($name);?></strong> · <label><input type="checkbox" class="lux-check-city" data-city="<?php echo esc_attr($city);?>"> all</label></legend>
 <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:4px 16px;margin-top:6px"><?php foreach($list as $p){$base=(float)get_post_meta($p->ID,'_lux_price',true);?><label><input type="checkbox" name="apartments[]" value="<?php echo (int)$p->ID;?>" data-city="<?php echo esc_attr($city);?>"> <?php echo esc_html(get_the_title($p));?> <span style="color:#646970">(base <?php echo $base>0?esc_html(lux_money($base)):'—';?>)</span></label><?php }?></div></fieldset><?php }?>
 <p><button class="button button-primary" name="mode" value="add">Add season to selected</button> <button class="button" name="mode" value="remove" formnovalidate onclick="return this.form.from.value&&this.form.to.value?confirm('Remove periods with exactly these dates from the selected apartments?'):(alert('Enter the first and last night of the season to remove.'),false)">Remove periods with these exact dates</button></p>
 </form>
 <h2>Upcoming rates</h2>
 <table class="widefat striped" style="max-width:980px"><thead><tr><th>Apartment</th><th>Base / night</th><th>Periods</th></tr></thead><tbody><?php foreach($posts as $p){$rates=lux_upcoming_rates($p->ID);$base=(float)get_post_meta($p->ID,'_lux_price',true);?><tr><td><a href="<?php echo esc_url(get_edit_post_link($p->ID));?>"><?php echo esc_html(get_the_title($p));?></a></td><td><?php echo $base>0?esc_html(lux_money($base)):'—';?></td><td><?php echo $rates?implode('<br>',array_map(fn($r)=>esc_html(lux_short_date($r['from']).' – '.lux_short_date($r['to']).' · '.lux_money($r['price']).($r['label']?' · '.$r['label']:'')),$rates)):'<span style="color:#646970">Base rate all year</span>';?></td></tr><?php }?></tbody></table>
 <script>document.querySelectorAll('.lux-check-city').forEach(c=>c.addEventListener('change',()=>document.querySelectorAll('input[name="apartments[]"][data-city="'+c.dataset.city+'"]').forEach(b=>b.checked=c.checked)));</script>
 </div><?php
}
add_action('admin_post_lux_bulk_rates',function(){
 if(!current_user_can('manage_options'))wp_die('Not allowed',403);check_admin_referer('lux_bulk_rates');
 $back=function($msg){wp_safe_redirect(add_query_arg('lux_done',rawurlencode($msg),admin_url('admin.php?page=luxury-rates')));exit;};
 $from=sanitize_text_field(wp_unslash($_POST['from']??''));$to=sanitize_text_field(wp_unslash($_POST['to']??''));$mode=($_POST['mode']??'')==='remove'?'remove':'add';
 $ids=array_filter(array_map('absint',(array)($_POST['apartments']??[])),fn($id)=>get_post_type($id)===lux_room_type());
 if(!lux_ymd($from)||!lux_ymd($to)||$to<$from){return $back('Nothing changed: enter a first and last night, with the last night on or after the first.');}
 if(!$ids){return $back('Nothing changed: select at least one apartment.');}
 $changed=0;
 if($mode==='remove'){foreach($ids as $id){$rates=lux_rates($id);$kept=array_values(array_filter($rates,fn($r)=>!($r['from']===$from&&$r['to']===$to)));if(count($kept)!==count($rates)){update_post_meta($id,'_lux_rates',$kept);$changed++;}}return $back(sprintf('Removed %s – %s from %d apartment(s).',lux_short_date($from),lux_short_date($to),$changed));}
 $kind=($_POST['kind']??'')==='percent'?'percent':'fixed';$fixed=$_POST['fixed']??'';$percent=$_POST['percent']??'';
 if($kind==='fixed'&&(!is_numeric($fixed)||$fixed<0)){return $back('Nothing changed: enter a nightly rate of 0 or more.');}
 if($kind==='percent'&&(!is_numeric($percent)||$percent<-90||$percent>500)){return $back('Nothing changed: enter a percentage between -90 and 500.');}
 $label=mb_substr(sanitize_text_field(wp_unslash($_POST['label']??'')),0,60);$skipped=0;
 foreach($ids as $id){
  $base=(float)get_post_meta($id,'_lux_price',true);if($kind==='percent'&&$base<=0){$skipped++;continue;}
  $price=$kind==='fixed'?(float)$fixed:$base*(1+(float)$percent/100);
  $rates=array_values(array_filter(lux_rates($id),fn($r)=>!($r['from']===$from&&$r['to']===$to)));$rates[]=['from'=>$from,'to'=>$to,'price'=>round($price),'label'=>$label];
  update_post_meta($id,'_lux_rates',lux_clean_rates($rates));$changed++;
 }
 return $back(sprintf('Saved %s – %s for %d apartment(s).',lux_short_date($from),lux_short_date($to),$changed).($skipped?sprintf(' %d skipped: no base rate to apply a percentage to.',$skipped):''));
});
