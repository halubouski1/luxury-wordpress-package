<?php
if(!defined('ABSPATH'))exit;
// Booking numbers and vouchers. Every apartment booking gets the next number (LAH-2026-0001, LAH-2026-0002 …),
// a private voucher link, and emails: "received" on submit and "confirmed" when the manager sets the status to Confirmed.

function lux_next_booking_number(){
 $lock='lux_booking_seq_lock';for($i=0;$i<50&&!add_option($lock,time(),'','no');$i++){if((int)get_option($lock)<time()-10)delete_option($lock);usleep(100000);}
 $n=(int)get_option('lux_booking_seq',0)+1;update_option('lux_booking_seq',$n,false);delete_option($lock);
 return 'LAH-'.wp_date('Y').'-'.str_pad((string)$n,4,'0',STR_PAD_LEFT);
}
function lux_voucher_url($id){$d=get_post_meta($id,'_lux_request',true);$key=get_post_meta($id,'_lux_voucher_key',true);return is_array($d)&&$key?add_query_arg(['lux_voucher'=>rawurlencode($d['reference']),'vk'=>$key],home_url('/')):'';}
function lux_voucher_status($id){return ['new'=>['Received','Awaiting confirmation from our team'],'reviewing'=>['In review','We are checking availability for your dates'],'confirmed'=>['Confirmed','Your booking is confirmed'],'declined'=>['Not available','Unfortunately these dates are not available'],'cancelled'=>['Cancelled','This booking has been cancelled'],'awaiting_payment'=>['Awaiting payment','Complete the prepayment to confirm your booking'],'payment_failed'=>['Not confirmed','The payment was not completed']][get_post_meta($id,'_lux_status',true)?:'new']??['Received',''];}

// Voucher body shared by the web page and the email (inline styles so email clients keep the layout).
function lux_voucher_html($id){
 $d=get_post_meta($id,'_lux_request',true);if(!is_array($d))return '';
 $b=$d['breakdown']??null;$m=fn($v)=>$v===null?'On request':lux_request_money($d,$v);[$status,$statusText]=lux_voucher_status($id);
 $in=lux_ymd($d['checkin']);$out=lux_ymd($d['checkout']);$nights=$in&&$out?$out->diff($in)->days:0;
 $row=fn($k,$v,$strong=false)=>'<tr><td style="padding:9px 0;border-bottom:1px solid #e4e4dc;color:#474e42;font-size:14px">'.esc_html($k).'</td><td style="padding:9px 0;border-bottom:1px solid #e4e4dc;text-align:right;font-size:14px;color:#141813'.($strong?';font-weight:600':'').'">'.esc_html($v).'</td></tr>';
 $logo=function_exists('lux_theme_asset')&&wp_get_theme('luxury-apart-hotel')->exists()?esc_url(wp_get_theme('luxury-apart-hotel')->get_stylesheet_directory_uri().'/assets/images/luxury-logo-footer-group.webp'):'';
 $h='<div style="max-width:640px;margin:0 auto;background:#fff;border:1px solid #e4e4dc;font-family:Helvetica,Arial,sans-serif;color:#141813">';
 $h.='<div style="padding:28px 32px;border-bottom:1px solid #e4e4dc;display:flex;align-items:center;justify-content:space-between;gap:16px">'.($logo?'<img src="'.$logo.'" alt="Luxury Apart Hotel Group" width="64" style="width:64px;height:auto">':'<strong>LUXURY APART HOTEL GROUP</strong>').'<div style="text-align:right"><div style="font-size:11px;letter-spacing:.14em;color:#474e42">BOOKING REQUEST</div><div style="font-size:22px;font-weight:600;margin-top:4px">'.esc_html($d['reference']).'</div></div></div>';
 $h.='<div style="padding:18px 32px;background:'.($status==='Confirmed'?'#e8efe2':'#f4f2ea').';font-size:15px"><strong>'.esc_html($status).'</strong> · '.esc_html($statusText).'</div>';
 $h.='<div style="padding:24px 32px"><table style="width:100%;border-collapse:collapse">'.$row('Guest',$d['name']).$row('Email',$d['email']).$row('Phone',$d['phone']).(!empty($d['created'])?$row('Booking date',mysql2date('j M Y, H:i',$d['created']).' (Tbilisi time)'):'').$row('Check-in',$in?$in->format('j M Y'):'').$row('Check-out',$out?$out->format('j M Y'):'').$row('Nights',(string)$nights).'</table>';
 $h.='<div style="margin:22px 0 6px;font-size:11px;letter-spacing:.14em;color:#474e42">APARTMENTS</div><table style="width:100%;border-collapse:collapse">';
 foreach($d['apartments'] as $a){$q=$a['quote']??null;$h.=$row($a['title'].' · '.($a['city']==='gudauri'?'New Gudauri':'Batumi').' · '.$a['guests'].' guest'.($a['guests']==1?'':'s'),$q?($q['on_request']?'On request':$m($q['total'])):'');}
 $h.='</table>';
 if($b){$h.='<div style="margin:22px 0 6px;font-size:11px;letter-spacing:.14em;color:#474e42">SERVICES &amp; PAYMENT</div><table style="width:100%;border-collapse:collapse">';
  if($b['breakfast']['guests'])$h.=$row('Breakfast · '.$b['breakfast']['guests'].' guests × '.$b['breakfast']['nights'].' nights',$m($b['breakfast']['total']));
  if($b['transfer'])$h.=$row('Transfer · '.$b['transfer']['name'].' · '.(($b['transfer']['vehicle']??'car')==='minivan'?'minivan':'private car').' · '.($b['transfer']['trip']==='round'?'round trip':'one way'),$b['transfer']['on_request']?'On request':$m($b['transfer']['total']));
  $h.=$row('Total booking price',$m($b['total']),true);
  $p=$b['payment'];$h.=$row($p['option']==='full'?'Payment option · 100% full payment':'Payment option · '.$p['percent'].'% deposit',$m($p['due_now']).' due now');
  if($p['option']==='full')$h.=$row('Deposit',$b['total']===null?'On request':$m(0));
  $h.=$row('Balance due on arrival',$m($p['balance']),true).'</table>';}
 if(!empty($d['notes']))$h.='<p style="margin:18px 0 0;font-size:14px;color:#474e42"><strong style="color:#141813">Your notes:</strong> '.esc_html($d['notes']).'</p>';
 $h.='<p style="margin:22px 0 0;font-size:13px;line-height:1.6;color:#474e42">'.($status==='Confirmed'?'Please show this voucher on arrival. ':'This voucher confirms that we received your booking request. ').'No payment has been taken on the website; our team sends a secure payment link for the amount due now. Questions: <a href="mailto:reservations@luxuryaparthotel.ge" style="color:#141813">reservations@luxuryaparthotel.ge</a></p></div>';
 $h.='<div style="padding:16px 32px;border-top:1px solid #e4e4dc;font-size:12px;color:#474e42">LLC LUXURY APART HOTEL GROUP · Batumi: Sherif Khimshiashvili 7d, Orbi City · Gudauri: Redco New Gudauri 4702</div></div>';
 return $h;
}
function lux_send_voucher($id,$kind){
 if(defined('LUXURY_DEMO')&&LUXURY_DEMO)return false;$d=get_post_meta($id,'_lux_request',true);if(!is_array($d)||!is_email($d['email']??''))return false;
 $subject=$kind==='confirmed'?'Your booking is confirmed · '.$d['reference']:'We received your booking · '.$d['reference'];
 $intro=$kind==='confirmed'?'Great news — your booking is confirmed. Your voucher is below.':'Thank you for your booking with Luxury Apart Hotel Group. We have received your request and will confirm availability shortly.';
 $body='<div style="background:#f8f7f3;padding:24px 12px"><p style="max-width:640px;margin:0 auto 16px;font-family:Helvetica,Arial,sans-serif;font-size:15px;color:#141813">Dear '.esc_html($d['name']).',<br>'.esc_html($intro).'</p>'.lux_voucher_html($id).'<p style="max-width:640px;margin:16px auto 0;font-family:Helvetica,Arial,sans-serif;font-size:13px"><a href="'.esc_url(lux_voucher_url($id)).'" style="color:#141813">View and print your voucher online</a></p></div>';
 if($kind==='received'&&function_exists('luxv_request_email')&&($req=luxv_request_email($id)))[$subject,$body]=$req;
 $sent=wp_mail($d['email'],$subject,$body,[(function_exists('luxv_from_header')?luxv_from_header():'From: Luxury Apart Hotel Group <reservations@luxuryaparthotel.ge>'),'Content-Type: text/html; charset=UTF-8','Reply-To: Luxury Apart Hotel Group <reservations@luxuryaparthotel.ge>','Bcc: '.(function_exists('lux_booking_notify_email')?lux_booking_notify_email():'reservations@luxuryaparthotel.ge')]);
 update_post_meta($id,'_lux_voucher_'.$kind,$sent?current_time('mysql'):'failed');return $sent;
}
// The confirmation with the PDF voucher is issued in voucher-doc.php once the booking is confirmed and paid.

// Public, printable voucher page: /?lux_voucher=LAH-2026-0001&vk=…
add_filter('query_vars',fn($v)=>array_merge($v,['lux_voucher','vk']));
add_action('template_redirect',function(){
 $ref=get_query_var('lux_voucher');if(!$ref)return;$key=(string)get_query_var('vk');
 $posts=get_posts(['post_type'=>'lux_booking','post_status'=>'private','numberposts'=>1,'meta_key'=>'_lux_reference','meta_value'=>sanitize_text_field($ref)]);
 $id=$posts?$posts[0]->ID:0;$valid=$id&&$key!==''&&hash_equals((string)get_post_meta($id,'_lux_voucher_key',true),$key);
 // Once the confirmation is issued the link shows its current version (same content as the PDF) and serves the stored PDF.
 $cur=$valid&&function_exists('luxv_current')?luxv_current($id):null;
 if($cur&&!empty($_GET['pdf'])&&($f=luxv_file($cur)))luxv_send_file($f,$cur['snapshot']['reference'].'-v'.$cur['version'].'.pdf',true);
 if($cur){$L=$cur['locale'];status_header(200);nocache_headers();header('X-Robots-Tag: noindex, nofollow');if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);header('X-LiteSpeed-Cache-Control: no-cache');
  $pdfUrl=add_query_arg(['lux_voucher'=>rawurlencode($ref),'vk'=>$key,'pdf'=>'1'],home_url('/'));$sans=$L==='ka'?"'Noto Sans Georgian',Calibri,Carlito,Helvetica,Arial,sans-serif":"Calibri,Carlito,'Segoe UI',Helvetica,Arial,sans-serif";
  echo '<!doctype html><html lang="'.esc_attr($L).'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="google" content="notranslate"><title>'.esc_html(luxv_t($L,'title').' '.$ref).'</title><style>*{box-sizing:border-box}body{margin:0;background:#f8f7f3;padding:28px 12px;color:#171717}.wrap{max-width:760px;margin:0 auto;background:#fff;border:1px solid #e4e4dc;padding:32px 36px}.acts{max-width:760px;margin:0 auto 14px;display:flex;flex-wrap:wrap;gap:10px 22px;align-items:center;font-family:'.$sans.';font-size:15px}.acts a{color:#171717}.acts .btn{background:#050505;color:#fff;text-decoration:none;padding:14px 22px;font-size:16px;text-align:center}.acts button{background:none;border:0;padding:0;font:inherit;color:#171717;text-decoration:underline;cursor:pointer}@media(max-width:600px){body{padding:12px 8px}.wrap{padding:20px 14px}.acts .btn{flex:1 1 100%}}@media print{.acts{display:none}body{background:#fff;padding:0}.wrap{border:0;padding:0}}'.luxv_css(false).'</style></head><body class="notranslate" translate="no">';
  echo '<div class="acts"><a class="btn" href="'.esc_url($pdfUrl).'">'.esc_html(luxv_t($L,'download_pdf')).'</a><button type="button" onclick="window.print()">'.esc_html(luxv_t($L,'print')).'</button><a href="'.esc_url(home_url('/')).'">'.esc_html(luxv_t($L,'home')).'</a></div>'.(get_post_meta($id,'_lux_status',true)==='cancelled'?'<div class="acts" style="background:#fbeaea;border:1px solid #e3b3b3;padding:12px 16px;color:#8a1f1f;font-weight:bold">'.esc_html(['en'=>'This booking has been cancelled. The confirmation below is no longer valid.','ru'=>'Это бронирование отменено. Подтверждение ниже больше не действительно.','ka'=>'ეს ჯავშანი გაუქმებულია. ქვემოთ მოცემული დადასტურება აღარ მოქმედებს.'][$L]??'This booking has been cancelled.').'</div>':'').'<div class="wrap">'.luxv_html($cur['snapshot']).'</div></body></html>';exit;}
 status_header($valid?200:404);nocache_headers();header('X-Robots-Tag: noindex, nofollow');
 echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>'.esc_html($valid?'Booking voucher '.$ref:'Voucher not found').'</title><style>body{margin:0;background:#f8f7f3;padding:32px 12px;font-family:Helvetica,Arial,sans-serif}.bar{max-width:640px;margin:0 auto 16px;display:flex;justify-content:space-between;gap:12px;align-items:center}.bar a,.bar button{font:inherit;font-size:14px;color:#141813}.bar button{background:#050505;color:#fff;border:0;padding:12px 18px;cursor:pointer}@media print{.bar{display:none}body{background:#fff;padding:0}}</style></head><body>';
 if($valid)echo '<div class="bar"><a href="'.esc_url(home_url('/')).'">← Luxury Apart Hotel Group</a><button type="button" onclick="window.print()">Print voucher</button></div>'.lux_voucher_html($id);
 else echo '<div class="bar"><p>This voucher link is not valid. Please use the link from your email or contact reservations@luxuryaparthotel.ge.</p></div>';
 echo '</body></html>';exit;
});
// Admin: voucher link and resend.
add_action('add_meta_boxes',function(){add_meta_box('lux-voucher','Voucher','lux_voucher_box','lux_booking','side','high');});
function lux_voucher_box($post){$url=lux_voucher_url($post->ID);if(!$url){echo '<p>No voucher for this request.</p>';return;}
 echo '<p><a class="button" href="'.esc_url($url).'" target="_blank">Open voucher</a></p>';
 foreach(['received'=>'“Received” email','confirmed'=>'Confirmation PDF email'] as $k=>$label){$v=get_post_meta($post->ID,'_lux_voucher_'.$k,true);echo '<p>'.esc_html($label).': '.esc_html($v?($v==='failed'?'not delivered — check the site email (SMTP) settings':'sent '.$v):'not sent').'</p>';}
 echo '<p class="description">The confirmation (PDF) is issued and emailed to the guest and the company once the status is “Confirmed by manager” and the required payment is recorded below.</p>';
}

// Thank-you page after a booking request (no online payment: price on request, or payment switched off).
add_filter('the_content',function($c){if(!is_page('thank-you-rental')||!in_the_loop())return $c;$ref=isset($_GET['ref'])?sanitize_text_field(wp_unslash($_GET['ref'])):'';return '<p>Your booking request has been received'.($ref?' — booking number <strong>'.esc_html($ref).'</strong>':'').'.</p><p>We have emailed you a confirmation of your request. Our team will confirm availability and the final price and send you a secure payment link. Your confirmed voucher arrives by email after the payment.</p><p>Questions? <a href="mailto:reservations@luxuryaparthotel.ge">reservations@luxuryaparthotel.ge</a></p><p><a href="'.esc_url(home_url('/apartments/')).'">Back to apartments</a></p>';},20);
