(()=>{'use strict';
const config=window.LUX_LANGS;if(!config)return;
const widget=document.getElementById('lux-lang');if(!widget)return;
const toggle=widget.querySelector('.lux-lang-toggle'),menu=widget.querySelector('.lux-lang-menu'),current=widget.querySelector('[data-lux-current]');
const langs=config.languages;

// Read the Google Translate cookie (googtrans=/en/ru) to know the active language.
function activeCode(){
 const m=document.cookie.match(/(?:^|;\s*)googtrans=([^;]+)/);
 if(m){const g=decodeURIComponent(m[1]).split('/').pop();for(const c in langs)if(langs[c].google===g)return c;}
 return config.default;
}
function setCookie(google){
 const val=google===config.default?'':('/'+config.default+'/'+google);
 const host=location.hostname;
 // Clear then set across host variants so Google picks it up.
 for(const d of ['', '; domain='+host, '; domain=.'+host]){
  document.cookie='googtrans=;expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/'+d;
 }
 if(val){document.cookie='googtrans='+val+'; path=/';document.cookie='googtrans='+val+'; path=/; domain='+host;}
}
function applyDir(code){
 const rtl=langs[code]&&langs[code].rtl;
 document.documentElement.setAttribute('dir',rtl?'rtl':'ltr');
 document.documentElement.classList.toggle('lux-rtl',!!rtl);
}
function label(code){return (langs[code]||langs[config.default]).label;}

function paint(code){
 current.textContent=label(code);
 const flag=widget.querySelector('[data-lux-flag]'),src=(langs[code]||langs[config.default]).flag;
 if(flag&&src)flag.src=src;
 widget.querySelectorAll('[data-lang]').forEach(li=>li.setAttribute('aria-selected',String(li.dataset.lang===code)));
}

function choose(code){
 if(!langs[code])return;
 setCookie(langs[code].google);
 applyDir(code);paint(code);
 // Re-run Google's translation for the new cookie value.
 location.reload();
}

toggle.addEventListener('click',()=>{const open=!menu.hidden;menu.hidden=open;toggle.setAttribute('aria-expanded',String(!open));});
document.addEventListener('click',e=>{if(!widget.contains(e.target)){menu.hidden=true;toggle.setAttribute('aria-expanded','false');}});
menu.addEventListener('click',e=>{const li=e.target.closest('[data-lang]');if(li)choose(li.dataset.lang);});

const code=activeCode();paint(code);applyDir(code);widget.hidden=false;

// Move the switcher into the header next to "Book your stay"; keep it there if the header re-renders.
function dock(){
 const actions=document.querySelector('.header-actions');
 // Move the same node (keeps its listeners and any open menu); never force-close here.
 if(actions){if(widget.parentElement!==actions){widget.classList.add('lux-lang-inheader');actions.insertBefore(widget,actions.firstChild);}}
 else if(widget.parentElement!==document.body){widget.classList.remove('lux-lang-inheader');document.body.appendChild(widget);}
}
// Client-approved copy: elements with data-lux-i18n='{"ru":"…"}' show that text and are skipped by Google.
function manual(){
 document.querySelectorAll('[data-lux-i18n]').forEach(el=>{
  let map;try{map=JSON.parse(el.dataset.luxI18n);}catch(e){return;}
  const t=map[code];
  if(t){if(el.textContent!==t)el.textContent=t;el.classList.add('notranslate');el.setAttribute('translate','no');}
 });
}
dock();manual();
const host=document.getElementById('luxury-app')||document.body;
let queued=false;
new MutationObserver(()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;dock();manual();});}).observe(host,{childList:true,subtree:true});
})();
